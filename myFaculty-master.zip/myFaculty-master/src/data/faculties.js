var facultiesInfo = [{
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT823",
    "SLOT": "TE2",
    "FACULTY": "GANGATHARAN C"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GANGATHARAN C"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT703",
    "SLOT": "TE1",
    "FACULTY": "GEMINI V JOY"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GEMINI V JOY"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT703",
    "SLOT": "TE2",
    "FACULTY": "GEMINI V JOY"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GEMINI V JOY"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT704",
    "SLOT": "TE1",
    "FACULTY": "MERCY MATHEW"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MERCY MATHEW"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT704",
    "SLOT": "TE2",
    "FACULTY": "MERCY MATHEW"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MERCY MATHEW"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT824",
    "SLOT": "TE1",
    "FACULTY": "MURUGAVEL R"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MURUGAVEL R"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT824",
    "SLOT": "TE2",
    "FACULTY": "PADMAVATHY C"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PADMAVATHY C"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT109",
    "SLOT": "TE1",
    "FACULTY": "PADMAVATHY C"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PADMAVATHY C"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT112",
    "SLOT": "TE1",
    "FACULTY": "NAGA VENKATA RAGHURAM J."
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NAGA VENKATA RAGHURAM J."
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT113",
    "SLOT": "TE1",
    "FACULTY": "SURAJ KUSHE SHEKHAR"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SURAJ KUSHE SHEKHAR"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT113",
    "SLOT": "TE2",
    "FACULTY": "SURAJ KUSHE SHEKHAR"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SURAJ KUSHE SHEKHAR"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT114",
    "SLOT": "TE1",
    "FACULTY": "RAMASESHAN H."
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMASESHAN H."
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT114",
    "SLOT": "TE2",
    "FACULTY": "RAMASESHAN H."
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMASESHAN H."
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "TT630",
    "SLOT": "TE1",
    "FACULTY": "SEEMA A"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SEEMA A"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "TT630",
    "SLOT": "TE2",
    "FACULTY": "SEEMA A"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SEEMA A"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "TT631",
    "SLOT": "TE1",
    "FACULTY": "SEETHA RAM V."
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SEETHA RAM V."
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "TT631",
    "SLOT": "TE2",
    "FACULTY": "SEETHA RAM V."
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SEETHA RAM V."
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "TT715",
    "SLOT": "TE1",
    "FACULTY": "SUBASHINI R"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUBASHINI R"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "TT715",
    "SLOT": "TE2",
    "FACULTY": "SUBASHINI R"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUBASHINI R"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT823",
    "SLOT": "TE1",
    "FACULTY": "VISALAKSHMI S"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VISALAKSHMI S"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "MB110",
    "SLOT": "TE2",
    "FACULTY": "VISALAKSHMI S"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VISALAKSHMI S"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "TT716",
    "SLOT": "TE1",
    "FACULTY": "RAVIKUMAR B"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAVIKUMAR B"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "TT716",
    "SLOT": "TE2",
    "FACULTY": "RAVIKUMAR B"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAVIKUMAR B"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "GDN123",
    "SLOT": "TE1",
    "FACULTY": "VENUGOPAL P."
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VENUGOPAL P."
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "CDMM1\n01",
    "SLOT": "TE1",
    "FACULTY": "SUDHAKAR  R"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUDHAKAR  R"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "CDMM1\n01",
    "SLOT": "TE2",
    "FACULTY": "SUDHAKAR  R"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUDHAKAR  R"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "GDN123",
    "SLOT": "TE2",
    "FACULTY": "VENUGOPAL P."
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VENUGOPAL P."
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "TT724",
    "SLOT": "TE1",
    "FACULTY": "SOUMEN PAL"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SOUMEN PAL"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "TT724",
    "SLOT": "TE2",
    "FACULTY": "SOUMEN PAL"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SOUMEN PAL"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT109",
    "SLOT": "TE2",
    "FACULTY": "SUNDARAMALI G"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUNDARAMALI G"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT112",
    "SLOT": "TE2",
    "FACULTY": "RAJYALAKSHMI G"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJYALAKSHMI G"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SMV112",
    "SLOT": "TE1",
    "FACULTY": "SRINIVASA GUPTA N"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SRINIVASA GUPTA N"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SMV116",
    "SLOT": "TE1",
    "FACULTY": "JAYAKRISHNA K"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JAYAKRISHNA K"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT601",
    "SLOT": "TE2",
    "FACULTY": "ASHOK D"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ASHOK D"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT602",
    "SLOT": "TE2",
    "FACULTY": "STEPHAN THANGAIAH I S"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "STEPHAN THANGAIAH I S"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT604",
    "SLOT": "TE2",
    "FACULTY": "SUDIPTO BHATTACHARYA"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUDIPTO BHATTACHARYA"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT617",
    "SLOT": "TE1",
    "FACULTY": "MURALI MANOHAR B"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MURAL MANOHAR B"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT619",
    "SLOT": "TE1",
    "FACULTY": "SUJATHA  S"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUJATHA  S"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT803",
    "SLOT": "TE1",
    "FACULTY": "VEZHAVENDHAN R"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VEZHAVENDHAN R"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "MB110",
    "SLOT": "TE1",
    "FACULTY": "GANGATHARAN C"
}, {
    "CODE": "MGT1022",
    "TITLE": "Lean Start-up Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GANGATHARAN C"
}, {
    "CODE": "STS1021",
    "TITLE": "Introduction to Soft Skills",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV218",
    "SLOT": "F1+TF1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS1021",
    "TITLE": "Introduction to Soft Skills",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV220",
    "SLOT": "F1+TF1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS1021",
    "TITLE": "Introduction to Soft Skills",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV219",
    "SLOT": "F2+TF2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS1021",
    "TITLE": "Introduction to Soft Skills",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV220",
    "SLOT": "F2+TF2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CBMR10\n1",
    "SLOT": "E1+TE1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CBMR30\n1",
    "SLOT": "E1+TE1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT423",
    "SLOT": "E1+TE1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT424",
    "SLOT": "E1+TE1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT434",
    "SLOT": "E1+TE1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT408",
    "SLOT": "E1+TE1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT409",
    "SLOT": "E1+TE1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT415",
    "SLOT": "E1+TE1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT421",
    "SLOT": "E1+TE1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT222",
    "SLOT": "E1+TE1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT423",
    "SLOT": "E1+TE1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT501",
    "SLOT": "E1+TE1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJTG04",
    "SLOT": "E1+TE1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJTG05",
    "SLOT": "E1+TE1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV121",
    "SLOT": "E1+TE1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB111",
    "SLOT": "E1+TE1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB124",
    "SLOT": "E1+TE1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN120",
    "SLOT": "E1+TE1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN121",
    "SLOT": "E1+TE1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN122",
    "SLOT": "E1+TE1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CDMM3\n01",
    "SLOT": "E1+TE1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CDMM3\n02",
    "SLOT": "E1+TE1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT619",
    "SLOT": "E1+TE1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT620",
    "SLOT": "E1+TE1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CTS201",
    "SLOT": "E1+TE1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CTS202",
    "SLOT": "E1+TE1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CBMR10\n1",
    "SLOT": "E2+TE2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CBMR30\n1",
    "SLOT": "E2+TE2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT423",
    "SLOT": "E2+TE2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT424",
    "SLOT": "E2+TE2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT434",
    "SLOT": "E2+TE2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT408",
    "SLOT": "E2+TE2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT409",
    "SLOT": "E2+TE2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT415",
    "SLOT": "E2+TE2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT421",
    "SLOT": "E2+TE2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT422",
    "SLOT": "E2+TE2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT423",
    "SLOT": "E2+TE2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT501",
    "SLOT": "E2+TE2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJTG04",
    "SLOT": "E2+TE2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJTG05",
    "SLOT": "E2+TE2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV121",
    "SLOT": "E2+TE2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB111",
    "SLOT": "E2+TE2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB124",
    "SLOT": "E2+TE2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN120",
    "SLOT": "E2+TE2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN121",
    "SLOT": "E2+TE2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN122",
    "SLOT": "E2+TE2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CDMM3\n01",
    "SLOT": "E2+TE2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CDMM3\n02",
    "SLOT": "E2+TE2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT308",
    "SLOT": "E2+TE2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT620",
    "SLOT": "E2+TE2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT619",
    "SLOT": "E2+TE2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CTS201",
    "SLOT": "E2+TE2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CTS202",
    "SLOT": "E2+TE2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT205",
    "SLOT": "E2+TE2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT825",
    "SLOT": "E2+TE2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CDMM1\n05",
    "SLOT": "E1+TE1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CDMM1\n05",
    "SLOT": "E2+TE2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB102",
    "SLOT": "E1+TE1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB102",
    "SLOT": "E2+TE2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB103",
    "SLOT": "E1+TE1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB103",
    "SLOT": "E2+TE2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT621",
    "SLOT": "E1+TE1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT621",
    "SLOT": "E2+TE2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TTGAL0\n1",
    "SLOT": "E1+TE1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TTGAL0\n1",
    "SLOT": "E2+TE2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CTS301",
    "SLOT": "E2+TE2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2001",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CTS302",
    "SLOT": "E2+TE2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2011",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT207A",
    "SLOT": "G1+TG1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2011",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT208",
    "SLOT": "G1+TG1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2011",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT333",
    "SLOT": "G1+TG1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2011",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT334",
    "SLOT": "G1+TG1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2011",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT603",
    "SLOT": "G1+TG1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2011",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT602A",
    "SLOT": "G1+TG1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2011",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV319",
    "SLOT": "G1+TG1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2011",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT807",
    "SLOT": "G1+TG1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2011",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT707",
    "SLOT": "G1+TG1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2011",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT709",
    "SLOT": "G1+TG1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2021",
    "TITLE": "Fundamentals of Aptitude",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT109",
    "SLOT": "G1+TG1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2021",
    "TITLE": "Fundamentals of Aptitude",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT112",
    "SLOT": "G1+TG1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2021",
    "TITLE": "Fundamentals of Aptitude",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT113",
    "SLOT": "G1+TG1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2021",
    "TITLE": "Fundamentals of Aptitude",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT114",
    "SLOT": "G1+TG1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2021",
    "TITLE": "Fundamentals of Aptitude",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV220",
    "SLOT": "G1+TG1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2021",
    "TITLE": "Fundamentals of Aptitude",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT109",
    "SLOT": "G2+TG2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS2021",
    "TITLE": "Fundamentals of Aptitude",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT112",
    "SLOT": "G2+TG2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2021",
    "TITLE": "Fundamentals of Aptitude",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT113",
    "SLOT": "G2+TG2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS2021",
    "TITLE": "Fundamentals of Aptitude",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT114",
    "SLOT": "G2+TG2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2021",
    "TITLE": "Fundamentals of Aptitude",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV220",
    "SLOT": "G2+TG2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS2021",
    "TITLE": "Fundamentals of Aptitude",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "LIB501",
    "SLOT": "G1+TG1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT104",
    "SLOT": "D1+TD1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT104",
    "SLOT": "D2+TD2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT201",
    "SLOT": "D1+TD1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT201",
    "SLOT": "D2+TD2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT204",
    "SLOT": "D1+TD1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT204",
    "SLOT": "D2+TD2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CBMR10\n1",
    "SLOT": "D1+TD1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CBMR10\n1",
    "SLOT": "D2+TD2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CBMR30\n1",
    "SLOT": "D1+TD1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CBMR30\n1",
    "SLOT": "D2+TD2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT408",
    "SLOT": "D1+TD1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT408",
    "SLOT": "D2+TD2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT409",
    "SLOT": "D1+TD1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT409",
    "SLOT": "D2+TD2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT415",
    "SLOT": "D1+TD1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT415",
    "SLOT": "D2+TD2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT421",
    "SLOT": "D1+TD1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT421",
    "SLOT": "D2+TD2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT422",
    "SLOT": "D1+TD1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT422",
    "SLOT": "D2+TD2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT423",
    "SLOT": "D1+TD1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT423",
    "SLOT": "D2+TD2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT424",
    "SLOT": "D1+TD1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT424",
    "SLOT": "D2+TD2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT501",
    "SLOT": "D1+TD1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT501",
    "SLOT": "D2+TD2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJTG10",
    "SLOT": "D1+TD1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJTG10",
    "SLOT": "D2+TD2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJTG14",
    "SLOT": "D1+TD1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJTG14",
    "SLOT": "D2+TD2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJTG16",
    "SLOT": "D1+TD1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJTG16",
    "SLOT": "D2+TD2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV112",
    "SLOT": "D2+TD2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV116",
    "SLOT": "D1+TD1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV116",
    "SLOT": "D2+TD2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB111",
    "SLOT": "D1+TD1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB111",
    "SLOT": "D2+TD2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB110",
    "SLOT": "D1+TD1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB110",
    "SLOT": "D2+TD2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB102",
    "SLOT": "D1+TD1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB102",
    "SLOT": "D2+TD2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB103",
    "SLOT": "D1+TD1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB103",
    "SLOT": "D2+TD2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB124",
    "SLOT": "D1+TD1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB124",
    "SLOT": "D2+TD2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN120",
    "SLOT": "D1+TD1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN120",
    "SLOT": "D2+TD2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN121",
    "SLOT": "D1+TD1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN121",
    "SLOT": "D2+TD2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN122",
    "SLOT": "D1+TD1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN122",
    "SLOT": "D2+TD2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CDMM3\n01",
    "SLOT": "D1+TD1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CDMM3\n01",
    "SLOT": "D2+TD2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CDMM3\n02",
    "SLOT": "D1+TD1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CDMM3\n02",
    "SLOT": "D2+TD2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT308",
    "SLOT": "D2+TD2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT619",
    "SLOT": "D1+TD1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT619",
    "SLOT": "D2+TD2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT620",
    "SLOT": "D1+TD1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT620",
    "SLOT": "D2+TD2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT621",
    "SLOT": "D1+TD1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT621",
    "SLOT": "D2+TD2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT825",
    "SLOT": "D2+TD2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CDMM1\n05",
    "SLOT": "D1+TD1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CDMM1\n05",
    "SLOT": "D2+TD2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CTS201",
    "SLOT": "D1+TD1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CTS201",
    "SLOT": "D2+TD2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CTS202",
    "SLOT": "D1+TD1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3001",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CTS202",
    "SLOT": "D2+TD2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3003",
    "TITLE": "Soft Skills for Professional Development",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT211",
    "SLOT": "G1+TG1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3003",
    "TITLE": "Soft Skills for Professional Development",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT211A",
    "SLOT": "G1+TG1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3003",
    "TITLE": "Soft Skills for Professional Development",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT825",
    "SLOT": "G1+TG1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3003",
    "TITLE": "Soft Skills for Professional Development",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CTS301",
    "SLOT": "G1+TG1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3003",
    "TITLE": "Soft Skills for Professional Development",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CTS302",
    "SLOT": "G1+TG1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3003",
    "TITLE": "Soft Skills for Professional Development",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT607",
    "SLOT": "G1+TG1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3003",
    "TITLE": "Soft Skills for Professional Development",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT617",
    "SLOT": "G1+TG1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3003",
    "TITLE": "Soft Skills for Professional Development",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV319",
    "SLOT": "G2+TG2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3003",
    "TITLE": "Soft Skills for Professional Development",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT627",
    "SLOT": "G1+TG1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3003",
    "TITLE": "Soft Skills for Professional Development",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT604",
    "SLOT": "G1+TG1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3021",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT118",
    "SLOT": "G1+TG1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3021",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT118",
    "SLOT": "G2+TG2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3021",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT124",
    "SLOT": "G1+TG1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3021",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT124",
    "SLOT": "G2+TG2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3021",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT125",
    "SLOT": "G1+TG1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3021",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT125",
    "SLOT": "G2+TG2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3021",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT126",
    "SLOT": "G1+TG1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3021",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT126",
    "SLOT": "G2+TG2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3021",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV218",
    "SLOT": "G1+TG1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3021",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV218",
    "SLOT": "G2+TG2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3021",
    "TITLE": "Reasoning Skill Enhancement",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "LIB601",
    "SLOT": "G1+TG1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS4021",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT215",
    "SLOT": "G1+TG1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS4021",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT221",
    "SLOT": "G1+TG1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS4021",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT222",
    "SLOT": "G1+TG1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS4021",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV219",
    "SLOT": "G1+TG1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS4021",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT207A",
    "SLOT": "G2+TG2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS4021",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT215",
    "SLOT": "G2+TG2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS4021",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT221",
    "SLOT": "G2+TG2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS4021",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT222",
    "SLOT": "G2+TG2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS4021",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV219",
    "SLOT": "G2+TG2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "CHY6012",
    "TITLE": "Advanced Organic Chemistry",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV128",
    "SLOT": "A1+TA1",
    "FACULTY": "PRIYANKAR PAIRA"
}, {
    "CODE": "CHY6012",
    "TITLE": "Advanced Organic Chemistry",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PRIYANKAR PAIRA"
}, {
    "CODE": "CHY6013",
    "TITLE": "Chemistry of Heterocyclic Compounds",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT112",
    "SLOT": "F1+TF1",
    "FACULTY": "BARNALI MAITI"
}, {
    "CODE": "CHY6013",
    "TITLE": "Chemistry of Heterocyclic Compounds",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BARNALI MAITI"
}, {
    "CODE": "CHY6014",
    "TITLE": "Organic Synthesis and Methodologies",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT112",
    "SLOT": "G1+TG1",
    "FACULTY": "MADHUMITHA G"
}, {
    "CODE": "CHY6015",
    "TITLE": "Photochemistry and Pericyclic\nReactions",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "TT621A",
    "SLOT": "C1+TC1+TCC1",
    "FACULTY": "KARPAGAM S"
}, {
    "CODE": "CHY6016",
    "TITLE": "Organic Chemistry Practical II",
    "TYPE": "LO",
    "CREDITS": "2",
    "VENUE": "TT221",
    "SLOT": "L43+L44+L45+L46",
    "FACULTY": "KARPAGAM S"
}, {
    "CODE": "CHY6017",
    "TITLE": "Organic Chemistry Practical III",
    "TYPE": "LO",
    "CREDITS": "2",
    "VENUE": "TT221",
    "SLOT": "L37+L38+L39+L40",
    "FACULTY": "SUSEEM S.R"
}, {
    "CODE": "CHY6018",
    "TITLE": "Electroanalytical and Separation\nTechniques",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT621A",
    "SLOT": "A1+TA1",
    "FACULTY": "PRABHAKARAN D"
}, {
    "CODE": "CHY6018",
    "TITLE": "Electroanalytical and Separation\nTechniques",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PRABHAKARAN D"
}, {
    "CODE": "CHY6019",
    "TITLE": "Environmental and Industrial Analytical\nChemistry",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT621A",
    "SLOT": "F1+TF1",
    "FACULTY": "ASHARANI I.V"
}, {
    "CODE": "CHY6019",
    "TITLE": "Environmental and Industrial Analytical\nChemistry",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ASHARANI I.V"
}, {
    "CODE": "CHY6020",
    "TITLE": "Bioanalytical and Forensic Analysis",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SMVG11",
    "SLOT": "C1+TC1+TCC1",
    "FACULTY": "ETHIRAJ K R"
}, {
    "CODE": "CHY6021",
    "TITLE": "Analytical Quality Assurance for Process\nIndustry",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT621A",
    "SLOT": "G1+TG1",
    "FACULTY": "SHIVA SHANKAR M"
}, {
    "CODE": "CHY6022",
    "TITLE": "General Organic and Inorganic\nChemistry Practical I",
    "TYPE": "LO",
    "CREDITS": "2",
    "VENUE": "TT221",
    "SLOT": "L49+L50+L51+L52",
    "FACULTY": "SUMATHI S"
}, {
    "CODE": "CHY6023",
    "TITLE": "Analytical Chemistry Practical III",
    "TYPE": "LO",
    "CREDITS": "2",
    "VENUE": "TT535",
    "SLOT": "L31+L32+L33+L34",
    "FACULTY": "SANGEETHA D"
}, {
    "CODE": "CHY6024",
    "TITLE": "Advanced Inorganic Chemistry",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT112",
    "SLOT": "E1+TE1",
    "FACULTY": "THIRUMANAVELAN G"
}, {
    "CODE": "CHY6024",
    "TITLE": "Advanced Inorganic Chemistry",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "THIRUMANAVELAN G"
}, {
    "CODE": "CHY6025",
    "TITLE": "Materials Chemistry",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMVG11",
    "SLOT": "G1+TG1",
    "FACULTY": "SANGEETHA P"
}, {
    "CODE": "CHY6026",
    "TITLE": "Nanomaterials and Characterization\nTechniques",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT112",
    "SLOT": "D1+TD1",
    "FACULTY": "CHERALATHAN K.K."
}, {
    "CODE": "CHY6026",
    "TITLE": "Nanomaterials and Characterization\nTechniques",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "CHERALATHAN K.K."
}, {
    "CODE": "CHY6027",
    "TITLE": "Inorganic Photochemistry",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "TT112",
    "SLOT": "A1+TA1+TAA1",
    "FACULTY": "MADHVESH PATHAK"
}, {
    "CODE": "CHY6028",
    "TITLE": "Inorganic Chemistry Practical II",
    "TYPE": "LO",
    "CREDITS": "2",
    "VENUE": "TT214",
    "SLOT": "L57+L58+L59+L60",
    "FACULTY": "SATISH KUMAR G"
}, {
    "CODE": "CHY6029",
    "TITLE": "Inorganic Chemistry Practical III",
    "TYPE": "LO",
    "CREDITS": "2",
    "VENUE": "TT214",
    "SLOT": "L43+L44+L45+L46",
    "FACULTY": "SOVAN ROY"
}, {
    "CODE": "CHY6036",
    "TITLE": "Advanced Physical Chemistry",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "TT112",
    "SLOT": "C1+TC1+TCC1",
    "FACULTY": "VIJAYANAND C"
}, {
    "CODE": "CHY6039",
    "TITLE": "Analytical and Physical Chemistry\nPractical II",
    "TYPE": "LO",
    "CREDITS": "2",
    "VENUE": "TT535",
    "SLOT": "L37+L38+L39+L40",
    "FACULTY": "SENTHILKUMAR S"
}, {
    "CODE": "MAT1011",
    "TITLE": "Calculus for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT308",
    "SLOT": "B1+TB1",
    "FACULTY": "SARAVANARAJAN M C"
}, {
    "CODE": "MAT1011",
    "TITLE": "Calculus for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT702",
    "SLOT": "D1+TD1",
    "FACULTY": "SARAVANARAJAN M C"
}, {
    "CODE": "MAT1011",
    "TITLE": "Calculus for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT119",
    "SLOT": "L59+L60",
    "FACULTY": "SARAVANARAJAN M C"
}, {
    "CODE": "MAT1011",
    "TITLE": "Calculus for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG16",
    "SLOT": "L51+L52",
    "FACULTY": "SARAVANARAJAN M C"
}, {
    "CODE": "MAT1012",
    "TITLE": "Statistical Applications",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT704",
    "SLOT": "A2",
    "FACULTY": "VENKATARAMANA B"
}, {
    "CODE": "MAT1012",
    "TITLE": "Statistical Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT620",
    "SLOT": "L57+L58",
    "FACULTY": "VENKATARAMANA B"
}, {
    "CODE": "MAT1012",
    "TITLE": "Statistical Applications",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT707",
    "SLOT": "F2",
    "FACULTY": "LAKSHMI NARAYANAN MISHRA"
}, {
    "CODE": "MAT1012",
    "TITLE": "Statistical Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT621",
    "SLOT": "L11+L12",
    "FACULTY": "LAKSHMI NARAYANAN MISHRA"
}, {
    "CODE": "MAT1014",
    "TITLE": "Discrete Mathematics and Graph\nTheory",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT711",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "ASHWIN GANESAN"
}, {
    "CODE": "MAT1014",
    "TITLE": "Discrete Mathematics and Graph\nTheory",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT208",
    "SLOT": "A2+TA2+TAA2+V3",
    "FACULTY": "NALLIAH M"
}, {
    "CODE": "MAT1014",
    "TITLE": "Discrete Mathematics and Graph\nTheory",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT702",
    "SLOT": "A1+TA1+TAA1+V1",
    "FACULTY": "NALLIAH M"
}, {
    "CODE": "MAT1014",
    "TITLE": "Discrete Mathematics and Graph\nTheory",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT712",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "RAMESH KUMAR D"
}, {
    "CODE": "MAT1014",
    "TITLE": "Discrete Mathematics and Graph\nTheory",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT211",
    "SLOT": "A2+TA2+TAA2+V3",
    "FACULTY": "DINESH KUMAR S"
}, {
    "CODE": "MAT1014",
    "TITLE": "Discrete Mathematics and Graph\nTheory",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT715",
    "SLOT": "A1+TA1+TAA1+V1",
    "FACULTY": "DINESH KUMAR S"
}, {
    "CODE": "MAT1016",
    "TITLE": "Applied Discrete Mathematical\nStructures",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT113",
    "SLOT": "A2+TA2+TAA2+V3",
    "FACULTY": "EASWARAMOORTHY"
}, {
    "CODE": "MAT1016",
    "TITLE": "Applied Discrete Mathematical\nStructures",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT113",
    "SLOT": "A1+TA1+TAA1+V1",
    "FACULTY": "EASWARAMOORTHY"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB211",
    "SLOT": "B1+TB1",
    "FACULTY": "GOWSALYA M"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB211",
    "SLOT": "B2+TB2",
    "FACULTY": "MANIMARAN A"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L55+L56",
    "FACULTY": "GOWSALYA M"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L23+L24",
    "FACULTY": "MANIMARAN A"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB212",
    "SLOT": "B1+TB1",
    "FACULTY": "ROY.S"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB212",
    "SLOT": "B2+TB2",
    "FACULTY": "KALPANA PRIYA D"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L53+L54",
    "FACULTY": "RAMESH KUMAR D"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT318",
    "SLOT": "L15+L16",
    "FACULTY": "KALPANA PRIYA D"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT335",
    "SLOT": "D1+TD1",
    "FACULTY": "KAVITHA K"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L35+L36",
    "FACULTY": "MADHU V"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT207A",
    "SLOT": "D2+TD2",
    "FACULTY": "NALLIAH M"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT318",
    "SLOT": "L1+L2",
    "FACULTY": "UDHAYAKUMAR R"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT712",
    "SLOT": "D1+TD1",
    "FACULTY": "EASWARAMOORTHY"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L37+L38",
    "FACULTY": "ROY.S"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT504",
    "SLOT": "D2+TD2",
    "FACULTY": "PURUSOTHAM S"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L7+L8",
    "FACULTY": "SUJATHA V"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT222",
    "SLOT": "F1+TF1",
    "FACULTY": "ANURADHA D"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L57+L58",
    "FACULTY": "ANURADHA D"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT208",
    "SLOT": "F2+TF2",
    "FACULTY": "THILAGAVATHI K"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L19+L20",
    "FACULTY": "KASPAR S"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT223",
    "SLOT": "F1+TF1",
    "FACULTY": "MADHU SUDHAN REDDY K"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L47+L48",
    "FACULTY": "MADHU SUDHAN REDDY K"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT211",
    "SLOT": "F2+TF2",
    "FACULTY": "SUJATHA V"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT118",
    "SLOT": "F1+TF1",
    "FACULTY": "THILAGAVATHI K"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT503",
    "SLOT": "F1+TF1",
    "FACULTY": "GOWRISANKAR A"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT503",
    "SLOT": "F2+TF2",
    "FACULTY": "KASPAR S"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT503",
    "SLOT": "E1+TE1",
    "FACULTY": "JAYALAKSHMI M"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT504",
    "SLOT": "E1+TE1",
    "FACULTY": "MUBASHIR UNNISSA M"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT505",
    "SLOT": "E1+TE1",
    "FACULTY": "KASPAR S"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT503",
    "SLOT": "E2+TE2",
    "FACULTY": "NANDHINI S"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM1\n01",
    "SLOT": "D1+TD1",
    "FACULTY": "UDHAYAKUMAR R"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM1\n01",
    "SLOT": "D2+TD2",
    "FACULTY": "KAVITHA K"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT318",
    "SLOT": "L29+L30",
    "FACULTY": "RAMESH KUMAR D"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT318",
    "SLOT": "L3+L4",
    "FACULTY": "NALLIAH M"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT318",
    "SLOT": "L5+L6",
    "FACULTY": "GOWRISANKAR A"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG16",
    "SLOT": "L7+L8",
    "FACULTY": "DINESH KUMAR S"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT115",
    "SLOT": "G1+TG1",
    "FACULTY": "JAGATHESWARI S"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT504",
    "SLOT": "G1+TG1",
    "FACULTY": "MADHU V"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT208",
    "SLOT": "G2+TG2",
    "FACULTY": "GOWRISANKAR A"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT211",
    "SLOT": "G2+TG2",
    "FACULTY": "KALAIVANI K"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT318",
    "SLOT": "L23+L24",
    "FACULTY": "PURUSOTHAM S"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L1+L2",
    "FACULTY": "NANDHINI S"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L31+L32",
    "FACULTY": "JAGATHESWARI S"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L43+L44",
    "FACULTY": "GOWRISANKAR A"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L45+L46",
    "FACULTY": "JAYALAKSHMI M"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L51+L52",
    "FACULTY": "MUBASHIR UNNISSA M"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L25+L26",
    "FACULTY": "SUJATHA V"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L41+L42",
    "FACULTY": "KAVITHA K"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L49+L50",
    "FACULTY": "THILAGAVATHI K"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L59+L60",
    "FACULTY": "EASWARAMOORTHY"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L9+L10",
    "FACULTY": "THILAGAVATHI K"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT630",
    "SLOT": "D2+TD2",
    "FACULTY": "SUJATHA V"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L33+L34",
    "FACULTY": "UDHAYAKUMAR R"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT505",
    "SLOT": "E2+TE2",
    "FACULTY": "DINESH KUMAR S"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT524",
    "SLOT": "D2+TD2",
    "FACULTY": "RAMESH KUMAR D"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L27+L28",
    "FACULTY": "KAVITHA K"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT211A",
    "SLOT": "F2+TF2",
    "FACULTY": "UDHAYAKUMAR R"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT621",
    "SLOT": "L1+L2",
    "FACULTY": "KALAIVANI K"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT523",
    "SLOT": "D2+TD2",
    "FACULTY": "ANURADHA D"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT318",
    "SLOT": "L9+L10",
    "FACULTY": "ANURADHA D"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT523",
    "SLOT": "D1+TD1",
    "FACULTY": "YOGALAKSHMI T"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT621",
    "SLOT": "L51+L52",
    "FACULTY": "YOGALAKSHMI T"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT524",
    "SLOT": "D1+TD1",
    "FACULTY": "KAVITHA A"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG17",
    "SLOT": "L59+L60",
    "FACULTY": "KAVITHA A"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB213",
    "SLOT": "B1+TB1",
    "FACULTY": "RAMESH KUMAR D"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT621",
    "SLOT": "L53+L54",
    "FACULTY": "KASPAR S"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT712",
    "SLOT": "F1+TF1",
    "FACULTY": "VANITHA R"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG16",
    "SLOT": "L53+L54",
    "FACULTY": "VANITHA R"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT207A",
    "SLOT": "E2+TE2",
    "FACULTY": "JAGATHESWARI S"
}, {
    "CODE": "MAT2001",
    "TITLE": "Statistics for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG15",
    "SLOT": "L1+L2",
    "FACULTY": "JAGATHESWARI S"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB211",
    "SLOT": "F1+TF1",
    "FACULTY": "KARTHIKA K"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG16",
    "SLOT": "L57+L58",
    "FACULTY": "KARTHIKA K"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB211",
    "SLOT": "F2+TF2",
    "FACULTY": "MOUMITA MANDAL"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L5+L6",
    "FACULTY": "MOUMITA MANDAL"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB212",
    "SLOT": "F2+TF2",
    "FACULTY": "SHOBANA DEVI N"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT318",
    "SLOT": "L19+L20",
    "FACULTY": "SHOBANA DEVI N"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB213",
    "SLOT": "F2+TF2",
    "FACULTY": "RAVI SANKAR J"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT318",
    "SLOT": "L7+L8",
    "FACULTY": "RAVI SANKAR J"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM1\n01",
    "SLOT": "B1+TB1",
    "FACULTY": "LAKSHMI NARAYANAN MISHRA"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM1\n01",
    "SLOT": "B2+TB2",
    "FACULTY": "DEEPA G"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM1\n02",
    "SLOT": "B2+TB2",
    "FACULTY": "VIJAYA KUMAR A.G"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT318",
    "SLOT": "L11+L12",
    "FACULTY": "VIJAYA KUMAR A.G"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L29+L30",
    "FACULTY": "RAGHAVENDAR K"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT702",
    "SLOT": "F1+TF1",
    "FACULTY": "MOUMITA MANDAL"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV101",
    "SLOT": "D1+TD1",
    "FACULTY": "MONICA C"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV101",
    "SLOT": "D2+TD2",
    "FACULTY": "RAJASEKARAN G"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV105",
    "SLOT": "D2+TD2",
    "FACULTY": "BALAJI S"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV105",
    "SLOT": "D1+TD1",
    "FACULTY": "ARUNA K"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV109",
    "SLOT": "F1+TF1",
    "FACULTY": "VIJAYA KUMAR A.G"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV109",
    "SLOT": "F2+TF2",
    "FACULTY": "SUBRAMANYAM REDDY"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDNG08",
    "SLOT": "B1+TB1",
    "FACULTY": "OM P.SUTHAR"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDNG08",
    "SLOT": "B2+TB2",
    "FACULTY": "LAKSHMI NARAYANAN MISHRA"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV128",
    "SLOT": "D2+TD2",
    "FACULTY": "RAGHAVENDAR K"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV320",
    "SLOT": "E2+TE2",
    "FACULTY": "SHARIEF BASHA S"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT109",
    "SLOT": "F1+TF1",
    "FACULTY": "SHARIEF BASHA S"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMVG11",
    "SLOT": "E1+TE1",
    "FACULTY": "POORNIMA T"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB111",
    "SLOT": "F1+TF1",
    "FACULTY": "RAVI SANKAR J"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT703",
    "SLOT": "F1+TF1",
    "FACULTY": "ASHISH KUMAR PRASAD"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT114",
    "SLOT": "F2+TF2",
    "FACULTY": "ASHISH KUMAR PRASAD"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMVG11",
    "SLOT": "B1+TB1",
    "FACULTY": "TAMIZHARASI R"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG15",
    "SLOT": "L41+L42",
    "FACULTY": "SHARIEF BASHA S"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG15",
    "SLOT": "L47+L48",
    "FACULTY": "ASHISH KUMAR PRASAD"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG16",
    "SLOT": "L35+L36",
    "FACULTY": "MONICA C"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG15",
    "SLOT": "L53+L54",
    "FACULTY": "PRAVEEN T"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT621",
    "SLOT": "L45+L46",
    "FACULTY": "OM P.SUTHAR"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT621",
    "SLOT": "L23+L24",
    "FACULTY": "BALAJI S"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG15",
    "SLOT": "L59+L60",
    "FACULTY": "ARUNA K"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT621",
    "SLOT": "L13+L14",
    "FACULTY": "DEEPA G"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT603",
    "SLOT": "L13+L14",
    "FACULTY": "LAKSHMI NARAYANAN MISHRA"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG15",
    "SLOT": "L49+L50",
    "FACULTY": "RAVI SANKAR J"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG15",
    "SLOT": "L57+L58",
    "FACULTY": "TAMIZHARASI R"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT621",
    "SLOT": "L55+L56",
    "FACULTY": "VIJAYA KUMAR A.G"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG15",
    "SLOT": "L3+L4",
    "FACULTY": "SHARIEF BASHA S"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT621",
    "SLOT": "L33+L34",
    "FACULTY": "POORNIMA T"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT318",
    "SLOT": "L41+L42",
    "FACULTY": "MOUMITA MANDAL"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "MB117",
    "SLOT": "L59+L60",
    "FACULTY": "LAKSHMI NARAYANAN MISHRA"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "MB114",
    "SLOT": "L5+L6",
    "FACULTY": "SUBRAMANYAM REDDY"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV102",
    "SLOT": "B1+TB1",
    "FACULTY": "PRAVEEN T"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG16",
    "SLOT": "L21+L22",
    "FACULTY": "RAJASEKARAN G"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG16",
    "SLOT": "L19+L20",
    "FACULTY": "ASHISH KUMAR PRASAD"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT211A",
    "SLOT": "D2+TD2",
    "FACULTY": "KARTHIKA K"
}, {
    "CODE": "MAT2002",
    "TITLE": "Applications of Differential and\nDifference Equations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG16",
    "SLOT": "L25+L26",
    "FACULTY": "KARTHIKA K"
}, {
    "CODE": "MAT2003",
    "TITLE": "Operations Research",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CTS202",
    "SLOT": "C1+TC1",
    "FACULTY": "GOWSALYA M"
}, {
    "CODE": "MAT3003",
    "TITLE": "Complex Variables and Partial\nDifferential Equations",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "TT423",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "ARUNA K"
}, {
    "CODE": "MAT3003",
    "TITLE": "Complex Variables and Partial\nDifferential Equations",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "TT424",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "SHOBANA DEVI N"
}, {
    "CODE": "MAT3003",
    "TITLE": "Complex Variables and Partial\nDifferential Equations",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "MB213",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "KALPANA PRIYA D"
}, {
    "CODE": "MAT3003",
    "TITLE": "Complex Variables and Partial\nDifferential Equations",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "TT423",
    "SLOT": "C2+TC2+TCC2+V5",
    "FACULTY": "MUBASHIR UNNISSA M"
}, {
    "CODE": "MAT3003",
    "TITLE": "Complex Variables and Partial\nDifferential Equations",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "MB214",
    "SLOT": "A1+TA1+TAA1+V1",
    "FACULTY": "TAMIZHARASI R"
}, {
    "CODE": "MAT3003",
    "TITLE": "Complex Variables and Partial\nDifferential Equations",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SMV109",
    "SLOT": "C2+TC2+TCC2+V5",
    "FACULTY": "UDHAYAKUMAR R"
}, {
    "CODE": "MAT3003",
    "TITLE": "Complex Variables and Partial\nDifferential Equations",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "TT620",
    "SLOT": "C2+TC2+TCC2+V5",
    "FACULTY": "TAMIZHARASI R"
}, {
    "CODE": "MAT3003",
    "TITLE": "Complex Variables and Partial\nDifferential Equations",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "MB212",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "GOWRISANKAR A"
}, {
    "CODE": "MAT3003",
    "TITLE": "Complex Variables and Partial\nDifferential Equations",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "TT424",
    "SLOT": "C2+TC2+TCC2+V5",
    "FACULTY": "ARUNA K"
}, {
    "CODE": "MAT3003",
    "TITLE": "Complex Variables and Partial\nDifferential Equations",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "CDMM1\n01",
    "SLOT": "A2+TA2+TAA2+V3",
    "FACULTY": "MUBASHIR UNNISSA M"
}, {
    "CODE": "MAT3003",
    "TITLE": "Complex Variables and Partial\nDifferential Equations",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "CDMM1\n02",
    "SLOT": "A2+TA2+TAA2+V3",
    "FACULTY": "KALPANA PRIYA D"
}, {
    "CODE": "MAT3003",
    "TITLE": "Complex Variables and Partial\nDifferential Equations",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SMV123",
    "SLOT": "B2+TB2+TBB2+V4",
    "FACULTY": "SHOBANA DEVI N"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT208",
    "SLOT": "D2+TD2+TDD2+V6",
    "FACULTY": "ROY.S"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT211",
    "SLOT": "C2+TC2+TCC2+V5",
    "FACULTY": "OM P.SUTHAR"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT503",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "MADHU V"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT504",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "KALAIVANI K"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT505",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "MADHU SUDHAN REDDY K"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT508",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "RAVI SANKAR J"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT503",
    "SLOT": "C2+TC2+TCC2+V5",
    "FACULTY": "MADHU V"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT504",
    "SLOT": "C2+TC2+TCC2+V5",
    "FACULTY": "KARTHIKA K"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT505",
    "SLOT": "C2+TC2+TCC2+V5",
    "FACULTY": "MANIMARAN A"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT508",
    "SLOT": "C2+TC2+TCC2+V5",
    "FACULTY": "RAJASEKARAN G"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT503",
    "SLOT": "A1+TA1+TAA1+V1",
    "FACULTY": "BALAJI S"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT504",
    "SLOT": "A1+TA1+TAA1+V1",
    "FACULTY": "KAVITHA A"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT508",
    "SLOT": "A1+TA1+TAA1+V1",
    "FACULTY": "MANIMARAN A"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT503",
    "SLOT": "A2+TA2+TAA2+V3",
    "FACULTY": "DEEPA G"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT504",
    "SLOT": "A2+TA2+TAA2+V3",
    "FACULTY": "BALAJI S"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT505",
    "SLOT": "A2+TA2+TAA2+V3",
    "FACULTY": "MADHU SUDHAN REDDY K"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT508",
    "SLOT": "A2+TA2+TAA2+V3",
    "FACULTY": "KAVITHA A"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT505",
    "SLOT": "A1+TA1+TAA1+V1",
    "FACULTY": "OM P.SUTHAR"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT703",
    "SLOT": "A1+TA1+TAA1+V1",
    "FACULTY": "RAJASEKARAN G"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT703",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "ROY.S"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT703",
    "SLOT": "C2+TC2+TCC2+V5",
    "FACULTY": "DEEPA G"
}, {
    "CODE": "MAT3004",
    "TITLE": "Applied Linear Algebra",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "TT335",
    "SLOT": "D2+TD2+TDD2+V6",
    "FACULTY": "KALAIVANI K"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "MB211",
    "SLOT": "A1+TA1+TAA1+V1",
    "FACULTY": "PURUSOTHAM S"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "MB212",
    "SLOT": "A1+TA1+TAA1+V1",
    "FACULTY": "ASHISH KUMAR PRASAD"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "MB211",
    "SLOT": "A2+TA2+TAA2+V3",
    "FACULTY": "NAGA SATYA SRINIVAS\nAKKIRAJU"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "MB212",
    "SLOT": "A2+TA2+TAA2+V3",
    "FACULTY": "MONICA C"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "MB213",
    "SLOT": "A2+TA2+TAA2+V3",
    "FACULTY": "PRAVEEN T"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "MB214",
    "SLOT": "A2+TA2+TAA2+V3",
    "FACULTY": "NANDHINI S"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "MB218",
    "SLOT": "A2+TA2+TAA2+V3",
    "FACULTY": "BIJU V"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "CDMM1\n01",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "NANDHINI S"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "CDMM1\n01",
    "SLOT": "C2+TC2+TCC2+V5",
    "FACULTY": "PURUSOTHAM S"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT702",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "JAGADEESH KUMAR K"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "TT434",
    "SLOT": "C2+TC2+TCC2+V5",
    "FACULTY": "RAGHAVENDAR K"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "MB213",
    "SLOT": "B2+TB2+TBB2+V4",
    "FACULTY": "BALA ANKI REDDY POL"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "MB218",
    "SLOT": "B2+TB2+TBB2+V4",
    "FACULTY": "SUBRAMANYAM REDDY"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "MB214",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "RAGHAVENDAR K"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "TT434",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "POORNIMA T"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "MB218",
    "SLOT": "A1+TA1+TAA1+V1",
    "FACULTY": "MONICA C"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SMV121",
    "SLOT": "A1+TA1+TAA1+V1",
    "FACULTY": "PRAVEEN T"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT508",
    "SLOT": "B2+TB2+TBB2+V4",
    "FACULTY": "JAGADEESH KUMAR K"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "MB211",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "HEMADRI REDDY REGANTI"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "CDMM1\n02",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "SUBRAMANYAM REDDY"
}, {
    "CODE": "MAT3005",
    "TITLE": "Applied Numerical Methods",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "MB211",
    "SLOT": "C2+TC2+TCC2+V5",
    "FACULTY": "POORNIMA T"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "MB103",
    "SLOT": "TG2",
    "FACULTY": "ANAND A SAMUEL"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANAND A SAMUEL"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT702",
    "SLOT": "TG2",
    "FACULTY": "AKSHAYA KUMAR SWAIN"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AKSHAYA KUMAR SWAIN"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT703",
    "SLOT": "TG2",
    "FACULTY": "USHA RANI M"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "USHA RANI M"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "TT424",
    "SLOT": "TG1",
    "FACULTY": "MURALI R"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MURALI R"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT702",
    "SLOT": "TG1",
    "FACULTY": "SURESH KUMAR VANDRANGI"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SURESH KUMAR VANDRANGI"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT702",
    "SLOT": "TE2",
    "FACULTY": "SURESH KUMAR VANDRANGI"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SURESH KUMAR VANDRANGI"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT703",
    "SLOT": "TG1",
    "FACULTY": "USHA RANI M"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "USHA RANI M"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "TT308",
    "SLOT": "TE1",
    "FACULTY": "MURALI R"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MURALI R"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT715",
    "SLOT": "TG2",
    "FACULTY": "SHOBANA M K"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SHOBANA M K"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT711",
    "SLOT": "TG1",
    "FACULTY": "AKSHAYA KUMAR SWAIN"
}, {
    "CODE": "PHY1999",
    "TITLE": "Introduction to Innovative Projects",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AKSHAYA KUMAR SWAIN"
}, {
    "CODE": "PHY5004",
    "TITLE": "Electromagnetic Theory",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "TT112",
    "SLOT": "A2+TA2+TAA2",
    "FACULTY": "TARUN"
}, {
    "CODE": "PHY6003",
    "TITLE": "Atomic and Molecular Physics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT112",
    "SLOT": "B2+TB2",
    "FACULTY": "UMMAL MOMEEN M"
}, {
    "CODE": "PHY6003",
    "TITLE": "Atomic and Molecular Physics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "UMMAL MOMEEN M"
}, {
    "CODE": "PHY6004",
    "TITLE": "Basic Electronics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT112",
    "SLOT": "E2+TE2",
    "FACULTY": "SENTHUR PANDI R"
}, {
    "CODE": "PHY6004",
    "TITLE": "Basic Electronics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SENTHUR PANDI R"
}, {
    "CODE": "PHY6005",
    "TITLE": "Advanced Solid State Theory",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT112",
    "SLOT": "C2+TC2",
    "FACULTY": "EITHIRAJ RD"
}, {
    "CODE": "PHY6007",
    "TITLE": "Optoelectronics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT112",
    "SLOT": "B1+TB1",
    "FACULTY": "KRISHNA CHANDAR N"
}, {
    "CODE": "PHY6007",
    "TITLE": "Optoelectronics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT343",
    "SLOT": "L15+L16",
    "FACULTY": "KRISHNA CHANDAR N"
}, {
    "CODE": "PHY6008",
    "TITLE": "Laser and Fiber Optics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT112",
    "SLOT": "G2+TG2",
    "FACULTY": "UMA MAHENDRA KUMAR K"
}, {
    "CODE": "BHM1001",
    "TITLE": "Computer Applications",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV320",
    "SLOT": "G2",
    "FACULTY": "FEBIN PRABHU DASS J"
}, {
    "CODE": "BHM1001",
    "TITLE": "Computer Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG15",
    "SLOT": "L19+L20",
    "FACULTY": "FEBIN PRABHU DASS J"
}, {
    "CODE": "BHM1001",
    "TITLE": "Computer Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "FEBIN PRABHU DASS J"
}, {
    "CODE": "BHM2010",
    "TITLE": "Quantity Food Production",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV320",
    "SLOT": "A1",
    "FACULTY": "PRADEEP KUMAR N B"
}, {
    "CODE": "BHM2010",
    "TITLE": "Quantity Food Production",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "SMV301",
    "SLOT": "L43+L44+L45+L46",
    "FACULTY": "PRADEEP KUMAR N B"
}, {
    "CODE": "BHM2010",
    "TITLE": "Quantity Food Production",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PRADEEP KUMAR N B"
}, {
    "CODE": "BHM2011",
    "TITLE": "Beverage Service",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV320",
    "SLOT": "D1",
    "FACULTY": "RAMAKRISHNAN O"
}, {
    "CODE": "BHM2011",
    "TITLE": "Beverage Service",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "SMV301",
    "SLOT": "L57+L58+L59+L60",
    "FACULTY": "RAMAKRISHNAN O"
}, {
    "CODE": "BHM2011",
    "TITLE": "Beverage Service",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMAKRISHNAN O"
}, {
    "CODE": "BHM2015",
    "TITLE": "Hotel Accounts",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV320",
    "SLOT": "F2",
    "FACULTY": "SUNDARAM N"
}, {
    "CODE": "BHM2015",
    "TITLE": "Hotel Accounts",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV306",
    "SLOT": "L25+L26",
    "FACULTY": "SUNDARAM N"
}, {
    "CODE": "BHM2015",
    "TITLE": "Hotel Accounts",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV319",
    "SLOT": "F1",
    "FACULTY": "SUNDARAM N"
}, {
    "CODE": "BHM2015",
    "TITLE": "Hotel Accounts",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV303",
    "SLOT": "L47+L48",
    "FACULTY": "SUNDARAM N"
}, {
    "CODE": "BHM2018",
    "TITLE": "Food and Beverage Services Operations",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV319",
    "SLOT": "C2",
    "FACULTY": "RAMAKRISHNAN O"
}, {
    "CODE": "BHM2018",
    "TITLE": "Food and Beverage Services Operations",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "SMV303",
    "SLOT": "L11+L12+L23+L24",
    "FACULTY": "RAMAKRISHNAN O"
}, {
    "CODE": "BHM2018",
    "TITLE": "Food and Beverage Services Operations",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMAKRISHNAN O"
}, {
    "CODE": "BHM2019",
    "TITLE": "Accommodation Management",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV319",
    "SLOT": "D2",
    "FACULTY": "JESU FREDERICK T"
}, {
    "CODE": "BHM2019",
    "TITLE": "Accommodation Management",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV302",
    "SLOT": "L1+L2",
    "FACULTY": "JESU FREDERICK T"
}, {
    "CODE": "BHM2019",
    "TITLE": "Accommodation Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JESU FREDERICK T"
}, {
    "CODE": "BHM3022",
    "TITLE": "Accommodation and Linen operation",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV320",
    "SLOT": "C1",
    "FACULTY": "JESU FREDERICK T"
}, {
    "CODE": "BHM3022",
    "TITLE": "Accommodation and Linen operation",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV301",
    "SLOT": "L23+L24",
    "FACULTY": "JESU FREDERICK T"
}, {
    "CODE": "BHM3022",
    "TITLE": "Accommodation and Linen operation",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JESU FREDERICK T"
}, {
    "CODE": "BHM3023",
    "TITLE": "Front Office Operations",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV320",
    "SLOT": "B1",
    "FACULTY": "MUTHANANDAM  S"
}, {
    "CODE": "BHM3023",
    "TITLE": "Front Office Operations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV301",
    "SLOT": "L11+L12",
    "FACULTY": "MUTHANANDAM  S"
}, {
    "CODE": "BHM3023",
    "TITLE": "Front Office Operations",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MUTHANANDAM  S"
}, {
    "CODE": "BHM3024",
    "TITLE": "Front Office Management",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV319",
    "SLOT": "A2",
    "FACULTY": "MUTHANANDAM  S"
}, {
    "CODE": "BHM3024",
    "TITLE": "Front Office Management",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV302",
    "SLOT": "L27+L28",
    "FACULTY": "MUTHANANDAM  S"
}, {
    "CODE": "BHM3027",
    "TITLE": "Advanced Food Production",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV319",
    "SLOT": "E2",
    "FACULTY": "MUTHANANDAM  S"
}, {
    "CODE": "BHM3027",
    "TITLE": "Advanced Food Production",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "SMV306",
    "SLOT": "L41+L42+L47+L48",
    "FACULTY": "MUTHANANDAM  S"
}, {
    "CODE": "BHM3027",
    "TITLE": "Advanced Food Production",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MUTHANANDAM  S"
}, {
    "CODE": "BIT1003",
    "TITLE": "Biology for Engineers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV123",
    "SLOT": "G2+TG2",
    "FACULTY": "DEBASISH MISHRA"
}, {
    "CODE": "BIT1003",
    "TITLE": "Biology for Engineers",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG15",
    "SLOT": "L15+L16",
    "FACULTY": "DEBASISH MISHRA"
}, {
    "CODE": "BIT1004",
    "TITLE": "Cell Biology and Biochemistry",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV116",
    "SLOT": "G1+TG1",
    "FACULTY": "KALAIVANI T"
}, {
    "CODE": "BIT1004",
    "TITLE": "Cell Biology and Biochemistry",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV216",
    "SLOT": "L57+L58",
    "FACULTY": "KALAIVANI T"
}, {
    "CODE": "BIT1008",
    "TITLE": "Principles of Chemical Engineering",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV128",
    "SLOT": "G1+TG1",
    "FACULTY": "SHANTHI V"
}, {
    "CODE": "BIT1008",
    "TITLE": "Principles of Chemical Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26\nA",
    "SLOT": "L33+L34",
    "FACULTY": "SHANTHI V"
}, {
    "CODE": "BIT1008",
    "TITLE": "Principles of Chemical Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26\nA",
    "SLOT": "L37+L38",
    "FACULTY": "SHANTHI V"
}, {
    "CODE": "BIT1009",
    "TITLE": "Biobusiness",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV112",
    "SLOT": "A1+TA1",
    "FACULTY": "ANAND PREM RAJAN"
}, {
    "CODE": "BIT1009",
    "TITLE": "Biobusiness",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANAND PREM RAJAN"
}, {
    "CODE": "BIT1009",
    "TITLE": "Biobusiness",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV123",
    "SLOT": "F2+TF2",
    "FACULTY": "ANAND PREM RAJAN"
}, {
    "CODE": "BIT1009",
    "TITLE": "Biobusiness",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANAND PREM RAJAN"
}, {
    "CODE": "BIT1011",
    "TITLE": "Social Entrepreneurship",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV112",
    "SLOT": "A2",
    "FACULTY": "KARTHIKEYAN S"
}, {
    "CODE": "BIT1011",
    "TITLE": "Social Entrepreneurship",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KARTHIKEYAN S"
}, {
    "CODE": "BIT1026",
    "TITLE": "Food, Nutrition and Health",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV116",
    "SLOT": "E2+TE2",
    "FACULTY": "JAYASRI M.A"
}, {
    "CODE": "BIT1026",
    "TITLE": "Food, Nutrition and Health",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV214",
    "SLOT": "G1+TG1",
    "FACULTY": "JAYANTHI S"
}, {
    "CODE": "BIT1026",
    "TITLE": "Food, Nutrition and Health",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV219",
    "SLOT": "F1+TF1",
    "FACULTY": "JAYANTHI S"
}, {
    "CODE": "BIT1026",
    "TITLE": "Food, Nutrition and Health",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV116",
    "SLOT": "A2+TA2",
    "FACULTY": "JAYASRI M.A"
}, {
    "CODE": "BIT1028",
    "TITLE": "Bio-Inspired Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV116",
    "SLOT": "G2+TG2",
    "FACULTY": "SURESH P.K"
}, {
    "CODE": "BIT1028",
    "TITLE": "Bio-Inspired Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SURESH P.K"
}, {
    "CODE": "BIT1028",
    "TITLE": "Bio-Inspired Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV214",
    "SLOT": "F2+TF2",
    "FACULTY": "DEBASISH MISHRA"
}, {
    "CODE": "BIT1028",
    "TITLE": "Bio-Inspired Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DEBASISH MISHRA"
}, {
    "CODE": "BIT1031",
    "TITLE": "System Biology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV121",
    "SLOT": "C1+TC1",
    "FACULTY": "ARNOLD EMERSON I"
}, {
    "CODE": "BIT1031",
    "TITLE": "System Biology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV217",
    "SLOT": "A2+TA2",
    "FACULTY": "ARNOLD EMERSON I"
}, {
    "CODE": "BIT2001",
    "TITLE": "Analytical Bioinformatics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV112",
    "SLOT": "C1+TC1",
    "FACULTY": "SUDHA RAMAIAH"
}, {
    "CODE": "BIT2001",
    "TITLE": "Analytical Bioinformatics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV112",
    "SLOT": "C2+TC2",
    "FACULTY": "ANAND A"
}, {
    "CODE": "BIT2001",
    "TITLE": "Analytical Bioinformatics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG16",
    "SLOT": "L37+L38",
    "FACULTY": "SUDHA RAMAIAH"
}, {
    "CODE": "BIT2001",
    "TITLE": "Analytical Bioinformatics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG16",
    "SLOT": "L5+L6",
    "FACULTY": "ANAND A"
}, {
    "CODE": "BIT2003",
    "TITLE": "Genomics and Proteomics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV217",
    "SLOT": "G2+TG2",
    "FACULTY": "RAJINIRAJA M"
}, {
    "CODE": "BIT2003",
    "TITLE": "Genomics and Proteomics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJINIRAJA M"
}, {
    "CODE": "BIT2003",
    "TITLE": "Genomics and Proteomics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT823",
    "SLOT": "G1+TG1",
    "FACULTY": "RAJINIRAJA M"
}, {
    "CODE": "BIT2003",
    "TITLE": "Genomics and Proteomics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJINIRAJA M"
}, {
    "CODE": "BIT2004",
    "TITLE": "Bioinformatics",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV121",
    "SLOT": "D1",
    "FACULTY": "RAMANATHAN K"
}, {
    "CODE": "BIT2004",
    "TITLE": "Bioinformatics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG15",
    "SLOT": "L51+L52",
    "FACULTY": "RAMANATHAN K"
}, {
    "CODE": "BIT2004",
    "TITLE": "Bioinformatics",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV217",
    "SLOT": "D2",
    "FACULTY": "MOHANA PRIYA A"
}, {
    "CODE": "BIT2004",
    "TITLE": "Bioinformatics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG15",
    "SLOT": "L27+L28",
    "FACULTY": "MOHANA PRIYA A"
}, {
    "CODE": "BIT2005",
    "TITLE": "Analytical Techniques in Biotechnology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV214",
    "SLOT": "F1+TF1",
    "FACULTY": "PRIYANKA SRIVASTAVA"
}, {
    "CODE": "BIT2005",
    "TITLE": "Analytical Techniques in Biotechnology",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "SMV212",
    "SLOT": "L49+L50+L51+L52",
    "FACULTY": "PRIYANKA SRIVASTAVA"
}, {
    "CODE": "BIT2005",
    "TITLE": "Analytical Techniques in Biotechnology",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "SMV212",
    "SLOT": "L49+L50+L51+L52",
    "FACULTY": "SABAREESH V"
}, {
    "CODE": "BIT2005",
    "TITLE": "Analytical Techniques in Biotechnology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV217",
    "SLOT": "F2+TF2",
    "FACULTY": "PRIYANKA SRIVASTAVA"
}, {
    "CODE": "BIT2005",
    "TITLE": "Analytical Techniques in Biotechnology",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "SMV216",
    "SLOT": "L19+L20+L21+L22",
    "FACULTY": "PRIYANKA SRIVASTAVA"
}, {
    "CODE": "BIT2005",
    "TITLE": "Analytical Techniques in Biotechnology",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "SMV216",
    "SLOT": "L19+L20+L21+L22",
    "FACULTY": "DEBASISH MISHRA"
}, {
    "CODE": "BIT2006",
    "TITLE": "Molecular Biology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV121",
    "SLOT": "G1+TG1",
    "FACULTY": "ALKA MEHTA"
}, {
    "CODE": "BIT2006",
    "TITLE": "Molecular Biology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV225",
    "SLOT": "L55+L56",
    "FACULTY": "ALKA MEHTA"
}, {
    "CODE": "BIT2006",
    "TITLE": "Molecular Biology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV225",
    "SLOT": "L55+L56",
    "FACULTY": "TAMIZHSELVI R"
}, {
    "CODE": "BIT2006",
    "TITLE": "Molecular Biology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV121",
    "SLOT": "G2+TG2",
    "FACULTY": "ALKA MEHTA"
}, {
    "CODE": "BIT2006",
    "TITLE": "Molecular Biology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV225",
    "SLOT": "L25+L26",
    "FACULTY": "ALKA MEHTA"
}, {
    "CODE": "BIT2006",
    "TITLE": "Molecular Biology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV225",
    "SLOT": "L25+L26",
    "FACULTY": "ABUL KALAM AZAD MANDAL"
}, {
    "CODE": "BIT2007",
    "TITLE": "Down Stream Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV319",
    "SLOT": "A1+TA1",
    "FACULTY": "SANGEETHA SUBRAMANIAN"
}, {
    "CODE": "BIT2007",
    "TITLE": "Down Stream Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV225",
    "SLOT": "L45+L46",
    "FACULTY": "SANGEETHA SUBRAMANIAN"
}, {
    "CODE": "BIT2008",
    "TITLE": "Immunology and Immunotechnology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV116",
    "SLOT": "B1+TB1",
    "FACULTY": "SUBATHRADEVI C"
}, {
    "CODE": "BIT2008",
    "TITLE": "Immunology and Immunotechnology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV212",
    "SLOT": "L31+L32",
    "FACULTY": "SUBATHRADEVI C"
}, {
    "CODE": "BIT2008",
    "TITLE": "Immunology and Immunotechnology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV212",
    "SLOT": "L31+L32",
    "FACULTY": "RASOOL M"
}, {
    "CODE": "BIT2008",
    "TITLE": "Immunology and Immunotechnology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV116",
    "SLOT": "B2+TB2",
    "FACULTY": "SUBATHRADEVI C"
}, {
    "CODE": "BIT2008",
    "TITLE": "Immunology and Immunotechnology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV212",
    "SLOT": "L21+L22",
    "FACULTY": "SUBATHRADEVI C"
}, {
    "CODE": "BIT2008",
    "TITLE": "Immunology and Immunotechnology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV212",
    "SLOT": "L21+L22",
    "FACULTY": "SURESH P.K"
}, {
    "CODE": "BIT2008",
    "TITLE": "Immunology and Immunotechnology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV116",
    "SLOT": "F1+TF1",
    "FACULTY": "RASOOL M"
}, {
    "CODE": "BIT2008",
    "TITLE": "Immunology and Immunotechnology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV212",
    "SLOT": "L43+L44",
    "FACULTY": "RASOOL M"
}, {
    "CODE": "BIT2008",
    "TITLE": "Immunology and Immunotechnology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV212",
    "SLOT": "L43+L44",
    "FACULTY": "SUBATHRADEVI C"
}, {
    "CODE": "BIT2009",
    "TITLE": "Protein Engineering and Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV235",
    "SLOT": "C1+TC1",
    "FACULTY": "SANJIT KUMAR"
}, {
    "CODE": "BIT2009",
    "TITLE": "Protein Engineering and Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SANJIT KUMAR"
}, {
    "CODE": "BIT2010",
    "TITLE": "Pharmaceutical Biotechnology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV220",
    "SLOT": "E1+TE1",
    "FACULTY": "SIVAKUMAR A"
}, {
    "CODE": "BIT2010",
    "TITLE": "Pharmaceutical Biotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SIVAKUMAR A"
}, {
    "CODE": "BIT2011",
    "TITLE": "Developmental Biology and\nRegenerative Medicine",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV123",
    "SLOT": "E1+TE1",
    "FACULTY": "DEVI RAJESWARI V"
}, {
    "CODE": "BIT2012",
    "TITLE": "Metabolic Engineering",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV235",
    "SLOT": "B1+TB1",
    "FACULTY": "SHAMPA SEN"
}, {
    "CODE": "BIT2013",
    "TITLE": "Industrial Enzymology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV123",
    "SLOT": "D2+TD2",
    "FACULTY": "SHANTHI C"
}, {
    "CODE": "BIT2014",
    "TITLE": "Proteomics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV123",
    "SLOT": "B1+TB1",
    "FACULTY": "JAYARAMAN G"
}, {
    "CODE": "BIT2015",
    "TITLE": "Stem Cell Technology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV235",
    "SLOT": "C2+TC2",
    "FACULTY": "DWAIPAYAN SEN"
}, {
    "CODE": "BIT2015",
    "TITLE": "Stem Cell Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV242",
    "SLOT": "L3+L4",
    "FACULTY": "DWAIPAYAN SEN"
}, {
    "CODE": "BIT2015",
    "TITLE": "Stem Cell Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV242",
    "SLOT": "L9+L10",
    "FACULTY": "DWAIPAYAN SEN"
}, {
    "CODE": "BIT2015",
    "TITLE": "Stem Cell Technology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV123",
    "SLOT": "C1+TC1",
    "FACULTY": "EVERETTE JACOB REMINGTON\nN"
}, {
    "CODE": "BIT2015",
    "TITLE": "Stem Cell Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV242",
    "SLOT": "L45+L46",
    "FACULTY": "EVERETTE JACOB REMINGTON\nN"
}, {
    "CODE": "BIT2015",
    "TITLE": "Stem Cell Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV242",
    "SLOT": "L55+L56",
    "FACULTY": "EVERETTE JACOB REMINGTON\nN"
}, {
    "CODE": "BIT2016",
    "TITLE": "Cancer Biology and Informatics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV121",
    "SLOT": "D2+TD2",
    "FACULTY": "TAMIZHSELVI R"
}, {
    "CODE": "BIT2016",
    "TITLE": "Cancer Biology and Informatics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV112",
    "SLOT": "D1+TD1",
    "FACULTY": "TAMIZHSELVI R"
}, {
    "CODE": "BIT2017",
    "TITLE": "Industrial Biotechnology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV121",
    "SLOT": "F1+TF1",
    "FACULTY": "RAMESH PATHY M"
}, {
    "CODE": "BIT2017",
    "TITLE": "Industrial Biotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMESH PATHY M"
}, {
    "CODE": "BIT2017",
    "TITLE": "Industrial Biotechnology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV121",
    "SLOT": "F2+TF2",
    "FACULTY": "RAMESH PATHY M"
}, {
    "CODE": "BIT2017",
    "TITLE": "Industrial Biotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMESH PATHY M"
}, {
    "CODE": "BIT2018",
    "TITLE": "Food Biotechnology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV112",
    "SLOT": "F2+TF2",
    "FACULTY": "CHITRA KALAICHELVAN"
}, {
    "CODE": "BIT2018",
    "TITLE": "Food Biotechnology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV112",
    "SLOT": "F1+TF1",
    "FACULTY": "RAMALINGAM C"
}, {
    "CODE": "BIT2019",
    "TITLE": "Environmental Biotechnology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV214",
    "SLOT": "B2",
    "FACULTY": "SATHIAVELU A"
}, {
    "CODE": "BIT2019",
    "TITLE": "Environmental Biotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SATHIAVELU A"
}, {
    "CODE": "BIT2020",
    "TITLE": "Chemical Reaction Engineering and Unit\nOperations",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV121",
    "SLOT": "A2+TA2",
    "FACULTY": "RAMANATHAN K"
}, {
    "CODE": "BIT2020",
    "TITLE": "Chemical Reaction Engineering and Unit\nOperations",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV235",
    "SLOT": "A1+TA1",
    "FACULTY": "SHANTHI V"
}, {
    "CODE": "BIT2021",
    "TITLE": "Mass and Heat Transfer Operations",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV214",
    "SLOT": "E2+TE2",
    "FACULTY": "ABHISHEK SINHA"
}, {
    "CODE": "BIT2022",
    "TITLE": "Biomaterials and Artificial Organs",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CBMR30\n1",
    "SLOT": "C2+TC2",
    "FACULTY": "SUGANTHAN V"
}, {
    "CODE": "BIT3004",
    "TITLE": "Nanobiotechnology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV128",
    "SLOT": "A2+TA2",
    "FACULTY": "KALI KISHORE REDDY TETALA"
}, {
    "CODE": "BIT3004",
    "TITLE": "Nanobiotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KALI KISHORE REDDY TETALA"
}, {
    "CODE": "BIT3005",
    "TITLE": "Biological Spectroscopy",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV235",
    "SLOT": "G1+TG1",
    "FACULTY": "PRIYANKAR SEN"
}, {
    "CODE": "BIT3005",
    "TITLE": "Biological Spectroscopy",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PRIYANKAR SEN"
}, {
    "CODE": "BIT3006",
    "TITLE": "Genetic Engineering",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV121",
    "SLOT": "C2+TC2",
    "FACULTY": "SRIDHARAN T B"
}, {
    "CODE": "BIT3006",
    "TITLE": "Genetic Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV216",
    "SLOT": "L13+L14",
    "FACULTY": "SRIDHARAN T B"
}, {
    "CODE": "BIT3006",
    "TITLE": "Genetic Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV216",
    "SLOT": "L13+L14",
    "FACULTY": "RAJASEKARAN C"
}, {
    "CODE": "BIT3006",
    "TITLE": "Genetic Engineering",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV116",
    "SLOT": "C1+TC1",
    "FACULTY": "SIVA R"
}, {
    "CODE": "BIT3006",
    "TITLE": "Genetic Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV216",
    "SLOT": "L37+L38",
    "FACULTY": "SIVA R"
}, {
    "CODE": "BIT3006",
    "TITLE": "Genetic Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV216",
    "SLOT": "L37+L38",
    "FACULTY": "ABUL KALAM AZAD MANDAL"
}, {
    "CODE": "BIT3007",
    "TITLE": "Animal Biotechnology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV128",
    "SLOT": "B1+TB1",
    "FACULTY": "SUDANDIRA DOSS C"
}, {
    "CODE": "BIT3007",
    "TITLE": "Animal Biotechnology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV242",
    "SLOT": "L37+L38",
    "FACULTY": "SUDANDIRA DOSS C"
}, {
    "CODE": "BIT3007",
    "TITLE": "Animal Biotechnology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV242",
    "SLOT": "L43+L44",
    "FACULTY": "SUDANDIRA DOSS C"
}, {
    "CODE": "BIT3008",
    "TITLE": "Plant Biotechnology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV123",
    "SLOT": "E2+TE2",
    "FACULTY": "KALAIVANI T"
}, {
    "CODE": "BIT3008",
    "TITLE": "Plant Biotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KALAIVANI T"
}, {
    "CODE": "BIT3008",
    "TITLE": "Plant Biotechnology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV214",
    "SLOT": "E1+TE1",
    "FACULTY": "DEEPA SANKAR P"
}, {
    "CODE": "BIT3008",
    "TITLE": "Plant Biotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DEEPA SANKAR P"
}, {
    "CODE": "BIT3009",
    "TITLE": "Forensic Science and Technology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV112",
    "SLOT": "G1+TG1",
    "FACULTY": "JAYANTHI A"
}, {
    "CODE": "BIT3009",
    "TITLE": "Forensic Science and Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JAYANTHI A"
}, {
    "CODE": "BIT3009",
    "TITLE": "Forensic Science and Technology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV112",
    "SLOT": "G2+TG2",
    "FACULTY": "JAYANTHI A"
}, {
    "CODE": "BIT3009",
    "TITLE": "Forensic Science and Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JAYANTHI A"
}, {
    "CODE": "BIT3010",
    "TITLE": "Food Process Technology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV116",
    "SLOT": "F2",
    "FACULTY": "RAMALINGAM C"
}, {
    "CODE": "BIT3010",
    "TITLE": "Food Process Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMALINGAM C"
}, {
    "CODE": "BIT3011",
    "TITLE": "Plant Cell and Tissue Culture",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV112",
    "SLOT": "E1",
    "FACULTY": "RAJASEKARAN C"
}, {
    "CODE": "BIT3011",
    "TITLE": "Plant Cell and Tissue Culture",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "SMV225",
    "SLOT": "L31+L32+L33+L34",
    "FACULTY": "RAJASEKARAN C"
}, {
    "CODE": "BIT3011",
    "TITLE": "Plant Cell and Tissue Culture",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "SMV225",
    "SLOT": "L57+L58+L59+L60",
    "FACULTY": "RAJASEKARAN C"
}, {
    "CODE": "BIT3012",
    "TITLE": "Bioprocess Engineering and Bioreactor\nDesign",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV123",
    "SLOT": "A1+TA1",
    "FACULTY": "MRUDULA P"
}, {
    "CODE": "BIT3012",
    "TITLE": "Bioprocess Engineering and Bioreactor\nDesign",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV225",
    "SLOT": "L37+L38",
    "FACULTY": "MRUDULA P"
}, {
    "CODE": "BIT3012",
    "TITLE": "Bioprocess Engineering and Bioreactor\nDesign",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV225",
    "SLOT": "L37+L38",
    "FACULTY": "ABHISHEK SINHA"
}, {
    "CODE": "BIT3012",
    "TITLE": "Bioprocess Engineering and Bioreactor\nDesign",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV123",
    "SLOT": "A2+TA2",
    "FACULTY": "SANGEETHA SUBRAMANIAN"
}, {
    "CODE": "BIT3012",
    "TITLE": "Bioprocess Engineering and Bioreactor\nDesign",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV225",
    "SLOT": "L15+L16",
    "FACULTY": "SANGEETHA SUBRAMANIAN"
}, {
    "CODE": "BIT3012",
    "TITLE": "Bioprocess Engineering and Bioreactor\nDesign",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV225",
    "SLOT": "L15+L16",
    "FACULTY": "MRUDULA P"
}, {
    "CODE": "BIT3012",
    "TITLE": "Bioprocess Engineering and Bioreactor\nDesign",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV217",
    "SLOT": "A1+TA1",
    "FACULTY": "SHAMPA SEN"
}, {
    "CODE": "BIT3012",
    "TITLE": "Bioprocess Engineering and Bioreactor\nDesign",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV225",
    "SLOT": "L49+L50",
    "FACULTY": "SHAMPA SEN"
}, {
    "CODE": "BIT3012",
    "TITLE": "Bioprocess Engineering and Bioreactor\nDesign",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV225",
    "SLOT": "L49+L50",
    "FACULTY": "VENKAT KUMAR S"
}, {
    "CODE": "BIT3015",
    "TITLE": "BioFluid Dynamics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CBMR30\n1",
    "SLOT": "G2+TG2",
    "FACULTY": "SHARMILA N"
}, {
    "CODE": "BIT4002",
    "TITLE": "Medical Diagnostics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV123",
    "SLOT": "C2+TC2",
    "FACULTY": "GUNASEKARAN S"
}, {
    "CODE": "BIT4002",
    "TITLE": "Medical Diagnostics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GUNASEKARAN S"
}, {
    "CODE": "BIT4004",
    "TITLE": "Tissue Engineering",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV123",
    "SLOT": "F1+TF1",
    "FACULTY": "AMIT KUMAR JAISWAL"
}, {
    "CODE": "BIT4004",
    "TITLE": "Tissue Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AMIT KUMAR JAISWAL"
}, {
    "CODE": "BIT4005",
    "TITLE": "Genomics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV123",
    "SLOT": "D1+TD1",
    "FACULTY": "BABU S"
}, {
    "CODE": "BIT499",
    "TITLE": "Project Work",
    "TYPE": "PJT",
    "CREDITS": "20",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "BIT6099",
    "TITLE": "Masters Thesis",
    "TYPE": "PJT",
    "CREDITS": "16",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "BIY1005",
    "TITLE": "General Microbiology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV220",
    "SLOT": "A2",
    "FACULTY": "KAVITHA M"
}, {
    "CODE": "BIY1005",
    "TITLE": "General Microbiology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT106",
    "SLOT": "L1+L2",
    "FACULTY": "KAVITHA M"
}, {
    "CODE": "BIY1005",
    "TITLE": "General Microbiology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KAVITHA M"
}, {
    "CODE": "BIY1005",
    "TITLE": "General Microbiology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT106",
    "SLOT": "L1+L2",
    "FACULTY": "MYTHILI S"
}, {
    "CODE": "BIY1005",
    "TITLE": "General Microbiology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MYTHILI S"
}, {
    "CODE": "BIY1005",
    "TITLE": "General Microbiology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV220",
    "SLOT": "A1",
    "FACULTY": "REENA RAJKUMARI B"
}, {
    "CODE": "BIY1005",
    "TITLE": "General Microbiology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT106",
    "SLOT": "L37+L38",
    "FACULTY": "REENA RAJKUMARI B"
}, {
    "CODE": "BIY1005",
    "TITLE": "General Microbiology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "REENA RAJKUMARI B"
}, {
    "CODE": "BIY1005",
    "TITLE": "General Microbiology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT106",
    "SLOT": "L37+L38",
    "FACULTY": "SABINA E.P"
}, {
    "CODE": "BIY1005",
    "TITLE": "General Microbiology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SABINA E.P"
}, {
    "CODE": "BIY1008",
    "TITLE": "Research Methodology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG16",
    "SLOT": "L43+L44",
    "FACULTY": "ANILKUMAR G"
}, {
    "CODE": "BIY1008",
    "TITLE": "Research Methodology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV218",
    "SLOT": "E2+TE2",
    "FACULTY": "KANNABIRAN K"
}, {
    "CODE": "BIY1008",
    "TITLE": "Research Methodology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG16",
    "SLOT": "L15+L16",
    "FACULTY": "KANNABIRAN K"
}, {
    "CODE": "BIY1008",
    "TITLE": "Research Methodology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV218",
    "SLOT": "E1+TE1",
    "FACULTY": "ANILKUMAR G"
}, {
    "CODE": "BIY1011",
    "TITLE": "Fundamentals of Chemical Engineering",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV220",
    "SLOT": "C1+TC1",
    "FACULTY": "VENKAT KUMAR S"
}, {
    "CODE": "BIY1011",
    "TITLE": "Fundamentals of Chemical Engineering",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV220",
    "SLOT": "C2+TC2",
    "FACULTY": "VENKAT KUMAR S"
}, {
    "CODE": "BIY1012",
    "TITLE": "Bioinformatics",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV220",
    "SLOT": "D1",
    "FACULTY": "RAJASEKARAN R"
}, {
    "CODE": "BIY1012",
    "TITLE": "Bioinformatics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG15",
    "SLOT": "L31+L32",
    "FACULTY": "RAJASEKARAN R"
}, {
    "CODE": "BIY1012",
    "TITLE": "Bioinformatics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJASEKARAN R"
}, {
    "CODE": "BIY1012",
    "TITLE": "Bioinformatics",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV220",
    "SLOT": "D2",
    "FACULTY": "RAJASEKARAN R"
}, {
    "CODE": "BIY1012",
    "TITLE": "Bioinformatics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG15",
    "SLOT": "L7+L8",
    "FACULTY": "RAJASEKARAN R"
}, {
    "CODE": "BIY1012",
    "TITLE": "Bioinformatics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJASEKARAN R"
}, {
    "CODE": "BIY1013",
    "TITLE": "Bioresource Management",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV220",
    "SLOT": "B1",
    "FACULTY": "GODWIN CHRISTOPHER J"
}, {
    "CODE": "BIY1013",
    "TITLE": "Bioresource Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GODWIN CHRISTOPHER J"
}, {
    "CODE": "BIY1013",
    "TITLE": "Bioresource Management",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV220",
    "SLOT": "B2",
    "FACULTY": "GODWIN CHRISTOPHER J"
}, {
    "CODE": "BIY1013",
    "TITLE": "Bioresource Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GODWIN CHRISTOPHER J"
}, {
    "CODE": "BIY1016",
    "TITLE": "Behavioral Sciences",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV116",
    "SLOT": "C2",
    "FACULTY": "SUNITA NAYAK"
}, {
    "CODE": "BIY1016",
    "TITLE": "Behavioral Sciences",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUNITA NAYAK"
}, {
    "CODE": "BIY1020",
    "TITLE": "Vaccinology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV217",
    "SLOT": "E2+TE2",
    "FACULTY": "VINO S"
}, {
    "CODE": "BIY2002",
    "TITLE": "Genetic Engineering",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV112",
    "SLOT": "E2+TE2",
    "FACULTY": "ABUL KALAM AZAD MANDAL"
}, {
    "CODE": "BIY2002",
    "TITLE": "Genetic Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT107",
    "SLOT": "L11+L12",
    "FACULTY": "ABUL KALAM AZAD MANDAL"
}, {
    "CODE": "BIY2002",
    "TITLE": "Genetic Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT107",
    "SLOT": "L11+L12",
    "FACULTY": "SUDHAKARAN R"
}, {
    "CODE": "BIY2003",
    "TITLE": "Bioprocess Principles",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV220",
    "SLOT": "E2+TE2",
    "FACULTY": "VENKAT KUMAR S"
}, {
    "CODE": "BIY2003",
    "TITLE": "Bioprocess Principles",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CTS301",
    "SLOT": "E1+TE1",
    "FACULTY": "ARABI MOHAMMED SALEH\nM.A"
}, {
    "CODE": "BIY2005",
    "TITLE": "Advanced Biochemistry",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV219",
    "SLOT": "C1+TC1",
    "FACULTY": "KANNABIRAN K"
}, {
    "CODE": "BIY2005",
    "TITLE": "Advanced Biochemistry",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV219",
    "SLOT": "C2+TC2",
    "FACULTY": "KANNABIRAN K"
}, {
    "CODE": "BIY2007",
    "TITLE": "Developmental Biology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV219",
    "SLOT": "A1+TA1",
    "FACULTY": "ASHA DEVI S"
}, {
    "CODE": "BIY2007",
    "TITLE": "Developmental Biology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV219",
    "SLOT": "A2+TA2",
    "FACULTY": "ASHA DEVI S"
}, {
    "CODE": "BIY2013",
    "TITLE": "Molecular Endocrinology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV219",
    "SLOT": "D1+TD1",
    "FACULTY": "ANBALAGAN M"
}, {
    "CODE": "BIY2013",
    "TITLE": "Molecular Endocrinology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV219",
    "SLOT": "D2+TD2",
    "FACULTY": "ANBALAGAN M"
}, {
    "CODE": "BIY2014",
    "TITLE": "Aquatic Biotechnology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV235",
    "SLOT": "F2",
    "FACULTY": "SAMANTA SEKHAR KHORA"
}, {
    "CODE": "BIY2014",
    "TITLE": "Aquatic Biotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SAMANTA SEKHAR KHORA"
}, {
    "CODE": "BIY2018",
    "TITLE": "Bioremediation",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV320",
    "SLOT": "F1",
    "FACULTY": "VIMALA R"
}, {
    "CODE": "BIY2018",
    "TITLE": "Bioremediation",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIMALA R"
}, {
    "CODE": "BIY307",
    "TITLE": "Enzyme Technology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV218",
    "SLOT": "D1+TD1",
    "FACULTY": "PRAGASAM V"
}, {
    "CODE": "BIY307",
    "TITLE": "Enzyme Technology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV218",
    "SLOT": "D2+TD2",
    "FACULTY": "PRAGASAM V"
}, {
    "CODE": "BIY404",
    "TITLE": "Protein Engineering",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV218",
    "SLOT": "C1+TC1",
    "FACULTY": "SUDANDIRA DOSS C"
}, {
    "CODE": "BIY410",
    "TITLE": "Nanobiotechnology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV218",
    "SLOT": "C2+TC2",
    "FACULTY": "AMITAVA MUKHERJEE"
}, {
    "CODE": "BIY411",
    "TITLE": "Medical Biotechnology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV235",
    "SLOT": "G2+TG2",
    "FACULTY": "JAYAPRAKASH N S"
}, {
    "CODE": "BIY412",
    "TITLE": "Environmental Biotechnology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV218",
    "SLOT": "B1+TB1",
    "FACULTY": "MYTHILI S"
}, {
    "CODE": "BIY412",
    "TITLE": "Environmental Biotechnology",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "TT106",
    "SLOT": "L31+L32+L33+L34",
    "FACULTY": "MYTHILI S"
}, {
    "CODE": "BIY412",
    "TITLE": "Environmental Biotechnology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV218",
    "SLOT": "B2+TB2",
    "FACULTY": "RAMESH N"
}, {
    "CODE": "BIY412",
    "TITLE": "Environmental Biotechnology",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "TT107",
    "SLOT": "L1+L2+L3+L4",
    "FACULTY": "RAMESH N"
}, {
    "CODE": "BIY413",
    "TITLE": "Bioethics and IPR",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV320",
    "SLOT": "G1+TG1",
    "FACULTY": "CHANDRA SEKARAN N"
}, {
    "CODE": "BIY413",
    "TITLE": "Bioethics and IPR",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV214",
    "SLOT": "G2+TG2",
    "FACULTY": "DANIE KINGSLEY J"
}, {
    "CODE": "BIY415",
    "TITLE": "Techniques in Biotechnology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV235",
    "SLOT": "F1+TF1",
    "FACULTY": "SUDHAKARAN R"
}, {
    "CODE": "BIY415",
    "TITLE": "Techniques in Biotechnology",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "TT107",
    "SLOT": "L57+L58+L59+L60",
    "FACULTY": "SUDHAKARAN R"
}, {
    "CODE": "BIY415",
    "TITLE": "Techniques in Biotechnology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV218",
    "SLOT": "F2+TF2",
    "FACULTY": "PRITI TALWAR"
}, {
    "CODE": "BIY415",
    "TITLE": "Techniques in Biotechnology",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "TT106",
    "SLOT": "L27+L28+L29+L30",
    "FACULTY": "PRITI TALWAR"
}, {
    "CODE": "BIY416",
    "TITLE": "Gene Therapy",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV320",
    "SLOT": "E1+TE1",
    "FACULTY": "EVERETTE JACOB REMINGTON\nN"
}, {
    "CODE": "BIY5001",
    "TITLE": "Animal Biotechnology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV219",
    "SLOT": "B1+TB1",
    "FACULTY": "ASIT RANJAN GHOSH"
}, {
    "CODE": "BIY5001",
    "TITLE": "Animal Biotechnology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV219",
    "SLOT": "B2+TB2",
    "FACULTY": "ASIT RANJAN GHOSH"
}, {
    "CODE": "BIY506",
    "TITLE": "Biological Databases",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV218",
    "SLOT": "A1+TA1",
    "FACULTY": "SAJITHA LULU S"
}, {
    "CODE": "BIY506",
    "TITLE": "Biological Databases",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV218",
    "SLOT": "A2+TA2",
    "FACULTY": "SAJITHA LULU S"
}, {
    "CODE": "BIY508",
    "TITLE": "Transgenic Engineering",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV235",
    "SLOT": "E2+TE2",
    "FACULTY": "KRISHNAN V"
}, {
    "CODE": "BIY599",
    "TITLE": "Student Project",
    "TYPE": "PJT",
    "CREDITS": "20",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "BMG5004",
    "TITLE": "Human Molecular Genetics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV217",
    "SLOT": "F1+TF1",
    "FACULTY": "SONALI SENGUPTA"
}, {
    "CODE": "BMG5006",
    "TITLE": "Advanced Analytical Techniques",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV217",
    "SLOT": "G1+TG1",
    "FACULTY": "SABAREESH V"
}, {
    "CODE": "BMG5008",
    "TITLE": "Cancer Genetics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CTS201",
    "SLOT": "A1+TA1",
    "FACULTY": "VENKATRAMAN M"
}, {
    "CODE": "BMG5012",
    "TITLE": "Forensic Science",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV123",
    "SLOT": "G1",
    "FACULTY": "VENKATRAMAN M"
}, {
    "CODE": "BMG5012",
    "TITLE": "Forensic Science",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VENKATRAMAN M"
}, {
    "CODE": "BMG5013",
    "TITLE": "Stem Cell Biology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV128",
    "SLOT": "D1+TD1",
    "FACULTY": "SURESH P.K"
}, {
    "CODE": "BMG6001",
    "TITLE": "Human Biochemical Genetics",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV219",
    "SLOT": "E1",
    "FACULTY": "SONALI SENGUPTA"
}, {
    "CODE": "BMG6001",
    "TITLE": "Human Biochemical Genetics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SONALI SENGUPTA"
}, {
    "CODE": "BMG6003",
    "TITLE": "Medical Biochemistry",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV319",
    "SLOT": "E1+TE1",
    "FACULTY": "RASOOL M"
}, {
    "CODE": "BMG6004",
    "TITLE": "Genetic Engineering",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV217",
    "SLOT": "C1+TC1",
    "FACULTY": "ASHA DEVI S"
}, {
    "CODE": "BMG6004",
    "TITLE": "Genetic Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT113",
    "SLOT": "L37+L38",
    "FACULTY": "ASHA DEVI S"
}, {
    "CODE": "BMG6005",
    "TITLE": "Genetic Counseling",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV214",
    "SLOT": "B1",
    "FACULTY": "ABILASH V.G"
}, {
    "CODE": "BMG6005",
    "TITLE": "Genetic Counseling",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ABILASH V.G"
}, {
    "CODE": "BMG6006",
    "TITLE": "Ethical, Legal and Social Issues in\nGenetic Counseling",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV217",
    "SLOT": "D1+TD1",
    "FACULTY": "RADHA SARASWATHY"
}, {
    "CODE": "BMG6007",
    "TITLE": "Clinical Rotation",
    "TYPE": "PJT",
    "CREDITS": "2",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "BMG6099",
    "TITLE": "Masters Thesis",
    "TYPE": "PJT",
    "CREDITS": "14",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "BST5006",
    "TITLE": "Tissue Engineering and Regenerative\nMedicine",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV214",
    "SLOT": "C1+TC1",
    "FACULTY": "MANJUBALA I"
}, {
    "CODE": "BST5008",
    "TITLE": "Industrial Biotechnology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV214",
    "SLOT": "C2",
    "FACULTY": "JABEZ OSBORNE W"
}, {
    "CODE": "BST6001",
    "TITLE": "Cancer Biology and Therapeutics",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV128",
    "SLOT": "E2",
    "FACULTY": "VENKATRAMAN M"
}, {
    "CODE": "BST6001",
    "TITLE": "Cancer Biology and Therapeutics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VENKATRAMAN M"
}, {
    "CODE": "BST6004",
    "TITLE": "Forensic Science and Technology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV217",
    "SLOT": "E1",
    "FACULTY": "JAYANTHI A"
}, {
    "CODE": "BST6004",
    "TITLE": "Forensic Science and Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JAYANTHI A"
}, {
    "CODE": "BST6005",
    "TITLE": "Pharmacology and Toxicology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV116",
    "SLOT": "A1+TA1",
    "FACULTY": "PRAGASAM V"
}, {
    "CODE": "BST6007",
    "TITLE": "Nutraceuticals",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV112",
    "SLOT": "B2",
    "FACULTY": "KAVITHA THIRUMURUGAN"
}, {
    "CODE": "BST6007",
    "TITLE": "Nutraceuticals",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT106",
    "SLOT": "L23+L24",
    "FACULTY": "KAVITHA THIRUMURUGAN"
}, {
    "CODE": "BST6007",
    "TITLE": "Nutraceuticals",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KAVITHA THIRUMURUGAN"
}, {
    "CODE": "BST6009",
    "TITLE": "Nanobiotechnology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV214",
    "SLOT": "D2",
    "FACULTY": "RAMESH N"
}, {
    "CODE": "BST6009",
    "TITLE": "Nanobiotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMESH N"
}, {
    "CODE": "BST6012",
    "TITLE": "Plant Biotechnology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV214",
    "SLOT": "A2",
    "FACULTY": "AYESHA NOOR"
}, {
    "CODE": "BST6012",
    "TITLE": "Plant Biotechnology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT107",
    "SLOT": "L23+L24",
    "FACULTY": "AYESHA NOOR"
}, {
    "CODE": "BST6012",
    "TITLE": "Plant Biotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AYESHA NOOR"
}, {
    "CODE": "BST6014",
    "TITLE": "Genomics and Proteomics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV214",
    "SLOT": "D1+TD1",
    "FACULTY": "RAVANAN P"
}, {
    "CODE": "BST6099",
    "TITLE": "Masters Thesis",
    "TYPE": "PJT",
    "CREDITS": "14",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "MSM5008",
    "TITLE": "Food Microbiology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV128",
    "SLOT": "F2+TF2",
    "FACULTY": "NILANJANA MITRA"
}, {
    "CODE": "MSM5008",
    "TITLE": "Food Microbiology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT107",
    "SLOT": "L15+L16",
    "FACULTY": "NILANJANA MITRA"
}, {
    "CODE": "MSM5010",
    "TITLE": "Fermentation Technology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV217",
    "SLOT": "B1",
    "FACULTY": "MOHANASRINIVASAN V"
}, {
    "CODE": "MSM5010",
    "TITLE": "Fermentation Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT106",
    "SLOT": "L39+L40",
    "FACULTY": "MOHANASRINIVASAN V"
}, {
    "CODE": "MSM5010",
    "TITLE": "Fermentation Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MOHANASRINIVASAN V"
}, {
    "CODE": "MSM5010",
    "TITLE": "Fermentation Technology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV217",
    "SLOT": "B2",
    "FACULTY": "MOHANASRINIVASAN V"
}, {
    "CODE": "MSM5010",
    "TITLE": "Fermentation Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT106",
    "SLOT": "L9+L10",
    "FACULTY": "MOHANASRINIVASAN V"
}, {
    "CODE": "MSM5010",
    "TITLE": "Fermentation Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MOHANASRINIVASAN V"
}, {
    "CODE": "MSM5012",
    "TITLE": "Pharmaceutical Biotechnology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV128",
    "SLOT": "F1",
    "FACULTY": "VINO S"
}, {
    "CODE": "MSM5012",
    "TITLE": "Pharmaceutical Biotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VINO S"
}, {
    "CODE": "MSM5013",
    "TITLE": "Soil and Agricultural Microbiology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV128",
    "SLOT": "C1+TC1",
    "FACULTY": "NILANJANA MITRA"
}, {
    "CODE": "MSM5018",
    "TITLE": "Bioinformatics",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV214",
    "SLOT": "A1",
    "FACULTY": "GEORGE PRIYA DOSS C"
}, {
    "CODE": "MSM5018",
    "TITLE": "Bioinformatics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG15",
    "SLOT": "L11+L12",
    "FACULTY": "GEORGE PRIYA DOSS C"
}, {
    "CODE": "MSM5018",
    "TITLE": "Bioinformatics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GEORGE PRIYA DOSS C"
}, {
    "CODE": "MSM5018",
    "TITLE": "Bioinformatics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG15",
    "SLOT": "L11+L12",
    "FACULTY": "ABILASH V.G"
}, {
    "CODE": "MSM5018",
    "TITLE": "Bioinformatics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ABILASH V.G"
}, {
    "CODE": "MSM6004",
    "TITLE": "Industrial Microbiology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV128",
    "SLOT": "E1+TE1",
    "FACULTY": "MYTHILI S"
}, {
    "CODE": "MSM6099",
    "TITLE": "Masters Thesis",
    "TYPE": "PJT",
    "CREDITS": "14",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "RES5001",
    "TITLE": "Research Methodology",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "SMV235",
    "SLOT": "D1",
    "FACULTY": "PRIYANKAR PAIRA"
}, {
    "CODE": "CHE1004",
    "TITLE": "Chemical Technology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV101",
    "SLOT": "B1+TB1",
    "FACULTY": "ASLAM ABDULLAH M"
}, {
    "CODE": "CHE1004",
    "TITLE": "Chemical Technology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV104",
    "SLOT": "A2+TA2",
    "FACULTY": "MAHESH GANESAPILLAI"
}, {
    "CODE": "CHE1005",
    "TITLE": "Momentum Transfer",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV101",
    "SLOT": "A1+TA1",
    "FACULTY": "DHARMENDRA KUMAR BAL"
}, {
    "CODE": "CHE1005",
    "TITLE": "Momentum Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L33+L34",
    "FACULTY": "DHARMENDRA KUMAR BAL"
}, {
    "CODE": "CHE1005",
    "TITLE": "Momentum Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L33+L34",
    "FACULTY": "ARUNA SINGH"
}, {
    "CODE": "CHE1005",
    "TITLE": "Momentum Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L49+L50",
    "FACULTY": "DHARMENDRA KUMAR BAL"
}, {
    "CODE": "CHE1005",
    "TITLE": "Momentum Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L49+L50",
    "FACULTY": "MAHESH GANESAPILLAI"
}, {
    "CODE": "CHE1007",
    "TITLE": "Safety and Hazard Analysis",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV101",
    "SLOT": "G1",
    "FACULTY": "BABU PONNUSAMI A"
}, {
    "CODE": "CHE1007",
    "TITLE": "Safety and Hazard Analysis",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BABU PONNUSAMI A"
}, {
    "CODE": "CHE1007",
    "TITLE": "Safety and Hazard Analysis",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV102",
    "SLOT": "C1",
    "FACULTY": "JAYKUMAR BABA BHASARKAR"
}, {
    "CODE": "CHE1007",
    "TITLE": "Safety and Hazard Analysis",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JAYKUMAR BABA BHASARKAR"
}, {
    "CODE": "CHE1008",
    "TITLE": "Unit Processes in Organic Synthesis",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV104",
    "SLOT": "E1+TE1",
    "FACULTY": "MOHANA ROOPAN S"
}, {
    "CODE": "CHE1008",
    "TITLE": "Unit Processes in Organic Synthesis",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG02\n7",
    "SLOT": "L31+L32",
    "FACULTY": "MOHANA ROOPAN S"
}, {
    "CODE": "CHE1008",
    "TITLE": "Unit Processes in Organic Synthesis",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG02\n7",
    "SLOT": "L31+L32",
    "FACULTY": "SHIVA SHANKAR M"
}, {
    "CODE": "CHE1010",
    "TITLE": "Process Plant Utilities",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV104",
    "SLOT": "G1+TG1",
    "FACULTY": "SHISHIR KUMAR BEHERA"
}, {
    "CODE": "CHE1011",
    "TITLE": "Optimization of Chemical Processes",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV104",
    "SLOT": "D1+TD1",
    "FACULTY": "JAYKUMAR BABA BHASARKAR"
}, {
    "CODE": "CHE1013",
    "TITLE": "Natural Gas Engineering",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV104",
    "SLOT": "F1+TF1",
    "FACULTY": "ASLAM ABDULLAH M"
}, {
    "CODE": "CHE1014",
    "TITLE": "Petroleum Technology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV101",
    "SLOT": "E1+TE1",
    "FACULTY": "NIRMALA G S"
}, {
    "CODE": "CHE1015",
    "TITLE": "Petrochemical Technology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV104",
    "SLOT": "B2+TB2",
    "FACULTY": "ASLAM ABDULLAH M"
}, {
    "CODE": "CHE1016",
    "TITLE": "Fermentation Technology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV101",
    "SLOT": "G2+TG2",
    "FACULTY": "NAGAMALLESWARA RAO K"
}, {
    "CODE": "CHE1017",
    "TITLE": "Food Process Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV102",
    "SLOT": "F1",
    "FACULTY": "ARUNA SINGH"
}, {
    "CODE": "CHE1017",
    "TITLE": "Food Process Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ARUNA SINGH"
}, {
    "CODE": "CHE1019",
    "TITLE": "Polymer Technology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV319",
    "SLOT": "B1+TB1",
    "FACULTY": "MONASH P"
}, {
    "CODE": "CHE1020",
    "TITLE": "Fertilizer Technology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV102",
    "SLOT": "G1+TG1",
    "FACULTY": "VELU S"
}, {
    "CODE": "CHE1022",
    "TITLE": "Mechanical Operations",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV101",
    "SLOT": "C1+TC1",
    "FACULTY": "MAHESH GANESAPILLAI"
}, {
    "CODE": "CHE1022",
    "TITLE": "Mechanical Operations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG29",
    "SLOT": "L37+L38",
    "FACULTY": "MAHESH GANESAPILLAI"
}, {
    "CODE": "CHE1022",
    "TITLE": "Mechanical Operations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG29",
    "SLOT": "L37+L38",
    "FACULTY": "NIRMALA G S"
}, {
    "CODE": "CHE1022",
    "TITLE": "Mechanical Operations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG29",
    "SLOT": "L47+L48",
    "FACULTY": "MAHESH GANESAPILLAI"
}, {
    "CODE": "CHE1022",
    "TITLE": "Mechanical Operations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG29",
    "SLOT": "L47+L48",
    "FACULTY": "NIRMALA G S"
}, {
    "CODE": "CHE1023",
    "TITLE": "Production and Operations\nManagement",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV101",
    "SLOT": "C2+TC2",
    "FACULTY": "MOHAMMED REHAAN\nCHANDAN"
}, {
    "CODE": "CHE2001",
    "TITLE": "Chemical Reaction Engineering",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV102",
    "SLOT": "E1+TE1",
    "FACULTY": "AABID HUSSAIN SHAIK"
}, {
    "CODE": "CHE2001",
    "TITLE": "Chemical Reaction Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV127",
    "SLOT": "L51+L52",
    "FACULTY": "AABID HUSSAIN SHAIK"
}, {
    "CODE": "CHE2001",
    "TITLE": "Chemical Reaction Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV127",
    "SLOT": "L51+L52",
    "FACULTY": "MURUGANANDAM L"
}, {
    "CODE": "CHE2001",
    "TITLE": "Chemical Reaction Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV127",
    "SLOT": "L37+L38",
    "FACULTY": "AABID HUSSAIN SHAIK"
}, {
    "CODE": "CHE2001",
    "TITLE": "Chemical Reaction Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV127",
    "SLOT": "L37+L38",
    "FACULTY": "MURUGANANDAM L"
}, {
    "CODE": "CHE2002",
    "TITLE": "Process Equipment Design and\nEconomics",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV101",
    "SLOT": "A2",
    "FACULTY": "ARUNA SINGH"
}, {
    "CODE": "CHE2002",
    "TITLE": "Process Equipment Design and\nEconomics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG31",
    "SLOT": "L11+L12",
    "FACULTY": "ARUNA SINGH"
}, {
    "CODE": "CHE2002",
    "TITLE": "Process Equipment Design and\nEconomics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ARUNA SINGH"
}, {
    "CODE": "CHE2002",
    "TITLE": "Process Equipment Design and\nEconomics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG31",
    "SLOT": "L11+L12",
    "FACULTY": "NIRMALA G S"
}, {
    "CODE": "CHE2002",
    "TITLE": "Process Equipment Design and\nEconomics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NIRMALA G S"
}, {
    "CODE": "CHE2002",
    "TITLE": "Process Equipment Design and\nEconomics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG31",
    "SLOT": "L29+L30",
    "FACULTY": "ARUNA SINGH"
}, {
    "CODE": "CHE2002",
    "TITLE": "Process Equipment Design and\nEconomics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ARUNA SINGH"
}, {
    "CODE": "CHE2003",
    "TITLE": "Chemical Product Design",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMVG33",
    "SLOT": "D1+TD1",
    "FACULTY": "ANAND VEERABADRA PRASAD\nGURUMOORTHY"
}, {
    "CODE": "CHE2006",
    "TITLE": "Fuels and Combustion",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV102",
    "SLOT": "B2+TB2",
    "FACULTY": "VELU S"
}, {
    "CODE": "CHE2006",
    "TITLE": "Fuels and Combustion",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV105",
    "SLOT": "G2+TG2",
    "FACULTY": "JAYKUMAR BABA BHASARKAR"
}, {
    "CODE": "CHE2006",
    "TITLE": "Fuels and Combustion",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV105",
    "SLOT": "E1+TE1",
    "FACULTY": "CHITRA D"
}, {
    "CODE": "CHE3001",
    "TITLE": "Computational Methods in Process\nEngineering",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV102",
    "SLOT": "A1+TA1",
    "FACULTY": "MONASH P"
}, {
    "CODE": "CHE3001",
    "TITLE": "Computational Methods in Process\nEngineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG31",
    "SLOT": "L31+L32",
    "FACULTY": "MONASH P"
}, {
    "CODE": "CHE3001",
    "TITLE": "Computational Methods in Process\nEngineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG31",
    "SLOT": "L41+L42",
    "FACULTY": "MONASH P"
}, {
    "CODE": "CHE3001",
    "TITLE": "Computational Methods in Process\nEngineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG31",
    "SLOT": "L41+L42",
    "FACULTY": "MURUGANANDAM L"
}, {
    "CODE": "CHE3002",
    "TITLE": "Process Instrumentation and Control",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV104",
    "SLOT": "C1",
    "FACULTY": "BABU PONNUSAMI A"
}, {
    "CODE": "CHE3002",
    "TITLE": "Process Instrumentation and Control",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26\nA",
    "SLOT": "L55+L56",
    "FACULTY": "BABU PONNUSAMI A"
}, {
    "CODE": "CHE3002",
    "TITLE": "Process Instrumentation and Control",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BABU PONNUSAMI A"
}, {
    "CODE": "CHE3002",
    "TITLE": "Process Instrumentation and Control",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26\nA",
    "SLOT": "L55+L56",
    "FACULTY": "CHITRA D"
}, {
    "CODE": "CHE3002",
    "TITLE": "Process Instrumentation and Control",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "CHITRA D"
}, {
    "CODE": "CHE3002",
    "TITLE": "Process Instrumentation and Control",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26\nA",
    "SLOT": "L39+L40",
    "FACULTY": "BABU PONNUSAMI A"
}, {
    "CODE": "CHE3002",
    "TITLE": "Process Instrumentation and Control",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BABU PONNUSAMI A"
}, {
    "CODE": "CHE3003",
    "TITLE": "Mass Transfer",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV102",
    "SLOT": "D1+TD1",
    "FACULTY": "NIRMALA G S"
}, {
    "CODE": "CHE4001",
    "TITLE": "Equilibrium Staged Operations",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV104",
    "SLOT": "B1",
    "FACULTY": "MOHAMMED REHAAN\nCHANDAN"
}, {
    "CODE": "CHE4001",
    "TITLE": "Equilibrium Staged Operations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV127",
    "SLOT": "L45+L46",
    "FACULTY": "MOHAMMED REHAAN\nCHANDAN"
}, {
    "CODE": "CHE4001",
    "TITLE": "Equilibrium Staged Operations",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MOHAMMED REHAAN\nCHANDAN"
}, {
    "CODE": "CHE4001",
    "TITLE": "Equilibrium Staged Operations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV127",
    "SLOT": "L45+L46",
    "FACULTY": "BABU PONNUSAMI A"
}, {
    "CODE": "CHE4001",
    "TITLE": "Equilibrium Staged Operations",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BABU PONNUSAMI A"
}, {
    "CODE": "CHE4001",
    "TITLE": "Equilibrium Staged Operations",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMV127",
    "SLOT": "L49+L50",
    "FACULTY": "MOHAMMED REHAAN\nCHANDAN"
}, {
    "CODE": "CHE4001",
    "TITLE": "Equilibrium Staged Operations",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MOHAMMED REHAAN\nCHANDAN"
}, {
    "CODE": "CHE4002",
    "TITLE": "Transport Phenomena",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV104",
    "SLOT": "A1+TA1",
    "FACULTY": "MURUGANANDAM L"
}, {
    "CODE": "CLE1003",
    "TITLE": "Surveying",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV109",
    "SLOT": "G1+TG1",
    "FACULTY": "SAIRAM V"
}, {
    "CODE": "CLE1003",
    "TITLE": "Surveying",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG06",
    "SLOT": "L1+L2",
    "FACULTY": "SAIRAM V"
}, {
    "CODE": "CLE1003",
    "TITLE": "Surveying",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SAIRAM V"
}, {
    "CODE": "CLE1004",
    "TITLE": "Soil Mechanics and Foundation\nEngineering",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMVG11",
    "SLOT": "A1+TA1",
    "FACULTY": "VISUVASAM J"
}, {
    "CODE": "CLE1004",
    "TITLE": "Soil Mechanics and Foundation\nEngineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG04",
    "SLOT": "L31+L32",
    "FACULTY": "VISUVASAM J"
}, {
    "CODE": "CLE1004",
    "TITLE": "Soil Mechanics and Foundation\nEngineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG04",
    "SLOT": "L43+L44",
    "FACULTY": "VISUVASAM J"
}, {
    "CODE": "CLE1004",
    "TITLE": "Soil Mechanics and Foundation\nEngineering",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMVG11",
    "SLOT": "C2+TC2",
    "FACULTY": "CHANDRASEKARAN S.S"
}, {
    "CODE": "CLE1004",
    "TITLE": "Soil Mechanics and Foundation\nEngineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG04",
    "SLOT": "L5+L6",
    "FACULTY": "CHANDRASEKARAN S.S"
}, {
    "CODE": "CLE1004",
    "TITLE": "Soil Mechanics and Foundation\nEngineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG04",
    "SLOT": "L11+L12",
    "FACULTY": "CHANDRASEKARAN S.S"
}, {
    "CODE": "CLE1004",
    "TITLE": "Soil Mechanics and Foundation\nEngineering",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMVG11",
    "SLOT": "F1+TF1",
    "FACULTY": "CHANDRASEKARAN S.S"
}, {
    "CODE": "CLE1004",
    "TITLE": "Soil Mechanics and Foundation\nEngineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG04",
    "SLOT": "L37+L38",
    "FACULTY": "CHANDRASEKARAN S.S"
}, {
    "CODE": "CLE1004",
    "TITLE": "Soil Mechanics and Foundation\nEngineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG04",
    "SLOT": "L49+L50",
    "FACULTY": "CHANDRASEKARAN S.S"
}, {
    "CODE": "CLE1004",
    "TITLE": "Soil Mechanics and Foundation\nEngineering",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMVG11",
    "SLOT": "G2+TG2",
    "FACULTY": "VISUVASAM J"
}, {
    "CODE": "CLE1004",
    "TITLE": "Soil Mechanics and Foundation\nEngineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG04",
    "SLOT": "L23+L24",
    "FACULTY": "VISUVASAM J"
}, {
    "CODE": "CLE1004",
    "TITLE": "Soil Mechanics and Foundation\nEngineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG04",
    "SLOT": "L29+L30",
    "FACULTY": "VISUVASAM J"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM3\n04",
    "SLOT": "F2",
    "FACULTY": "PAVAN KUMAR KUMMAMURU"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN142",
    "SLOT": "L5+L6",
    "FACULTY": "PAVAN KUMAR KUMMAMURU"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PAVAN KUMAR KUMMAMURU"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN142",
    "SLOT": "L11+L12",
    "FACULTY": "PAVAN KUMAR KUMMAMURU"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PAVAN KUMAR KUMMAMURU"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV101",
    "SLOT": "F1",
    "FACULTY": "PARIMALA RENGANAYAKI S"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV101",
    "SLOT": "F2",
    "FACULTY": "PARIMALA RENGANAYAKI S"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV105",
    "SLOT": "C2",
    "FACULTY": "RANJITHA"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV109",
    "SLOT": "C1",
    "FACULTY": "BHASKAR DAS"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN142",
    "SLOT": "L37+L38",
    "FACULTY": "BHASKAR DAS"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BHASKAR DAS"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN142",
    "SLOT": "L49+L50",
    "FACULTY": "BHASKAR DAS"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BHASKAR DAS"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN142",
    "SLOT": "L23+L24",
    "FACULTY": "PARIMALA RENGANAYAKI S"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PARIMALA RENGANAYAKI S"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN142",
    "SLOT": "L29+L30",
    "FACULTY": "PARIMALA RENGANAYAKI S"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PARIMALA RENGANAYAKI S"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN142",
    "SLOT": "L43+L44",
    "FACULTY": "PARIMALA RENGANAYAKI S"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PARIMALA RENGANAYAKI S"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN142",
    "SLOT": "L41+L42",
    "FACULTY": "PARIMALA RENGANAYAKI S"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PARIMALA RENGANAYAKI S"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN142",
    "SLOT": "L19+L20",
    "FACULTY": "RANJITHA"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RANJITHA"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN142",
    "SLOT": "L25+L26",
    "FACULTY": "RANJITHA"
}, {
    "CODE": "CLE1006",
    "TITLE": "Environmental Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RANJITHA"
}, {
    "CODE": "CLE1010",
    "TITLE": "Natural Disaster Mitigation and\nManagement",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n04A",
    "SLOT": "E1+TE1",
    "FACULTY": "VAANI N"
}, {
    "CODE": "CLE1010",
    "TITLE": "Natural Disaster Mitigation and\nManagement",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n04",
    "SLOT": "E1+TE1",
    "FACULTY": "KIRAN YARRAKULA"
}, {
    "CODE": "CLE1010",
    "TITLE": "Natural Disaster Mitigation and\nManagement",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n02",
    "SLOT": "C2+TC2",
    "FACULTY": "GANAPATHY G.P"
}, {
    "CODE": "CLE1010",
    "TITLE": "Natural Disaster Mitigation and\nManagement",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n01",
    "SLOT": "G1+TG1",
    "FACULTY": "MALATHY  J"
}, {
    "CODE": "CLE1011",
    "TITLE": "Engineering Geology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM3\n02",
    "SLOT": "G1",
    "FACULTY": "DILLIP KUMAR BARIK"
}, {
    "CODE": "CLE1011",
    "TITLE": "Engineering Geology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DILLIP KUMAR BARIK"
}, {
    "CODE": "CLE1011",
    "TITLE": "Engineering Geology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV109",
    "SLOT": "E1",
    "FACULTY": "PORCHELVAN P"
}, {
    "CODE": "CLE1011",
    "TITLE": "Engineering Geology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PORCHELVAN P"
}, {
    "CODE": "CLE1013",
    "TITLE": "Environmental Impact Assessment",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n02",
    "SLOT": "A2+TA2",
    "FACULTY": "VELVIZHI G"
}, {
    "CODE": "CLE1013",
    "TITLE": "Environmental Impact Assessment",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n01",
    "SLOT": "A1+TA1",
    "FACULTY": "KAVITHA M.S"
}, {
    "CODE": "CLE2001",
    "TITLE": "Building Drawing",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SMV101",
    "SLOT": "TG1",
    "FACULTY": "SUGANYA OM"
}, {
    "CODE": "CLE2001",
    "TITLE": "Building Drawing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN153",
    "SLOT": "L39+L40",
    "FACULTY": "SUGANYA OM"
}, {
    "CODE": "CLE2001",
    "TITLE": "Building Drawing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUGANYA OM"
}, {
    "CODE": "CLE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n03",
    "SLOT": "A2+TA2+V3",
    "FACULTY": "MEENA T"
}, {
    "CODE": "CLE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L25+L26",
    "FACULTY": "MEENA T"
}, {
    "CODE": "CLE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n03",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "AJEESH S S"
}, {
    "CODE": "CLE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L29+L30",
    "FACULTY": "AJEESH S S"
}, {
    "CODE": "CLE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L53+L54",
    "FACULTY": "RAMA MOHAN RAO P"
}, {
    "CODE": "CLE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n04",
    "SLOT": "A1+TA1+TAA1",
    "FACULTY": "THIRUMALINI S"
}, {
    "CODE": "CLE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n01",
    "SLOT": "A2+TA2+TAA2",
    "FACULTY": "SAIRAM V"
}, {
    "CODE": "CLE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n04A",
    "SLOT": "C1+TC1+TCC1",
    "FACULTY": "VISWANATHAN T S"
}, {
    "CODE": "CLE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L13+L14",
    "FACULTY": "SAIRAM V"
}, {
    "CODE": "CLE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L39+L40",
    "FACULTY": "THIRUMALINI S"
}, {
    "CODE": "CLE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L15+L16",
    "FACULTY": "THIRUMALINI S"
}, {
    "CODE": "CLE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L55+L56",
    "FACULTY": "VISWANATHAN T S"
}, {
    "CODE": "CLE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n04",
    "SLOT": "D2+TD2+TDD2",
    "FACULTY": "THIRUMALINI S"
}, {
    "CODE": "CLE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n03",
    "SLOT": "B2+TB2+V4",
    "FACULTY": "RAMA MOHAN RAO P"
}, {
    "CODE": "CLE2003",
    "TITLE": "Structural Analysis",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n04A",
    "SLOT": "A2+TA2+TAA2",
    "FACULTY": "HAREESH M"
}, {
    "CODE": "CLE2003",
    "TITLE": "Structural Analysis",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n04",
    "SLOT": "A2+TA2+V3",
    "FACULTY": "SUNEEL KUMAR M"
}, {
    "CODE": "CLE2003",
    "TITLE": "Structural Analysis",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n04",
    "SLOT": "B2+TB2+V4",
    "FACULTY": "SANTHI A.S"
}, {
    "CODE": "CLE2003",
    "TITLE": "Structural Analysis",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDNG08",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "SANTHI A.S"
}, {
    "CODE": "CLE2004",
    "TITLE": "Water Resource Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM3\n04",
    "SLOT": "G1",
    "FACULTY": "JAGADEESH P"
}, {
    "CODE": "CLE2004",
    "TITLE": "Water Resource Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN153",
    "SLOT": "L55+L56",
    "FACULTY": "JAGADEESH P"
}, {
    "CODE": "CLE2004",
    "TITLE": "Water Resource Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JAGADEESH P"
}, {
    "CODE": "CLE2004",
    "TITLE": "Water Resource Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM3\n04",
    "SLOT": "F1",
    "FACULTY": "DILLIP KUMAR BARIK"
}, {
    "CODE": "CLE2004",
    "TITLE": "Water Resource Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM3\n04",
    "SLOT": "E2",
    "FACULTY": "DILLIP KUMAR BARIK"
}, {
    "CODE": "CLE2004",
    "TITLE": "Water Resource Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN153",
    "SLOT": "L23+L24",
    "FACULTY": "DILLIP KUMAR BARIK"
}, {
    "CODE": "CLE2004",
    "TITLE": "Water Resource Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DILLIP KUMAR BARIK"
}, {
    "CODE": "CLE2004",
    "TITLE": "Water Resource Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN153",
    "SLOT": "L53+L54",
    "FACULTY": "DILLIP KUMAR BARIK"
}, {
    "CODE": "CLE2004",
    "TITLE": "Water Resource Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DILLIP KUMAR BARIK"
}, {
    "CODE": "CLE2005",
    "TITLE": "Transportation Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM3\n04",
    "SLOT": "G2",
    "FACULTY": "VASANTHA KUMAR S"
}, {
    "CODE": "CLE2005",
    "TITLE": "Transportation Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VASANTHA KUMAR S"
}, {
    "CODE": "CLE2005",
    "TITLE": "Transportation Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM3\n04A",
    "SLOT": "G1",
    "FACULTY": "SASANKA BHUSHAN PULIPATI"
}, {
    "CODE": "CLE2005",
    "TITLE": "Transportation Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SASANKA BHUSHAN PULIPATI"
}, {
    "CODE": "CLE2005",
    "TITLE": "Transportation Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM3\n01",
    "SLOT": "G2",
    "FACULTY": "SASANKA BHUSHAN PULIPATI"
}, {
    "CODE": "CLE2005",
    "TITLE": "Transportation Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SASANKA BHUSHAN PULIPATI"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n03",
    "SLOT": "G1+TG1",
    "FACULTY": "BALA MURUGAN S"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG27",
    "SLOT": "L35+L36",
    "FACULTY": "BALA MURUGAN S"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BALA MURUGAN S"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n02",
    "SLOT": "G2+TG2",
    "FACULTY": "SOFI A"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG27",
    "SLOT": "L5+L6",
    "FACULTY": "SOFI A"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SOFI A"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG27",
    "SLOT": "L5+L6",
    "FACULTY": "SIMON J"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SIMON J"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG27",
    "SLOT": "L27+L28",
    "FACULTY": "SOFI A"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SOFI A"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n04A",
    "SLOT": "F1+TF1",
    "FACULTY": "SRINIVASAN"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV104",
    "SLOT": "D2+TD2",
    "FACULTY": "MEENA T"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG27",
    "SLOT": "L39+L40",
    "FACULTY": "BALA MURUGAN S"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BALA MURUGAN S"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG27",
    "SLOT": "L11+L12",
    "FACULTY": "MEENA T"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MEENA T"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG27",
    "SLOT": "L23+L24",
    "FACULTY": "MEENA T"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MEENA T"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG27",
    "SLOT": "L55+L56",
    "FACULTY": "SRINIVASAN"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SRINIVASAN"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG27",
    "SLOT": "L49+L50",
    "FACULTY": "SRINIVASAN"
}, {
    "CODE": "CLE2007",
    "TITLE": "Advanced Concrete Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SRINIVASAN"
}, {
    "CODE": "CLE2008",
    "TITLE": "Construction Planning and Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n01",
    "SLOT": "F2+TF2",
    "FACULTY": "SHANMUGA PRIYA T"
}, {
    "CODE": "CLE2008",
    "TITLE": "Construction Planning and Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n03",
    "SLOT": "F1+TF1",
    "FACULTY": "JOHN SUSHIL PACKIARAJ"
}, {
    "CODE": "CLE2008",
    "TITLE": "Construction Planning and Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n04",
    "SLOT": "B1+TB1",
    "FACULTY": "JOHN SUSHIL PACKIARAJ"
}, {
    "CODE": "CLE2010",
    "TITLE": "Ground Improvement Techniques",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM3\n04A",
    "SLOT": "C2",
    "FACULTY": "MUTHUKUMAR M"
}, {
    "CODE": "CLE2010",
    "TITLE": "Ground Improvement Techniques",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MUTHUKUMAR M"
}, {
    "CODE": "CLE2010",
    "TITLE": "Ground Improvement Techniques",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM3\n02",
    "SLOT": "F1",
    "FACULTY": "MUTHUKUMAR M"
}, {
    "CODE": "CLE2010",
    "TITLE": "Ground Improvement Techniques",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MUTHUKUMAR M"
}, {
    "CODE": "CLE2013",
    "TITLE": "Advanced Foundation Engineering",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n04A",
    "SLOT": "B2+TB2+V4",
    "FACULTY": "MUTHUKUMAR M"
}, {
    "CODE": "CLE2015",
    "TITLE": "Hydraulic Structures and Machinery",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM1\n05",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "JAGADEESH P"
}, {
    "CODE": "CLE2015",
    "TITLE": "Hydraulic Structures and Machinery",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10",
    "SLOT": "L59+L60",
    "FACULTY": "JAGADEESH P"
}, {
    "CODE": "CLE2017",
    "TITLE": "Hydrology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDNG08",
    "SLOT": "C2+TC2",
    "FACULTY": "UMA SHANKAR M"
}, {
    "CODE": "CLE2017",
    "TITLE": "Hydrology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n03",
    "SLOT": "E1+TE1",
    "FACULTY": "PAVAN KUMAR KUMMAMURU"
}, {
    "CODE": "CLE2017",
    "TITLE": "Hydrology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n04",
    "SLOT": "C2+TC2",
    "FACULTY": "PAVAN KUMAR KUMMAMURU"
}, {
    "CODE": "CLE2017",
    "TITLE": "Hydrology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV105",
    "SLOT": "A2+TA2",
    "FACULTY": "JAGADEESH P"
}, {
    "CODE": "CLE2018",
    "TITLE": "Industrial Wastes Treatment and\nDisposal",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM3\n04A",
    "SLOT": "G2",
    "FACULTY": "VIJAYALAKSHMI S"
}, {
    "CODE": "CLE2018",
    "TITLE": "Industrial Wastes Treatment and\nDisposal",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIJAYALAKSHMI S"
}, {
    "CODE": "CLE2019",
    "TITLE": "Pollution Control and Monitoring",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDNG08",
    "SLOT": "G1",
    "FACULTY": "SRIMURUGANANDAM B"
}, {
    "CODE": "CLE2019",
    "TITLE": "Pollution Control and Monitoring",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SRIMURUGANANDAM B"
}, {
    "CODE": "CLE2019",
    "TITLE": "Pollution Control and Monitoring",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM3\n03",
    "SLOT": "G2",
    "FACULTY": "SRIMURUGANANDAM B"
}, {
    "CODE": "CLE2019",
    "TITLE": "Pollution Control and Monitoring",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SRIMURUGANANDAM B"
}, {
    "CODE": "CLE2020",
    "TITLE": "Solid Waste Management",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM3\n04A",
    "SLOT": "E2",
    "FACULTY": "MAHINDRAKAR AMIT\nBABURAO"
}, {
    "CODE": "CLE2020",
    "TITLE": "Solid Waste Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MAHINDRAKAR AMIT\nBABURAO"
}, {
    "CODE": "CLE2020",
    "TITLE": "Solid Waste Management",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM3\n01",
    "SLOT": "F1",
    "FACULTY": "BHASKAR DAS"
}, {
    "CODE": "CLE2020",
    "TITLE": "Solid Waste Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BHASKAR DAS"
}, {
    "CODE": "CLE2022",
    "TITLE": "Economics and Business Finance for\nCivil Engineers",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDNG08",
    "SLOT": "D2+TD2",
    "FACULTY": "SARAVANA KUMAR M P"
}, {
    "CODE": "CLE2022",
    "TITLE": "Economics and Business Finance for\nCivil Engineers",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n03",
    "SLOT": "A1+TA1",
    "FACULTY": "SARAVANA KUMAR M P"
}, {
    "CODE": "CLE2023",
    "TITLE": "GIS and Remote Sensing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM3\n04A",
    "SLOT": "B1",
    "FACULTY": "PORCHELVAN P"
}, {
    "CODE": "CLE2023",
    "TITLE": "GIS and Remote Sensing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN153",
    "SLOT": "L57+L58",
    "FACULTY": "PORCHELVAN P"
}, {
    "CODE": "CLE2023",
    "TITLE": "GIS and Remote Sensing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM3\n03",
    "SLOT": "C2",
    "FACULTY": "PORCHELVAN P"
}, {
    "CODE": "CLE2023",
    "TITLE": "GIS and Remote Sensing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN153",
    "SLOT": "L3+L4",
    "FACULTY": "PORCHELVAN P"
}, {
    "CODE": "CLE3001",
    "TITLE": "Quantity Surveying and Estimating",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "CDMM3\n03",
    "SLOT": "E2",
    "FACULTY": "SOFI A"
}, {
    "CODE": "CLE3001",
    "TITLE": "Quantity Surveying and Estimating",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "CDMM3\n04A",
    "SLOT": "F2",
    "FACULTY": "SRINIVASAN"
}, {
    "CODE": "CLE3001",
    "TITLE": "Quantity Surveying and Estimating",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "CDMM3\n04A",
    "SLOT": "D1",
    "FACULTY": "SIMON J"
}, {
    "CODE": "CLE3001",
    "TITLE": "Quantity Surveying and Estimating",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "CDMM1\n05",
    "SLOT": "A2",
    "FACULTY": "BALA MURUGAN S"
}, {
    "CODE": "CLE3002",
    "TITLE": "Basics of Structural Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n04A",
    "SLOT": "A1+TA1+TAA1",
    "FACULTY": "SUGANYA OM"
}, {
    "CODE": "CLE3002",
    "TITLE": "Basics of Structural Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN153",
    "SLOT": "L35+L36",
    "FACULTY": "SUGANYA OM"
}, {
    "CODE": "CLE3005",
    "TITLE": "Ground Water Engineering",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n04A",
    "SLOT": "D2+TD2",
    "FACULTY": "UMA SHANKAR M"
}, {
    "CODE": "CLE3007",
    "TITLE": "Traffic Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDNG08",
    "SLOT": "A1",
    "FACULTY": "VASANTHA KUMAR S"
}, {
    "CODE": "CLE3007",
    "TITLE": "Traffic Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VASANTHA KUMAR S"
}, {
    "CODE": "CLE3007",
    "TITLE": "Traffic Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDNG08",
    "SLOT": "A2",
    "FACULTY": "VASANTHA KUMAR S"
}, {
    "CODE": "CLE3007",
    "TITLE": "Traffic Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VASANTHA KUMAR S"
}, {
    "CODE": "CLE3008",
    "TITLE": "Transport Planning and Management",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDNG08",
    "SLOT": "F2",
    "FACULTY": "SASANKA BHUSHAN PULIPATI"
}, {
    "CODE": "CLE3008",
    "TITLE": "Transport Planning and Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SASANKA BHUSHAN PULIPATI"
}, {
    "CODE": "CLE3010",
    "TITLE": "Architecture and Town Planning",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDNG08",
    "SLOT": "G2",
    "FACULTY": "E.S. DINESH RAGHAVAN"
}, {
    "CODE": "CLE3010",
    "TITLE": "Architecture and Town Planning",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "E.S. DINESH RAGHAVAN"
}, {
    "CODE": "CLE3010",
    "TITLE": "Architecture and Town Planning",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM1\n05",
    "SLOT": "G1",
    "FACULTY": "KOTA SANDEEP"
}, {
    "CODE": "CLE3010",
    "TITLE": "Architecture and Town Planning",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KOTA SANDEEP"
}, {
    "CODE": "CLE3999",
    "TITLE": "Technical Answers for Real World\nProblems (TARP)",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "CDMM3\n02",
    "SLOT": "TF1",
    "FACULTY": "THIRUMALINI S"
}, {
    "CODE": "CLE3999",
    "TITLE": "Technical Answers for Real World\nProblems (TARP)",
    "TYPE": "EPJ",
    "CREDITS": "2",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "THIRUMALINI S"
}, {
    "CODE": "CLE3999",
    "TITLE": "Technical Answers for Real World\nProblems (TARP)",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "CDMM3\n02",
    "SLOT": "TF2",
    "FACULTY": "SUGANYA OM"
}, {
    "CODE": "CLE3999",
    "TITLE": "Technical Answers for Real World\nProblems (TARP)",
    "TYPE": "EPJ",
    "CREDITS": "2",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUGANYA OM"
}, {
    "CODE": "CLE4001",
    "TITLE": "Design of Steel Structures",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDNG08",
    "SLOT": "E1+TE1",
    "FACULTY": "NEERAJA D"
}, {
    "CODE": "CLE4001",
    "TITLE": "Design of Steel Structures",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDNG08",
    "SLOT": "E2+TE2",
    "FACULTY": "NEERAJA D"
}, {
    "CODE": "CLE4001",
    "TITLE": "Design of Steel Structures",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN153",
    "SLOT": "L29+L30",
    "FACULTY": "NEERAJA D"
}, {
    "CODE": "CLE4001",
    "TITLE": "Design of Steel Structures",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN153",
    "SLOT": "L33+L34",
    "FACULTY": "NEERAJA D"
}, {
    "CODE": "CLE4002",
    "TITLE": "Design of Advanced Concrete Structures",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDNG08",
    "SLOT": "D1",
    "FACULTY": "SRINIVASAN"
}, {
    "CODE": "CLE4002",
    "TITLE": "Design of Advanced Concrete Structures",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SRINIVASAN"
}, {
    "CODE": "CLE4003",
    "TITLE": "Prestressed Concrete Design",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDNG08",
    "SLOT": "F1+TF1",
    "FACULTY": "SENTHIL KUMAR N"
}, {
    "CODE": "CLE4004",
    "TITLE": "Seismic Design of Structures",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n04",
    "SLOT": "C1+TC1+TCC1",
    "FACULTY": "SENTHIL KUMAR N"
}, {
    "CODE": "BCI3001",
    "TITLE": "Web Security",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT617",
    "SLOT": "C1",
    "FACULTY": "UMADEVI K S"
}, {
    "CODE": "BCI3001",
    "TITLE": "Web Security",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT803",
    "SLOT": "C1",
    "FACULTY": "ANURADHA D"
}, {
    "CODE": "BCI3001",
    "TITLE": "Web Security",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT702",
    "SLOT": "C2",
    "FACULTY": "ANURADHA D"
}, {
    "CODE": "BCI3001",
    "TITLE": "Web Security",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT318",
    "SLOT": "L41+L42",
    "FACULTY": "ANURADHA D"
}, {
    "CODE": "BCI3001",
    "TITLE": "Web Security",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANURADHA D"
}, {
    "CODE": "BCI3001",
    "TITLE": "Web Security",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT516",
    "SLOT": "L55+L56",
    "FACULTY": "UMADEVI K S"
}, {
    "CODE": "BCI3001",
    "TITLE": "Web Security",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "UMADEVI K S"
}, {
    "CODE": "BCI3001",
    "TITLE": "Web Security",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT516",
    "SLOT": "L23+L24",
    "FACULTY": "ANURADHA D"
}, {
    "CODE": "BCI3001",
    "TITLE": "Web Security",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANURADHA D"
}, {
    "CODE": "BCI3004",
    "TITLE": "Security of E-Based Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT802",
    "SLOT": "G1+TG1",
    "FACULTY": "MADHU VISWANATHAM V"
}, {
    "CODE": "BCI3004",
    "TITLE": "Security of E-Based Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MADHU VISWANATHAM V"
}, {
    "CODE": "BCI3004",
    "TITLE": "Security of E-Based Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT801",
    "SLOT": "G1+TG1",
    "FACULTY": "ANAND M"
}, {
    "CODE": "BCI3004",
    "TITLE": "Security of E-Based Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANAND M"
}, {
    "CODE": "BCI3004",
    "TITLE": "Security of E-Based Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT801",
    "SLOT": "G2+TG2",
    "FACULTY": "ANIL KUMAR K"
}, {
    "CODE": "BCI3004",
    "TITLE": "Security of E-Based Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANIL KUMAR K"
}, {
    "CODE": "BCI3005",
    "TITLE": "Digital Watermarking and\nSteganography",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT607",
    "SLOT": "F2+TF2",
    "FACULTY": "RAMANI S"
}, {
    "CODE": "BCI3005",
    "TITLE": "Digital Watermarking and\nSteganography",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMANI S"
}, {
    "CODE": "CSC1005",
    "TITLE": "E-Commerce",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT508",
    "SLOT": "E1+TE1",
    "FACULTY": "RAJESHKANNAN R"
}, {
    "CODE": "CSC1005",
    "TITLE": "E-Commerce",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJESHKANNAN R"
}, {
    "CODE": "CSC1005",
    "TITLE": "E-Commerce",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT607",
    "SLOT": "E1+TE1",
    "FACULTY": "SALEEM DURAI M.A"
}, {
    "CODE": "CSC1005",
    "TITLE": "E-Commerce",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SALEEM DURAI M.A"
}, {
    "CODE": "CSC1006",
    "TITLE": "Open Source Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT513",
    "SLOT": "D1",
    "FACULTY": "NALINI N"
}, {
    "CODE": "CSC1006",
    "TITLE": "Open Source Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L57+L58",
    "FACULTY": "NALINI N"
}, {
    "CODE": "CSC1006",
    "TITLE": "Open Source Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NALINI N"
}, {
    "CODE": "CSC1013",
    "TITLE": "System Software",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT403",
    "SLOT": "C1+TC1+TCC1",
    "FACULTY": "KUMARAVELU R"
}, {
    "CODE": "CSC1013",
    "TITLE": "System Software",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT408",
    "SLOT": "C1+TC1+TCC1",
    "FACULTY": "JAYA SUBALAKSHMI R"
}, {
    "CODE": "CSC1016",
    "TITLE": "Multimedia Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT423",
    "SLOT": "A1+TA1",
    "FACULTY": "JAYASHREE J"
}, {
    "CODE": "CSC1016",
    "TITLE": "Multimedia Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT513",
    "SLOT": "A1+TA1",
    "FACULTY": "DHEEBA J"
}, {
    "CODE": "CSC1016",
    "TITLE": "Multimedia Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT419",
    "SLOT": "L51+L52",
    "FACULTY": "JAYASHREE J"
}, {
    "CODE": "CSC1016",
    "TITLE": "Multimedia Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT419",
    "SLOT": "L57+L58",
    "FACULTY": "DHEEBA J"
}, {
    "CODE": "CSC2001",
    "TITLE": "Data Structures",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT802",
    "SLOT": "B1+TB1",
    "FACULTY": "KAUSER AHMED P"
}, {
    "CODE": "CSC2001",
    "TITLE": "Data Structures",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT318",
    "SLOT": "L33+L34",
    "FACULTY": "KAUSER AHMED P"
}, {
    "CODE": "CSC2001",
    "TITLE": "Data Structures",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT709",
    "SLOT": "B1+TB1",
    "FACULTY": "MURALI S"
}, {
    "CODE": "CSC2001",
    "TITLE": "Data Structures",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT318",
    "SLOT": "L31+L32",
    "FACULTY": "MURALI S"
}, {
    "CODE": "CSC2003",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT403",
    "SLOT": "D1+TD1",
    "FACULTY": "JANANI T"
}, {
    "CODE": "CSC2003",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT617",
    "SLOT": "D1+TD1",
    "FACULTY": "ANBARASI M"
}, {
    "CODE": "CSC2003",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT318",
    "SLOT": "L39+L40",
    "FACULTY": "JANANI T"
}, {
    "CODE": "CSC2003",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JANANI T"
}, {
    "CODE": "CSC2003",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT516",
    "SLOT": "L39+L40",
    "FACULTY": "ANBARASI M"
}, {
    "CODE": "CSC2003",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANBARASI M"
}, {
    "CODE": "CSC2004",
    "TITLE": "Computer Architecture",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT627",
    "SLOT": "A1+TA1+TAA1+V1",
    "FACULTY": "SAIRABANU J"
}, {
    "CODE": "CSC2004",
    "TITLE": "Computer Architecture",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT626",
    "SLOT": "A1+TA1+TAA1+V1",
    "FACULTY": "NARESH K"
}, {
    "CODE": "CSC3004",
    "TITLE": "Visual Programming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT607",
    "SLOT": "F1+TF1",
    "FACULTY": "ARUN KUMAR G"
}, {
    "CODE": "CSC3004",
    "TITLE": "Visual Programming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT513",
    "SLOT": "F1+TF1",
    "FACULTY": "NAVEEN KUMAR N"
}, {
    "CODE": "CSC3004",
    "TITLE": "Visual Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L51+L52",
    "FACULTY": "ARUN KUMAR G"
}, {
    "CODE": "CSC3004",
    "TITLE": "Visual Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT318",
    "SLOT": "L49+L50",
    "FACULTY": "NAVEEN KUMAR N"
}, {
    "CODE": "CSC3005",
    "TITLE": "Fundamentals of Data Analytics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT704",
    "SLOT": "D1+TD1",
    "FACULTY": "VIJAYASHERLY V"
}, {
    "CODE": "CSC3005",
    "TITLE": "Fundamentals of Data Analytics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIJAYASHERLY V"
}, {
    "CODE": "CSC3005",
    "TITLE": "Fundamentals of Data Analytics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT703",
    "SLOT": "D1+TD1",
    "FACULTY": "RAMANI S"
}, {
    "CODE": "CSC3005",
    "TITLE": "Fundamentals of Data Analytics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMANI S"
}, {
    "CODE": "CSC3006",
    "TITLE": "Data Mining",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT514",
    "SLOT": "A1+TA1+TAA1+V1",
    "FACULTY": "ARCHANA T"
}, {
    "CODE": "CSC3006",
    "TITLE": "Data Mining",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT521",
    "SLOT": "A1+TA1+TAA1+V1",
    "FACULTY": "ANNY LEEMA A"
}, {
    "CODE": "CSC3099",
    "TITLE": "Capstone Project",
    "TYPE": "PJT",
    "CREDITS": "10",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "CSC4001",
    "TITLE": "Software Quality Assurance/Testing",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT709",
    "SLOT": "E1+TE1",
    "FACULTY": "MYTHILI T"
}, {
    "CODE": "CSC4001",
    "TITLE": "Software Quality Assurance/Testing",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT715",
    "SLOT": "E1+TE1",
    "FACULTY": "SWARNALATHA P"
}, {
    "CODE": "CSC4002",
    "TITLE": "Web Development",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT823",
    "SLOT": "B1+TB1",
    "FACULTY": "JANANI T"
}, {
    "CODE": "CSC4002",
    "TITLE": "Web Development",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT824",
    "SLOT": "B1+TB1",
    "FACULTY": "JAYASHREE J"
}, {
    "CODE": "CSC4002",
    "TITLE": "Web Development",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT318",
    "SLOT": "L45+L46",
    "FACULTY": "JANANI T"
}, {
    "CODE": "CSC4002",
    "TITLE": "Web Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JANANI T"
}, {
    "CODE": "CSC4002",
    "TITLE": "Web Development",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT516",
    "SLOT": "L45+L46",
    "FACULTY": "JAYASHREE J"
}, {
    "CODE": "CSC4002",
    "TITLE": "Web Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JAYASHREE J"
}, {
    "CODE": "CSC4004",
    "TITLE": "Data Communication and Networking",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT715",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "VIJAYA KUMAR K"
}, {
    "CODE": "CSC4004",
    "TITLE": "Data Communication and Networking",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT421",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "SRIMATHI C"
}, {
    "CODE": "CSE1004",
    "TITLE": "Network and Communication",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT403",
    "SLOT": "G1+TG1",
    "FACULTY": "JAISANKAR N"
}, {
    "CODE": "CSE1004",
    "TITLE": "Network and Communication",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT403",
    "SLOT": "G2+TG2",
    "FACULTY": "JAISANKAR N"
}, {
    "CODE": "CSE1004",
    "TITLE": "Network and Communication",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT513",
    "SLOT": "G1+TG1",
    "FACULTY": "SIVANESAN S"
}, {
    "CODE": "CSE1004",
    "TITLE": "Network and Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT417",
    "SLOT": "L55+L56",
    "FACULTY": "JAISANKAR N"
}, {
    "CODE": "CSE1004",
    "TITLE": "Network and Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT516",
    "SLOT": "L47+L48",
    "FACULTY": "SIVANESAN S"
}, {
    "CODE": "CSE1004",
    "TITLE": "Network and Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L1+L2",
    "FACULTY": "JAISANKAR N"
}, {
    "CODE": "CSE1011",
    "TITLE": "Cryptography Fundamentals",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT801",
    "SLOT": "C1",
    "FACULTY": "MARIMUTHU K"
}, {
    "CODE": "CSE1011",
    "TITLE": "Cryptography Fundamentals",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT802",
    "SLOT": "C1",
    "FACULTY": "MADHU VISWANATHAM V"
}, {
    "CODE": "CSE1011",
    "TITLE": "Cryptography Fundamentals",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT802",
    "SLOT": "C2",
    "FACULTY": "MADHU VISWANATHAM V"
}, {
    "CODE": "CSE1011",
    "TITLE": "Cryptography Fundamentals",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L49+L50",
    "FACULTY": "MARIMUTHU K"
}, {
    "CODE": "CSE1011",
    "TITLE": "Cryptography Fundamentals",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MARIMUTHU K"
}, {
    "CODE": "CSE1011",
    "TITLE": "Cryptography Fundamentals",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L35+L36",
    "FACULTY": "MADHU VISWANATHAM V"
}, {
    "CODE": "CSE1011",
    "TITLE": "Cryptography Fundamentals",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MADHU VISWANATHAM V"
}, {
    "CODE": "CSE1011",
    "TITLE": "Cryptography Fundamentals",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT318",
    "SLOT": "L15+L16",
    "FACULTY": "MADHU VISWANATHAM V"
}, {
    "CODE": "CSE1011",
    "TITLE": "Cryptography Fundamentals",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MADHU VISWANATHAM V"
}, {
    "CODE": "CSE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT502",
    "SLOT": "B1+TB1",
    "FACULTY": "ANISHA M. LAL"
}, {
    "CODE": "CSE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT503",
    "SLOT": "B1+TB1",
    "FACULTY": "LIJO V.P"
}, {
    "CODE": "CSE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT505",
    "SLOT": "B1+TB1",
    "FACULTY": "NARAYANAN PRASANTH"
}, {
    "CODE": "CSE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT702",
    "SLOT": "B1+TB1",
    "FACULTY": "RAHUL RAMAN"
}, {
    "CODE": "CSE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT703",
    "SLOT": "B1+TB1",
    "FACULTY": "USHUS ELIZEBETH ZACHARIAH"
}, {
    "CODE": "CSE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT710",
    "SLOT": "B1+TB1",
    "FACULTY": "YOKESH BABU S"
}, {
    "CODE": "CSE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT711",
    "SLOT": "B1+TB1",
    "FACULTY": "SELVAKUMAR K"
}, {
    "CODE": "CSE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT712",
    "SLOT": "B1+TB1",
    "FACULTY": "USHA K"
}, {
    "CODE": "CSE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT715",
    "SLOT": "B1+TB1",
    "FACULTY": "SURESHKUMAR WI"
}, {
    "CODE": "CSE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT704",
    "SLOT": "B1+TB1",
    "FACULTY": "NARESH K"
}, {
    "CODE": "CSE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT503",
    "SLOT": "B2+TB2",
    "FACULTY": "LIJO V.P"
}, {
    "CODE": "CSE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT504",
    "SLOT": "B2+TB2",
    "FACULTY": "MOHANASUNDARAM R"
}, {
    "CODE": "CSE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT505",
    "SLOT": "B2+TB2",
    "FACULTY": "NARAYANAN PRASANTH"
}, {
    "CODE": "CSE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT704",
    "SLOT": "B2+TB2",
    "FACULTY": "NARESH K"
}, {
    "CODE": "CSE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT703",
    "SLOT": "B2+TB2",
    "FACULTY": "USHUS ELIZEBETH ZACHARIAH"
}, {
    "CODE": "CSE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT711",
    "SLOT": "B2+TB2",
    "FACULTY": "RAHUL RAMAN"
}, {
    "CODE": "CSE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT712",
    "SLOT": "B2+TB2",
    "FACULTY": "USHA K"
}, {
    "CODE": "CSE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT715",
    "SLOT": "B2+TB2",
    "FACULTY": "SURESHKUMAR WI"
}, {
    "CODE": "CSE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT501",
    "SLOT": "B2+TB2",
    "FACULTY": "KUMARAVELU R"
}, {
    "CODE": "CSE2002",
    "TITLE": "Theory of Computation and Compiler\nDesign",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT422",
    "SLOT": "A1+TA1+TAA1",
    "FACULTY": "DELHI BABU R"
}, {
    "CODE": "CSE2002",
    "TITLE": "Theory of Computation and Compiler\nDesign",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT409",
    "SLOT": "A1+TA1+TAA1",
    "FACULTY": "ANAND M"
}, {
    "CODE": "CSE2002",
    "TITLE": "Theory of Computation and Compiler\nDesign",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT522",
    "SLOT": "A1+TA1+TAA1",
    "FACULTY": "DEBI PRASANNA ACHARJYA"
}, {
    "CODE": "CSE2002",
    "TITLE": "Theory of Computation and Compiler\nDesign",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT502",
    "SLOT": "A1+TA1+TAA1",
    "FACULTY": "KANNADASAN R"
}, {
    "CODE": "CSE2002",
    "TITLE": "Theory of Computation and Compiler\nDesign",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT408",
    "SLOT": "A1+TA1+TAA1",
    "FACULTY": "SATHIYA KUMAR C"
}, {
    "CODE": "CSE2002",
    "TITLE": "Theory of Computation and Compiler\nDesign",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT415",
    "SLOT": "A1+TA1+TAA1",
    "FACULTY": "SENDHIL KUMAR K.S"
}, {
    "CODE": "CSE2002",
    "TITLE": "Theory of Computation and Compiler\nDesign",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT421",
    "SLOT": "A1+TA1+TAA1",
    "FACULTY": "SURESHKUMAR WI"
}, {
    "CODE": "CSE2002",
    "TITLE": "Theory of Computation and Compiler\nDesign",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT521",
    "SLOT": "A2+TA2+TAA2",
    "FACULTY": "BOOMINATHAN P"
}, {
    "CODE": "CSE2002",
    "TITLE": "Theory of Computation and Compiler\nDesign",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT502",
    "SLOT": "A2+TA2+TAA2",
    "FACULTY": "KANNADASAN R"
}, {
    "CODE": "CSE2002",
    "TITLE": "Theory of Computation and Compiler\nDesign",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT408",
    "SLOT": "A2+TA2+TAA2",
    "FACULTY": "SATHIYA KUMAR C"
}, {
    "CODE": "CSE2002",
    "TITLE": "Theory of Computation and Compiler\nDesign",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT403",
    "SLOT": "A2+TA2+TAA2",
    "FACULTY": "SHALINI L"
}, {
    "CODE": "CSE2002",
    "TITLE": "Theory of Computation and Compiler\nDesign",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT409",
    "SLOT": "A2+TA2+TAA2",
    "FACULTY": "ANAND M"
}, {
    "CODE": "CSE2002",
    "TITLE": "Theory of Computation and Compiler\nDesign",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT424",
    "SLOT": "A2+TA2+TAA2",
    "FACULTY": "SANTHI K"
}, {
    "CODE": "CSE2002",
    "TITLE": "Theory of Computation and Compiler\nDesign",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT415",
    "SLOT": "A2+TA2+TAA2",
    "FACULTY": "SENDHIL KUMAR K.S"
}, {
    "CODE": "CSE2002",
    "TITLE": "Theory of Computation and Compiler\nDesign",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT422",
    "SLOT": "A2+TA2+TAA2",
    "FACULTY": "DELHI BABU R"
}, {
    "CODE": "CSE2002",
    "TITLE": "Theory of Computation and Compiler\nDesign",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT522",
    "SLOT": "A2+TA2+TAA2",
    "FACULTY": "LAKSHMANAN K"
}, {
    "CODE": "CSE2002",
    "TITLE": "Theory of Computation and Compiler\nDesign",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT424",
    "SLOT": "A1+TA1+TAA1",
    "FACULTY": "SANTHI K"
}, {
    "CODE": "CSE2002",
    "TITLE": "Theory of Computation and Compiler\nDesign",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "SJT712",
    "SLOT": "A2+TA2+TAA2",
    "FACULTY": "ASHWIN GANESAN"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT715",
    "SLOT": "D1",
    "FACULTY": "DELHI BABU R"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT503",
    "SLOT": "D1",
    "FACULTY": "RAJESHKANNAN R"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT502",
    "SLOT": "D1",
    "FACULTY": "GEETHA MARY A"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT521",
    "SLOT": "D1",
    "FACULTY": "SATHYARAJ R"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT504",
    "SLOT": "D1",
    "FACULTY": "GOVINDA K"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT522",
    "SLOT": "D1",
    "FACULTY": "LAVANYA K"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT505",
    "SLOT": "D1",
    "FACULTY": "MURALI S"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT711",
    "SLOT": "D1",
    "FACULTY": "NAGARAJU M"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT514",
    "SLOT": "D1",
    "FACULTY": "GOPINATH M.P"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT508",
    "SLOT": "D1",
    "FACULTY": "RAMANATHAN L"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT709",
    "SLOT": "D1",
    "FACULTY": "BALAMURUGAN R"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT710",
    "SLOT": "D1",
    "FACULTY": "GAYATHRI P"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT503",
    "SLOT": "D2",
    "FACULTY": "RAJESHKANNAN R"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT521",
    "SLOT": "D2",
    "FACULTY": "SATHYARAJ R"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT504",
    "SLOT": "D2",
    "FACULTY": "GOVINDA K"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT522",
    "SLOT": "D2",
    "FACULTY": "LAVANYA K"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT505",
    "SLOT": "D2",
    "FACULTY": "MURALI S"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT711",
    "SLOT": "D2",
    "FACULTY": "NAGARAJU M"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT513",
    "SLOT": "D2",
    "FACULTY": "ANBARASI M"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT508",
    "SLOT": "D2",
    "FACULTY": "RAMANATHAN L"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT710",
    "SLOT": "D2",
    "FACULTY": "GAYATHRI P"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L41+L42",
    "FACULTY": "NAGARAJU M"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NAGARAJU M"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT317",
    "SLOT": "L57+L58",
    "FACULTY": "GEETHA MARY A"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GEETHA MARY A"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT419",
    "SLOT": "L21+L22",
    "FACULTY": "SATHYARAJ R"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SATHYARAJ R"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT419",
    "SLOT": "L23+L24",
    "FACULTY": "GOVINDA K"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GOVINDA K"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT419",
    "SLOT": "L5+L6",
    "FACULTY": "LAVANYA K"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "LAVANYA K"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT419",
    "SLOT": "L27+L28",
    "FACULTY": "RAJESHKANNAN R"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJESHKANNAN R"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT516",
    "SLOT": "L5+L6",
    "FACULTY": "NAGARAJU M"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NAGARAJU M"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT419",
    "SLOT": "L13+L14",
    "FACULTY": "RAMANATHAN L"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMANATHAN L"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L35+L36",
    "FACULTY": "RAMANATHAN L"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMANATHAN L"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L33+L34",
    "FACULTY": "BALAMURUGAN R"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BALAMURUGAN R"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT419",
    "SLOT": "L43+L44",
    "FACULTY": "SATHYARAJ R"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SATHYARAJ R"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT419",
    "SLOT": "L55+L56",
    "FACULTY": "GOVINDA K"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GOVINDA K"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT318",
    "SLOT": "L51+L52",
    "FACULTY": "LAVANYA K"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "LAVANYA K"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT419",
    "SLOT": "L47+L48",
    "FACULTY": "GAYATHRI P"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GAYATHRI P"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT419",
    "SLOT": "L39+L40",
    "FACULTY": "RAJESHKANNAN R"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJESHKANNAN R"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L33+L34",
    "FACULTY": "DELHI BABU R"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DELHI BABU R"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L25+L26",
    "FACULTY": "GAYATHRI P"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GAYATHRI P"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT417",
    "SLOT": "L43+L44",
    "FACULTY": "MURALI S"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MURALI S"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT417",
    "SLOT": "L37+L38",
    "FACULTY": "GOPINATH M.P"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GOPINATH M.P"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT502",
    "SLOT": "D2",
    "FACULTY": "GOPINATH M.P"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT702",
    "SLOT": "D2",
    "FACULTY": "RAMANI S"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT419",
    "SLOT": "L15+L16",
    "FACULTY": "RAMANI S"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMANI S"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT419",
    "SLOT": "L7+L8",
    "FACULTY": "GOPINATH M.P"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GOPINATH M.P"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT419",
    "SLOT": "L9+L10",
    "FACULTY": "ANBARASI M"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANBARASI M"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L11+L12",
    "FACULTY": "MURALI S"
}, {
    "CODE": "CSE2004",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MURALI S"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT501",
    "SLOT": "F1",
    "FACULTY": "KALYANARAMAN P"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT501",
    "SLOT": "F2",
    "FACULTY": "KALYANARAMAN P"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT502",
    "SLOT": "F1",
    "FACULTY": "MANIKANDAN K"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT504",
    "SLOT": "F1",
    "FACULTY": "PADMA PRIYA R"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT505",
    "SLOT": "F1",
    "FACULTY": "PRABAKARAN N"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT505",
    "SLOT": "F2",
    "FACULTY": "PRABAKARAN N"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT508",
    "SLOT": "F1",
    "FACULTY": "SALEEM DURAI M.A"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT508",
    "SLOT": "F2",
    "FACULTY": "SALEEM DURAI M.A"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT522",
    "SLOT": "F1",
    "FACULTY": "SELVAKUMAR K"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT522",
    "SLOT": "F2",
    "FACULTY": "SELVAKUMAR K"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT513",
    "SLOT": "F2",
    "FACULTY": "SENDHIL KUMAR K.S"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT514",
    "SLOT": "F1",
    "FACULTY": "SHAIK NASEERA"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT514",
    "SLOT": "F2",
    "FACULTY": "SHAIK NASEERA"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT521",
    "SLOT": "F1",
    "FACULTY": "SRIMATHI C"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT521",
    "SLOT": "F2",
    "FACULTY": "SRIMATHI C"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT704",
    "SLOT": "F1",
    "FACULTY": "VIJAYA KUMAR K"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT704",
    "SLOT": "F2",
    "FACULTY": "VIJAYA KUMAR K"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L27+L28",
    "FACULTY": "KALYANARAMAN P"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KALYANARAMAN P"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L47+L48",
    "FACULTY": "KALYANARAMAN P"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KALYANARAMAN P"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L19+L20",
    "FACULTY": "MANIKANDAN K"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MANIKANDAN K"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L53+L54",
    "FACULTY": "MANIKANDAN K"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MANIKANDAN K"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L7+L8",
    "FACULTY": "PRABAKARAN N"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PRABAKARAN N"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L55+L56",
    "FACULTY": "PRABAKARAN N"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PRABAKARAN N"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L3+L4",
    "FACULTY": "SALEEM DURAI M.A"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SALEEM DURAI M.A"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L41+L42",
    "FACULTY": "SALEEM DURAI M.A"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SALEEM DURAI M.A"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L23+L24",
    "FACULTY": "SELVAKUMAR K"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SELVAKUMAR K"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT416",
    "SLOT": "L55+L56",
    "FACULTY": "SELVAKUMAR K"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SELVAKUMAR K"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L9+L10",
    "FACULTY": "SENDHIL KUMAR K.S"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SENDHIL KUMAR K.S"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT416",
    "SLOT": "L47+L48",
    "FACULTY": "PADMA PRIYA R"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PADMA PRIYA R"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L29+L30",
    "FACULTY": "SHAIK NASEERA"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SHAIK NASEERA"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L37+L38",
    "FACULTY": "SHAIK NASEERA"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SHAIK NASEERA"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L21+L22",
    "FACULTY": "SRIMATHI C"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SRIMATHI C"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L49+L50",
    "FACULTY": "SRIMATHI C"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SRIMATHI C"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L5+L6",
    "FACULTY": "VIJAYA KUMAR K"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIJAYA KUMAR K"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L39+L40",
    "FACULTY": "VIJAYA KUMAR K"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIJAYA KUMAR K"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT409",
    "SLOT": "F2",
    "FACULTY": "SATHEESH A"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT419",
    "SLOT": "L35+L36",
    "FACULTY": "SATHEESH A"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SATHEESH A"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT703",
    "SLOT": "F2",
    "FACULTY": "NAGARAJU M"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT823",
    "SLOT": "F1",
    "FACULTY": "GOPINATH M.P"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT416",
    "SLOT": "L39+L40",
    "FACULTY": "GOPINATH M.P"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GOPINATH M.P"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT409",
    "SLOT": "F1",
    "FACULTY": "ANTO S"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L45+L46",
    "FACULTY": "ANTO S"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANTO S"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT504",
    "SLOT": "F2",
    "FACULTY": "GAYATHRI P"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT417",
    "SLOT": "L11+L12",
    "FACULTY": "GAYATHRI P"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GAYATHRI P"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT424",
    "SLOT": "F1",
    "FACULTY": "JAYAKUMAR K"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT516",
    "SLOT": "L41+L42",
    "FACULTY": "JAYAKUMAR K"
}, {
    "CODE": "CSE2005",
    "TITLE": "Operating Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JAYAKUMAR K"
}, {
    "CODE": "CSE2008",
    "TITLE": "Network Security",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT617",
    "SLOT": "A1+TA1",
    "FACULTY": "ANIL KUMAR K"
}, {
    "CODE": "CSE2008",
    "TITLE": "Network Security",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANIL KUMAR K"
}, {
    "CODE": "CSE2008",
    "TITLE": "Network Security",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT403",
    "SLOT": "A1+TA1",
    "FACULTY": "AKILA VICTOR"
}, {
    "CODE": "CSE2008",
    "TITLE": "Network Security",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AKILA VICTOR"
}, {
    "CODE": "CSE2008",
    "TITLE": "Network Security",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT421",
    "SLOT": "A2+TA2",
    "FACULTY": "ANIL KUMAR K"
}, {
    "CODE": "CSE2008",
    "TITLE": "Network Security",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANIL KUMAR K"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT802",
    "SLOT": "E1",
    "FACULTY": "JAYAKUMAR K"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT703",
    "SLOT": "E1",
    "FACULTY": "LOKESH KUMAR R"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT712",
    "SLOT": "E1",
    "FACULTY": "SHRIRANG AMBAJI KULKARNI"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT702",
    "SLOT": "E2",
    "FACULTY": "ANNY LEEMA A"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT403",
    "SLOT": "E2",
    "FACULTY": "NALINI N"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT710",
    "SLOT": "E2",
    "FACULTY": "KAUSER AHMED P"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT802",
    "SLOT": "E2",
    "FACULTY": "JAYAKUMAR K"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT703",
    "SLOT": "E2",
    "FACULTY": "LOKESH KUMAR R"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT712",
    "SLOT": "E2",
    "FACULTY": "SHRIRANG AMBAJI KULKARNI"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT508",
    "SLOT": "E2",
    "FACULTY": "SATHYARAJ R"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT502",
    "SLOT": "E1",
    "FACULTY": "RAJKUMAR R"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT514",
    "SLOT": "E1",
    "FACULTY": "NAVEEN KUMAR N"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT521",
    "SLOT": "E1",
    "FACULTY": "ARUN KUMAR G"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT403",
    "SLOT": "E1",
    "FACULTY": "NALINI N"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT710",
    "SLOT": "E1",
    "FACULTY": "KAUSER AHMED P"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT711",
    "SLOT": "E1",
    "FACULTY": "ANNY LEEMA A"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT424",
    "SLOT": "E1",
    "FACULTY": "SANTHI H"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT522",
    "SLOT": "E2",
    "FACULTY": "RAHUL RAMAN"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT715",
    "SLOT": "E2",
    "FACULTY": "NAVEEN KUMAR N"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT521",
    "SLOT": "E2",
    "FACULTY": "ARUN KUMAR G"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT424",
    "SLOT": "E2",
    "FACULTY": "SANTHI H"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT317",
    "SLOT": "L15+L16",
    "FACULTY": "SATHYARAJ R"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SATHYARAJ R"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT416",
    "SLOT": "L5+L6",
    "FACULTY": "ANNY LEEMA A"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANNY LEEMA A"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT416",
    "SLOT": "L15+L16",
    "FACULTY": "NALINI N"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NALINI N"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT416",
    "SLOT": "L27+L28",
    "FACULTY": "RAHUL RAMAN"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAHUL RAMAN"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT317",
    "SLOT": "L21+L22",
    "FACULTY": "KAUSER AHMED P"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KAUSER AHMED P"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT318",
    "SLOT": "L5+L6",
    "FACULTY": "NAVEEN KUMAR N"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NAVEEN KUMAR N"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT416",
    "SLOT": "L7+L8",
    "FACULTY": "JAYAKUMAR K"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JAYAKUMAR K"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT318",
    "SLOT": "L1+L2",
    "FACULTY": "LOKESH KUMAR R"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "LOKESH KUMAR R"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT417",
    "SLOT": "L15+L16",
    "FACULTY": "SHRIRANG AMBAJI KULKARNI"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SHRIRANG AMBAJI KULKARNI"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT416",
    "SLOT": "L41+L42",
    "FACULTY": "ARUN KUMAR G"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ARUN KUMAR G"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT417",
    "SLOT": "L35+L36",
    "FACULTY": "SANTHI H"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SANTHI H"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT317",
    "SLOT": "L43+L44",
    "FACULTY": "ANNY LEEMA A"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANNY LEEMA A"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT317",
    "SLOT": "L31+L32",
    "FACULTY": "NALINI N"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NALINI N"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT416",
    "SLOT": "L51+L52",
    "FACULTY": "KAUSER AHMED P"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KAUSER AHMED P"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT516",
    "SLOT": "L49+L50",
    "FACULTY": "RAJKUMAR R"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJKUMAR R"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT318",
    "SLOT": "L57+L58",
    "FACULTY": "NAVEEN KUMAR N"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NAVEEN KUMAR N"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L31+L32",
    "FACULTY": "JAYAKUMAR K"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JAYAKUMAR K"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT317",
    "SLOT": "L53+L54",
    "FACULTY": "LOKESH KUMAR R"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "LOKESH KUMAR R"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT318",
    "SLOT": "L59+L60",
    "FACULTY": "SHRIRANG AMBAJI KULKARNI"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SHRIRANG AMBAJI KULKARNI"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT416",
    "SLOT": "L21+L22",
    "FACULTY": "SANTHI H"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SANTHI H"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT513",
    "SLOT": "E1",
    "FACULTY": "BALASUBRAMANIAN V"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT416",
    "SLOT": "L49+L50",
    "FACULTY": "BALASUBRAMANIAN V"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BALASUBRAMANIAN V"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT417",
    "SLOT": "L3+L4",
    "FACULTY": "ARUN KUMAR G"
}, {
    "CODE": "CSE3002",
    "TITLE": "Internet and Web Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ARUN KUMAR G"
}, {
    "CODE": "CSE3006",
    "TITLE": "Embedded System Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT513",
    "SLOT": "A2+TA2",
    "FACULTY": "RAJAKUMAR K"
}, {
    "CODE": "CSE3006",
    "TITLE": "Embedded System Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJAKUMAR K"
}, {
    "CODE": "CSE3006",
    "TITLE": "Embedded System Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT704",
    "SLOT": "A1+TA1",
    "FACULTY": "SIVANESAN S"
}, {
    "CODE": "CSE3006",
    "TITLE": "Embedded System Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SIVANESAN S"
}, {
    "CODE": "CSE3006",
    "TITLE": "Embedded System Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT709",
    "SLOT": "A1+TA1",
    "FACULTY": "YOKESH BABU S"
}, {
    "CODE": "CSE3006",
    "TITLE": "Embedded System Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "YOKESH BABU S"
}, {
    "CODE": "CSE3006",
    "TITLE": "Embedded System Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT710",
    "SLOT": "A1+TA1",
    "FACULTY": "KRISHNAMOORTHY A"
}, {
    "CODE": "CSE3006",
    "TITLE": "Embedded System Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KRISHNAMOORTHY A"
}, {
    "CODE": "CSE3006",
    "TITLE": "Embedded System Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT501",
    "SLOT": "A2+TA2",
    "FACULTY": "KUMARAVELU R"
}, {
    "CODE": "CSE3006",
    "TITLE": "Embedded System Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KUMARAVELU R"
}, {
    "CODE": "CSE3006",
    "TITLE": "Embedded System Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT423",
    "SLOT": "A2+TA2",
    "FACULTY": "SIVANESAN S"
}, {
    "CODE": "CSE3006",
    "TITLE": "Embedded System Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SIVANESAN S"
}, {
    "CODE": "CSE3006",
    "TITLE": "Embedded System Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT709",
    "SLOT": "A2+TA2",
    "FACULTY": "YOKESH BABU S"
}, {
    "CODE": "CSE3006",
    "TITLE": "Embedded System Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "YOKESH BABU S"
}, {
    "CODE": "CSE3006",
    "TITLE": "Embedded System Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT710",
    "SLOT": "A2+TA2",
    "FACULTY": "KRISHNAMOORTHY A"
}, {
    "CODE": "CSE3006",
    "TITLE": "Embedded System Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KRISHNAMOORTHY A"
}, {
    "CODE": "CSE3009",
    "TITLE": "Internet of Things",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT711",
    "SLOT": "F1+TF1",
    "FACULTY": "ANANDA KUMAR S"
}, {
    "CODE": "CSE3009",
    "TITLE": "Internet of Things",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANANDA KUMAR S"
}, {
    "CODE": "CSE3009",
    "TITLE": "Internet of Things",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT715",
    "SLOT": "F1+TF1",
    "FACULTY": "PRIYA G"
}, {
    "CODE": "CSE3009",
    "TITLE": "Internet of Things",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PRIYA G"
}, {
    "CODE": "CSE3009",
    "TITLE": "Internet of Things",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT801",
    "SLOT": "F1+TF1",
    "FACULTY": "PARVEEN SULTANA H"
}, {
    "CODE": "CSE3009",
    "TITLE": "Internet of Things",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PARVEEN SULTANA H"
}, {
    "CODE": "CSE3009",
    "TITLE": "Internet of Things",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT802",
    "SLOT": "F1+TF1",
    "FACULTY": "UMADEVI K S"
}, {
    "CODE": "CSE3009",
    "TITLE": "Internet of Things",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "UMADEVI K S"
}, {
    "CODE": "CSE3009",
    "TITLE": "Internet of Things",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT803",
    "SLOT": "F1+TF1",
    "FACULTY": "RAMESH BABU K"
}, {
    "CODE": "CSE3009",
    "TITLE": "Internet of Things",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMESH BABU K"
}, {
    "CODE": "CSE3009",
    "TITLE": "Internet of Things",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT710",
    "SLOT": "F1+TF1",
    "FACULTY": "ARUNKUMAR T"
}, {
    "CODE": "CSE3009",
    "TITLE": "Internet of Things",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ARUNKUMAR T"
}, {
    "CODE": "CSE3009",
    "TITLE": "Internet of Things",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT715",
    "SLOT": "F2+TF2",
    "FACULTY": "PRIYA G"
}, {
    "CODE": "CSE3009",
    "TITLE": "Internet of Things",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PRIYA G"
}, {
    "CODE": "CSE3009",
    "TITLE": "Internet of Things",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT801",
    "SLOT": "F2+TF2",
    "FACULTY": "PARVEEN SULTANA H"
}, {
    "CODE": "CSE3009",
    "TITLE": "Internet of Things",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PARVEEN SULTANA H"
}, {
    "CODE": "CSE3009",
    "TITLE": "Internet of Things",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT802",
    "SLOT": "F2+TF2",
    "FACULTY": "ANANDA KUMAR S"
}, {
    "CODE": "CSE3009",
    "TITLE": "Internet of Things",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANANDA KUMAR S"
}, {
    "CODE": "CSE3016",
    "TITLE": "Computer Graphics and Multimedia",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT403",
    "SLOT": "C2",
    "FACULTY": "AJU D"
}, {
    "CODE": "CSE3016",
    "TITLE": "Computer Graphics and Multimedia",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT419",
    "SLOT": "L3+L4",
    "FACULTY": "AJU D"
}, {
    "CODE": "CSE3016",
    "TITLE": "Computer Graphics and Multimedia",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AJU D"
}, {
    "CODE": "CSE3016",
    "TITLE": "Computer Graphics and Multimedia",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT415",
    "SLOT": "C1",
    "FACULTY": "GLADYS GNANA KIRUBA B"
}, {
    "CODE": "CSE3016",
    "TITLE": "Computer Graphics and Multimedia",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT419",
    "SLOT": "L37+L38",
    "FACULTY": "GLADYS GNANA KIRUBA B"
}, {
    "CODE": "CSE3016",
    "TITLE": "Computer Graphics and Multimedia",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GLADYS GNANA KIRUBA B"
}, {
    "CODE": "CSE3020",
    "TITLE": "Data Visualization",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT710",
    "SLOT": "G1",
    "FACULTY": "SATHEESH A"
}, {
    "CODE": "CSE3020",
    "TITLE": "Data Visualization",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT710",
    "SLOT": "G2",
    "FACULTY": "SATHEESH A"
}, {
    "CODE": "CSE3020",
    "TITLE": "Data Visualization",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT417",
    "SLOT": "L1+L2",
    "FACULTY": "SATHEESH A"
}, {
    "CODE": "CSE3020",
    "TITLE": "Data Visualization",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SATHEESH A"
}, {
    "CODE": "CSE3020",
    "TITLE": "Data Visualization",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT417",
    "SLOT": "L53+L54",
    "FACULTY": "SATHEESH A"
}, {
    "CODE": "CSE3020",
    "TITLE": "Data Visualization",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SATHEESH A"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT607",
    "SLOT": "A1+TA1",
    "FACULTY": "RAJKUMAR R"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJKUMAR R"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT711",
    "SLOT": "A1+TA1",
    "FACULTY": "DEEBAK B D"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DEEBAK B D"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT712",
    "SLOT": "A1+TA1",
    "FACULTY": "VASANTHA W B"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VASANTHA W B"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT707",
    "SLOT": "A1+TA1",
    "FACULTY": "MEENAKSHI S P"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MEENAKSHI S P"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT801",
    "SLOT": "A1+TA1",
    "FACULTY": "VIJAYASHERLY V"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIJAYASHERLY V"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT802",
    "SLOT": "A1+TA1",
    "FACULTY": "RISHIN HALDAR"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RISHIN HALDAR"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT803",
    "SLOT": "A1+TA1",
    "FACULTY": "SANJIBAN SEKHAR ROY"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SANJIBAN SEKHAR ROY"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT823",
    "SLOT": "A1+TA1",
    "FACULTY": "SIVA SHANMUGAM G"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SIVA SHANMUGAM G"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT824",
    "SLOT": "A1+TA1",
    "FACULTY": "MANJULA R"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MANJULA R"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT514",
    "SLOT": "A2+TA2",
    "FACULTY": "RAJKUMAR R"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJKUMAR R"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT702",
    "SLOT": "A2+TA2",
    "FACULTY": "VASANTHA W B"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VASANTHA W B"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT703",
    "SLOT": "A2+TA2",
    "FACULTY": "ANURADHA J"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANURADHA J"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT824",
    "SLOT": "A2+TA2",
    "FACULTY": "VIJAYASHERLY V"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIJAYASHERLY V"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT802",
    "SLOT": "A2+TA2",
    "FACULTY": "RISHIN HALDAR"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RISHIN HALDAR"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT803",
    "SLOT": "A2+TA2",
    "FACULTY": "MEENAKSHI S P"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MEENAKSHI S P"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT619",
    "SLOT": "A1+TA1",
    "FACULTY": "ANURADHA G"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANURADHA G"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT823",
    "SLOT": "A2+TA2",
    "FACULTY": "SIVA SHANMUGAM G"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SIVA SHANMUGAM G"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT707",
    "SLOT": "A2+TA2",
    "FACULTY": "ANURADHA G"
}, {
    "CODE": "CSE3021",
    "TITLE": "Social and Information Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANURADHA G"
}, {
    "CODE": "CSE3022",
    "TITLE": "Soft Computing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT704",
    "SLOT": "G1+TG1",
    "FACULTY": "BALAKRUSHNA TRIPATHY"
}, {
    "CODE": "CSE3022",
    "TITLE": "Soft Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BALAKRUSHNA TRIPATHY"
}, {
    "CODE": "CSE3022",
    "TITLE": "Soft Computing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT704",
    "SLOT": "G2+TG2",
    "FACULTY": "BALAKRUSHNA TRIPATHY"
}, {
    "CODE": "CSE3022",
    "TITLE": "Soft Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BALAKRUSHNA TRIPATHY"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT709",
    "SLOT": "F1+TF1",
    "FACULTY": "RISHIN HALDAR"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT408",
    "SLOT": "F1+TF1",
    "FACULTY": "BALAKRISHNAN P"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT415",
    "SLOT": "F1+TF1",
    "FACULTY": "NATARAJAN P"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT422",
    "SLOT": "F1+TF1",
    "FACULTY": "SANJIBAN SEKHAR ROY"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT423",
    "SLOT": "F1+TF1",
    "FACULTY": "ANURADHA J"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT403",
    "SLOT": "F1+TF1",
    "FACULTY": "SHASHANK MOULI SATAPATHY"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT408",
    "SLOT": "F2+TF2",
    "FACULTY": "GOVINDA K"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT424",
    "SLOT": "F2+TF2",
    "FACULTY": "ANURADHA J"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT421",
    "SLOT": "F2+TF2",
    "FACULTY": "BALAKRISHNAN P"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT422",
    "SLOT": "F2+TF2",
    "FACULTY": "LOKESH KUMAR R"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT423",
    "SLOT": "F2+TF2",
    "FACULTY": "SANJIBAN SEKHAR ROY"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT502",
    "SLOT": "F2+TF2",
    "FACULTY": "ARIVOLI A"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT421",
    "SLOT": "F1+TF1",
    "FACULTY": "KUMAR K"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT620",
    "SLOT": "L35+L36",
    "FACULTY": "KUMAR K"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT620",
    "SLOT": "L9+L10",
    "FACULTY": "ANURADHA J"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT620",
    "SLOT": "L51+L52",
    "FACULTY": "ANURADHA J"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT620",
    "SLOT": "L59+L60",
    "FACULTY": "NATARAJAN P"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT620",
    "SLOT": "L41+L42",
    "FACULTY": "SANJIBAN SEKHAR ROY"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT620",
    "SLOT": "L25+L26",
    "FACULTY": "SANJIBAN SEKHAR ROY"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT620",
    "SLOT": "L5+L6",
    "FACULTY": "BALAKRISHNAN P"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT620",
    "SLOT": "L33+L34",
    "FACULTY": "BALAKRISHNAN P"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT620",
    "SLOT": "L3+L4",
    "FACULTY": "SHASHANK MOULI SATAPATHY"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT620",
    "SLOT": "L45+L46",
    "FACULTY": "RISHIN HALDAR"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT418",
    "SLOT": "L13+L14",
    "FACULTY": "GOVINDA K"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT316",
    "SLOT": "L15+L16",
    "FACULTY": "LOKESH KUMAR R"
}, {
    "CODE": "CSE3024",
    "TITLE": "Web Mining",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT620",
    "SLOT": "L7+L8",
    "FACULTY": "ARIVOLI A"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT403",
    "SLOT": "B1",
    "FACULTY": "SAIRABANU J"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT403",
    "SLOT": "B2",
    "FACULTY": "SAIRABANU J"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L45+L46",
    "FACULTY": "SAIRABANU J"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SAIRABANU J"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT508",
    "SLOT": "B1",
    "FACULTY": "MANOOV R"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L51+L52",
    "FACULTY": "MANOOV R"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MANOOV R"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT513",
    "SLOT": "B1",
    "FACULTY": "SIVA SHANMUGAM G"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT513",
    "SLOT": "B2",
    "FACULTY": "MANOOV R"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT514",
    "SLOT": "B1",
    "FACULTY": "PREETHA EVANGELINE D"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT514",
    "SLOT": "B2",
    "FACULTY": "PREETHA EVANGELINE D"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT521",
    "SLOT": "B1",
    "FACULTY": "THENMOZHI T"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT521",
    "SLOT": "B2",
    "FACULTY": "THENMOZHI T"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT522",
    "SLOT": "B1",
    "FACULTY": "GAWAS MAHADEV ANANT"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT522",
    "SLOT": "B2",
    "FACULTY": "JABANJALIN HILDA J"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT702",
    "SLOT": "B2",
    "FACULTY": "NARAYANAMOORTHI M"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT607",
    "SLOT": "B1",
    "FACULTY": "ANTO S"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT607",
    "SLOT": "B2",
    "FACULTY": "ANTO S"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT619",
    "SLOT": "B1",
    "FACULTY": "DEEBAK B D"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT619",
    "SLOT": "B2",
    "FACULTY": "DEEBAK B D"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT707",
    "SLOT": "B1",
    "FACULTY": "BALAMURUGAN R"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT709",
    "SLOT": "B2",
    "FACULTY": "BALAMURUGAN R"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L37+L38",
    "FACULTY": "SIVA SHANMUGAM G"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SIVA SHANMUGAM G"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L15+L16",
    "FACULTY": "NARAYANAMOORTHI M"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NARAYANAMOORTHI M"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L3+L4",
    "FACULTY": "ANTO S"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANTO S"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L25+L26",
    "FACULTY": "DEEBAK B D"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DEEBAK B D"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L27+L28",
    "FACULTY": "BALAMURUGAN R"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BALAMURUGAN R"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L11+L12",
    "FACULTY": "MANOOV R"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MANOOV R"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L19+L20",
    "FACULTY": "JABANJALIN HILDA J"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JABANJALIN HILDA J"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L43+L44",
    "FACULTY": "ANTO S"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANTO S"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L53+L54",
    "FACULTY": "DEEBAK B D"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DEEBAK B D"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L59+L60",
    "FACULTY": "GAWAS MAHADEV ANANT"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GAWAS MAHADEV ANANT"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L55+L56",
    "FACULTY": "BALAMURUGAN R"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BALAMURUGAN R"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L9+L10",
    "FACULTY": "SAIRABANU J"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SAIRABANU J"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT803",
    "SLOT": "B1",
    "FACULTY": "UMADEVI K S"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L31+L32",
    "FACULTY": "UMADEVI K S"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "UMADEVI K S"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT710",
    "SLOT": "B2",
    "FACULTY": "GOPICHAND G"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT515",
    "SLOT": "L5+L6",
    "FACULTY": "GOPICHAND G"
}, {
    "CODE": "CSE4001",
    "TITLE": "Parallel and Distributed Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GOPICHAND G"
}, {
    "CODE": "CSE4014",
    "TITLE": "High Performance Computing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT501",
    "SLOT": "C1+TC1",
    "FACULTY": "GOPICHAND G"
}, {
    "CODE": "CSE4014",
    "TITLE": "High Performance Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GOPICHAND G"
}, {
    "CODE": "CSE4014",
    "TITLE": "High Performance Computing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT502",
    "SLOT": "C1+TC1",
    "FACULTY": "PREETHA EVANGELINE D"
}, {
    "CODE": "CSE4014",
    "TITLE": "High Performance Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PREETHA EVANGELINE D"
}, {
    "CODE": "CSE4014",
    "TITLE": "High Performance Computing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT513",
    "SLOT": "C1+TC1",
    "FACULTY": "SHAIK NASEERA"
}, {
    "CODE": "CSE4014",
    "TITLE": "High Performance Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SHAIK NASEERA"
}, {
    "CODE": "CSE4014",
    "TITLE": "High Performance Computing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT501",
    "SLOT": "C2+TC2",
    "FACULTY": "GOPICHAND G"
}, {
    "CODE": "CSE4014",
    "TITLE": "High Performance Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GOPICHAND G"
}, {
    "CODE": "CSE4014",
    "TITLE": "High Performance Computing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT502",
    "SLOT": "C2+TC2",
    "FACULTY": "PARVEEN SULTANA H"
}, {
    "CODE": "CSE4014",
    "TITLE": "High Performance Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PARVEEN SULTANA H"
}, {
    "CODE": "CSE4014",
    "TITLE": "High Performance Computing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT715",
    "SLOT": "C2+TC2",
    "FACULTY": "MANIKANDAN K"
}, {
    "CODE": "CSE4014",
    "TITLE": "High Performance Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MANIKANDAN K"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT514",
    "SLOT": "C1+TC1",
    "FACULTY": "SWARNALATHA P"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SWARNALATHA P"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT521",
    "SLOT": "C1+TC1",
    "FACULTY": "NAVAMANI T M"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NAVAMANI T M"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT522",
    "SLOT": "C1+TC1",
    "FACULTY": "MARGRET ANOUNCIA S"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MARGRET ANOUNCIA S"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT607",
    "SLOT": "C1+TC1",
    "FACULTY": "MYTHILI T"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MYTHILI T"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT619",
    "SLOT": "C1+TC1",
    "FACULTY": "SHASHANK MOULI SATAPATHY"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SHASHANK MOULI SATAPATHY"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT710",
    "SLOT": "C1+TC1",
    "FACULTY": "SATHIYA KUMAR C"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SATHIYA KUMAR C"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT704",
    "SLOT": "C1+TC1",
    "FACULTY": "DHEEBA J"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DHEEBA J"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT707",
    "SLOT": "C1+TC1",
    "FACULTY": "GAWAS MAHADEV ANANT"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GAWAS MAHADEV ANANT"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT709",
    "SLOT": "C1+TC1",
    "FACULTY": "MANJULA R"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MANJULA R"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT514",
    "SLOT": "C2+TC2",
    "FACULTY": "SWARNALATHA P"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SWARNALATHA P"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT521",
    "SLOT": "C2+TC2",
    "FACULTY": "ARUN KUMAR S"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ARUN KUMAR S"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT607",
    "SLOT": "C2+TC2",
    "FACULTY": "MYTHILI T"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MYTHILI T"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT619",
    "SLOT": "C2+TC2",
    "FACULTY": "SHASHANK MOULI SATAPATHY"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SHASHANK MOULI SATAPATHY"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT704",
    "SLOT": "C2+TC2",
    "FACULTY": "DHEEBA J"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DHEEBA J"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT707",
    "SLOT": "C2+TC2",
    "FACULTY": "GAWAS MAHADEV ANANT"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GAWAS MAHADEV ANANT"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT709",
    "SLOT": "C2+TC2",
    "FACULTY": "MANJULA R"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MANJULA R"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT803",
    "SLOT": "C2+TC2",
    "FACULTY": "ANANDA KUMAR S"
}, {
    "CODE": "CSE4015",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANANDA KUMAR S"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT415",
    "SLOT": "G1+TG1",
    "FACULTY": "RAJAKUMAR K"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJAKUMAR K"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT421",
    "SLOT": "G1+TG1",
    "FACULTY": "AJU D"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AJU D"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT424",
    "SLOT": "G1+TG1",
    "FACULTY": "RAJKUMAR S"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJKUMAR S"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT422",
    "SLOT": "G1+TG1",
    "FACULTY": "ANISHA M. LAL"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANISHA M. LAL"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT502",
    "SLOT": "G1+TG1",
    "FACULTY": "NATARAJAN P"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NATARAJAN P"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT508",
    "SLOT": "G1+TG1",
    "FACULTY": "NAGARAJA RAO A"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NAGARAJA RAO A"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT503",
    "SLOT": "G1+TG1",
    "FACULTY": "SRIVANI A"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SRIVANI A"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT514",
    "SLOT": "G1+TG1",
    "FACULTY": "JAISAKTHI S M"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JAISAKTHI S M"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT423",
    "SLOT": "G1+TG1",
    "FACULTY": "PRABU S"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PRABU S"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT415",
    "SLOT": "G2+TG2",
    "FACULTY": "RAJAKUMAR K"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJAKUMAR K"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT421",
    "SLOT": "G2+TG2",
    "FACULTY": "AJU D"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AJU D"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT422",
    "SLOT": "G2+TG2",
    "FACULTY": "ANISHA M. LAL"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANISHA M. LAL"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT423",
    "SLOT": "G2+TG2",
    "FACULTY": "PRABU S"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PRABU S"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT502",
    "SLOT": "G2+TG2",
    "FACULTY": "NATARAJAN P"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NATARAJAN P"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT424",
    "SLOT": "G2+TG2",
    "FACULTY": "SANTHI V"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SANTHI V"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT508",
    "SLOT": "G2+TG2",
    "FACULTY": "NAGARAJA RAO A"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NAGARAJA RAO A"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT503",
    "SLOT": "G2+TG2",
    "FACULTY": "SRIVANI A"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SRIVANI A"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT522",
    "SLOT": "G1+TG1",
    "FACULTY": "SURESHKUMAR N"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SURESHKUMAR N"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT505",
    "SLOT": "G2+TG2",
    "FACULTY": "SWATHI J.N"
}, {
    "CODE": "CSE4019",
    "TITLE": "Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SWATHI J.N"
}, {
    "CODE": "CSE4022",
    "TITLE": "Natural Language Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT702",
    "SLOT": "E1+TE1",
    "FACULTY": "ARIVOLI A"
}, {
    "CODE": "CSE4022",
    "TITLE": "Natural Language Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ARIVOLI A"
}, {
    "CODE": "CSE4022",
    "TITLE": "Natural Language Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT709",
    "SLOT": "E2+TE2",
    "FACULTY": "ARIVOLI A"
}, {
    "CODE": "CSE4022",
    "TITLE": "Natural Language Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ARIVOLI A"
}, {
    "CODE": "CSE4022",
    "TITLE": "Natural Language Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT707",
    "SLOT": "E1+TE1",
    "FACULTY": "SHARMILA BANU K"
}, {
    "CODE": "CSE4022",
    "TITLE": "Natural Language Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SHARMILA BANU K"
}, {
    "CODE": "CSE4022",
    "TITLE": "Natural Language Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT707",
    "SLOT": "E2+TE2",
    "FACULTY": "SHARMILA BANU K"
}, {
    "CODE": "CSE4022",
    "TITLE": "Natural Language Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SHARMILA BANU K"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT802",
    "SLOT": "D1",
    "FACULTY": "SENTHILNATHAN"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT803",
    "SLOT": "D1",
    "FACULTY": "JOTHI K R"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT807",
    "SLOT": "D1",
    "FACULTY": "AKILA VICTOR"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT823",
    "SLOT": "D1",
    "FACULTY": "ARUN KUMAR S"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT803",
    "SLOT": "D2",
    "FACULTY": "JOTHI K R"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT807",
    "SLOT": "D2",
    "FACULTY": "AKILA VICTOR"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT823",
    "SLOT": "D2",
    "FACULTY": "ARUN KUMAR S"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT417",
    "SLOT": "L23+L24",
    "FACULTY": "JOTHI K R"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JOTHI K R"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT417",
    "SLOT": "L25+L26",
    "FACULTY": "AKILA VICTOR"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AKILA VICTOR"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT417",
    "SLOT": "L5+L6",
    "FACULTY": "ARUN KUMAR S"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ARUN KUMAR S"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT417",
    "SLOT": "L47+L48",
    "FACULTY": "ARUN KUMAR S"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ARUN KUMAR S"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT417",
    "SLOT": "L57+L58",
    "FACULTY": "AKILA VICTOR"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AKILA VICTOR"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT417",
    "SLOT": "L39+L40",
    "FACULTY": "JOTHI K R"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JOTHI K R"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT417",
    "SLOT": "L51+L52",
    "FACULTY": "SENTHILNATHAN"
}, {
    "CODE": "CSE4028",
    "TITLE": "Object Oriented Software Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SENTHILNATHAN"
}, {
    "CODE": "CSE6099",
    "TITLE": "Masters Thesis",
    "TYPE": "PJT",
    "CREDITS": "16",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "EEE1001",
    "TITLE": "Basic Electrical and Electronics\nEngineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT127",
    "SLOT": "F2",
    "FACULTY": "SARAVANAKUMAR R"
}, {
    "CODE": "EEE1001",
    "TITLE": "Basic Electrical and Electronics\nEngineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT247",
    "SLOT": "L21+L22",
    "FACULTY": "SARAVANAKUMAR R"
}, {
    "CODE": "EEE1001",
    "TITLE": "Basic Electrical and Electronics\nEngineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT520",
    "SLOT": "L29+L30",
    "FACULTY": "SARAVANAKUMAR R"
}, {
    "CODE": "EEE1003",
    "TITLE": "Electrical Workshop",
    "TYPE": "LO",
    "CREDITS": "1",
    "VENUE": "TT037",
    "SLOT": "L23+L24",
    "FACULTY": "RAMA PRABHA D"
}, {
    "CODE": "EEE1004",
    "TITLE": "Engineering Electromagnetics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT515",
    "SLOT": "L43+L44",
    "FACULTY": "RAMESH V"
}, {
    "CODE": "EEE1004",
    "TITLE": "Engineering Electromagnetics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT515",
    "SLOT": "L53+L54",
    "FACULTY": "RAMESH V"
}, {
    "CODE": "EEE1004",
    "TITLE": "Engineering Electromagnetics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT204",
    "SLOT": "B1+TB1",
    "FACULTY": "RAMESH V"
}, {
    "CODE": "EEE1005",
    "TITLE": "Signals and Systems",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT423",
    "SLOT": "B2+TB2",
    "FACULTY": "RAMESH V"
}, {
    "CODE": "EEE1005",
    "TITLE": "Signals and Systems",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT424",
    "SLOT": "B2+TB2",
    "FACULTY": "MATHEW M. NOEL"
}, {
    "CODE": "EEE1005",
    "TITLE": "Signals and Systems",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT423",
    "SLOT": "B1+TB1",
    "FACULTY": "MAHALAKSHMI P"
}, {
    "CODE": "EEE1005",
    "TITLE": "Signals and Systems",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT424",
    "SLOT": "B1+TB1",
    "FACULTY": "AMUTHA PRABHA N"
}, {
    "CODE": "EEE1005",
    "TITLE": "Signals and Systems",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT434",
    "SLOT": "B1+TB1",
    "FACULTY": "MANIMOZHI M"
}, {
    "CODE": "EEE1005",
    "TITLE": "Signals and Systems",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT434",
    "SLOT": "B2+TB2",
    "FACULTY": "MANIMOZHI M"
}, {
    "CODE": "EEE1007",
    "TITLE": "Neural Network and Fuzzy Control",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT423",
    "SLOT": "F1",
    "FACULTY": "SATHISHKUMAR K"
}, {
    "CODE": "EEE1007",
    "TITLE": "Neural Network and Fuzzy Control",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SATHISHKUMAR K"
}, {
    "CODE": "EEE1007",
    "TITLE": "Neural Network and Fuzzy Control",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT423",
    "SLOT": "F2",
    "FACULTY": "MONICA SUBASHINI M"
}, {
    "CODE": "EEE1007",
    "TITLE": "Neural Network and Fuzzy Control",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MONICA SUBASHINI M"
}, {
    "CODE": "EEE1007",
    "TITLE": "Neural Network and Fuzzy Control",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT424",
    "SLOT": "F1",
    "FACULTY": "VIVEKANANDAN S"
}, {
    "CODE": "EEE1007",
    "TITLE": "Neural Network and Fuzzy Control",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIVEKANANDAN S"
}, {
    "CODE": "EEE1007",
    "TITLE": "Neural Network and Fuzzy Control",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT424",
    "SLOT": "F2",
    "FACULTY": "SHARMILA A"
}, {
    "CODE": "EEE1007",
    "TITLE": "Neural Network and Fuzzy Control",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SHARMILA A"
}, {
    "CODE": "EEE1007",
    "TITLE": "Neural Network and Fuzzy Control",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV105",
    "SLOT": "F2",
    "FACULTY": "SRIHARI MANDAVA"
}, {
    "CODE": "EEE1007",
    "TITLE": "Neural Network and Fuzzy Control",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SRIHARI MANDAVA"
}, {
    "CODE": "EEE1008",
    "TITLE": "Bio-Medical Instrumentation",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV105",
    "SLOT": "G1+TG1",
    "FACULTY": "RUBAN N"
}, {
    "CODE": "EEE1008",
    "TITLE": "Bio-Medical Instrumentation",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RUBAN N"
}, {
    "CODE": "EEE1008",
    "TITLE": "Bio-Medical Instrumentation",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT434",
    "SLOT": "G1+TG1",
    "FACULTY": "SUDHA R"
}, {
    "CODE": "EEE1008",
    "TITLE": "Bio-Medical Instrumentation",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUDHA R"
}, {
    "CODE": "EEE1008",
    "TITLE": "Bio-Medical Instrumentation",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT434",
    "SLOT": "G2+TG2",
    "FACULTY": "RUBAN N"
}, {
    "CODE": "EEE1008",
    "TITLE": "Bio-Medical Instrumentation",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RUBAN N"
}, {
    "CODE": "EEE1011",
    "TITLE": "Automated Test Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT204",
    "SLOT": "C1",
    "FACULTY": "VENKATARAMAN M.N"
}, {
    "CODE": "EEE1011",
    "TITLE": "Automated Test Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT401",
    "SLOT": "L33+L34",
    "FACULTY": "VENKATARAMAN M.N"
}, {
    "CODE": "EEE1011",
    "TITLE": "Automated Test Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT401",
    "SLOT": "L49+L50",
    "FACULTY": "VENKATARAMAN M.N"
}, {
    "CODE": "EEE1012",
    "TITLE": "Optoelectronic Instrumentation",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT104",
    "SLOT": "F2+TF2",
    "FACULTY": "SIVABALAN S"
}, {
    "CODE": "EEE1014",
    "TITLE": "Fiber Optic Sensors",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT104",
    "SLOT": "F1+TF1",
    "FACULTY": "SIVABALAN S"
}, {
    "CODE": "EEE1016",
    "TITLE": "Non-Destructive Testing",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT201",
    "SLOT": "G1+TG1",
    "FACULTY": "ARUNGALAI VENDAN S"
}, {
    "CODE": "EEE1018",
    "TITLE": "Nanotechnology Fundamentals and its\nApplications",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT423",
    "SLOT": "G2+TG2",
    "FACULTY": "PARTHA SHARATHI MALLICK"
}, {
    "CODE": "EEE1018",
    "TITLE": "Nanotechnology Fundamentals and its\nApplications",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT423",
    "SLOT": "G1+TG1",
    "FACULTY": "UMA SATHYAKAM P"
}, {
    "CODE": "EEE2001",
    "TITLE": "Network Theory",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT434A",
    "SLOT": "C2+TC2",
    "FACULTY": "JAYABARATHI T"
}, {
    "CODE": "EEE2002",
    "TITLE": "Semiconductor Devices and Circuits",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT204",
    "SLOT": "A1",
    "FACULTY": "ARUNKUMAR G"
}, {
    "CODE": "EEE2002",
    "TITLE": "Semiconductor Devices and Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT129",
    "SLOT": "L33+L34",
    "FACULTY": "ARUNKUMAR G"
}, {
    "CODE": "EEE2002",
    "TITLE": "Semiconductor Devices and Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ARUNKUMAR G"
}, {
    "CODE": "EEE2002",
    "TITLE": "Semiconductor Devices and Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT129",
    "SLOT": "L47+L48",
    "FACULTY": "ARUNKUMAR G"
}, {
    "CODE": "EEE2002",
    "TITLE": "Semiconductor Devices and Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ARUNKUMAR G"
}, {
    "CODE": "EEE2003",
    "TITLE": "Electromechanical Energy Conversion",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT423",
    "SLOT": "D1+TD1",
    "FACULTY": "RAJU J"
}, {
    "CODE": "EEE2003",
    "TITLE": "Electromechanical Energy Conversion",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT035",
    "SLOT": "L31+L32",
    "FACULTY": "RAJU J"
}, {
    "CODE": "EEE2003",
    "TITLE": "Electromechanical Energy Conversion",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT035",
    "SLOT": "L57+L58",
    "FACULTY": "RAJU J"
}, {
    "CODE": "EEE2003",
    "TITLE": "Electromechanical Energy Conversion",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT423",
    "SLOT": "D2+TD2",
    "FACULTY": "RAJA SINGH R"
}, {
    "CODE": "EEE2003",
    "TITLE": "Electromechanical Energy Conversion",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT035",
    "SLOT": "L5+L6",
    "FACULTY": "RAJA SINGH R"
}, {
    "CODE": "EEE2003",
    "TITLE": "Electromechanical Energy Conversion",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT035",
    "SLOT": "L9+L10",
    "FACULTY": "RAJA SINGH R"
}, {
    "CODE": "EEE2003",
    "TITLE": "Electromechanical Energy Conversion",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT424",
    "SLOT": "D1+TD1",
    "FACULTY": "PALANISAMY K"
}, {
    "CODE": "EEE2003",
    "TITLE": "Electromechanical Energy Conversion",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT035",
    "SLOT": "L39+L40",
    "FACULTY": "PALANISAMY K"
}, {
    "CODE": "EEE2003",
    "TITLE": "Electromechanical Energy Conversion",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT035",
    "SLOT": "L55+L56",
    "FACULTY": "PALANISAMY K"
}, {
    "CODE": "EEE2003",
    "TITLE": "Electromechanical Energy Conversion",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT424",
    "SLOT": "D2+TD2",
    "FACULTY": "GOKULAKRISHNAN G"
}, {
    "CODE": "EEE2003",
    "TITLE": "Electromechanical Energy Conversion",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT035",
    "SLOT": "L15+L16",
    "FACULTY": "GOKULAKRISHNAN G"
}, {
    "CODE": "EEE2003",
    "TITLE": "Electromechanical Energy Conversion",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT035",
    "SLOT": "L21+L22",
    "FACULTY": "GOKULAKRISHNAN G"
}, {
    "CODE": "EEE2003",
    "TITLE": "Electromechanical Energy Conversion",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT434",
    "SLOT": "D1+TD1",
    "FACULTY": "ANBARASAN P"
}, {
    "CODE": "EEE2003",
    "TITLE": "Electromechanical Energy Conversion",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT035",
    "SLOT": "L37+L38",
    "FACULTY": "ANBARASAN P"
}, {
    "CODE": "EEE2003",
    "TITLE": "Electromechanical Energy Conversion",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT035",
    "SLOT": "L43+L44",
    "FACULTY": "ANBARASAN P"
}, {
    "CODE": "EEE2004",
    "TITLE": "Measurement and Instrumentation",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT201",
    "SLOT": "F1",
    "FACULTY": "MEDARAMETLA\nPRAVEENKUMAR"
}, {
    "CODE": "EEE2004",
    "TITLE": "Measurement and Instrumentation",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MEDARAMETLA\nPRAVEENKUMAR"
}, {
    "CODE": "EEE2004",
    "TITLE": "Measurement and Instrumentation",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT201",
    "SLOT": "F2",
    "FACULTY": "THAMILMARAN A"
}, {
    "CODE": "EEE2004",
    "TITLE": "Measurement and Instrumentation",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "THAMILMARAN A"
}, {
    "CODE": "EEE2005",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT104",
    "SLOT": "B1",
    "FACULTY": "MATHEW M. NOEL"
}, {
    "CODE": "EEE2005",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT515",
    "SLOT": "L39+L40",
    "FACULTY": "MATHEW M. NOEL"
}, {
    "CODE": "EEE2005",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT515",
    "SLOT": "L57+L58",
    "FACULTY": "MATHEW M. NOEL"
}, {
    "CODE": "EEE2005",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT201",
    "SLOT": "B2",
    "FACULTY": "AMUTHA PRABHA N"
}, {
    "CODE": "EEE2005",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT515",
    "SLOT": "L13+L14",
    "FACULTY": "AMUTHA PRABHA N"
}, {
    "CODE": "EEE2005",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT515",
    "SLOT": "L21+L22",
    "FACULTY": "AMUTHA PRABHA N"
}, {
    "CODE": "EEE2005",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT104",
    "SLOT": "B2",
    "FACULTY": "MAHALAKSHMI P"
}, {
    "CODE": "EEE2005",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT515",
    "SLOT": "L25+L26",
    "FACULTY": "MAHALAKSHMI P"
}, {
    "CODE": "EEE2005",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT515",
    "SLOT": "L29+L30",
    "FACULTY": "MAHALAKSHMI P"
}, {
    "CODE": "EEE2006",
    "TITLE": "Communication Engineering",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT434",
    "SLOT": "F2+TF2",
    "FACULTY": "ABHISHEK G"
}, {
    "CODE": "EEE2006",
    "TITLE": "Communication Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT129",
    "SLOT": "L3+L4",
    "FACULTY": "ABHISHEK G"
}, {
    "CODE": "EEE2006",
    "TITLE": "Communication Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT129",
    "SLOT": "L29+L30",
    "FACULTY": "ABHISHEK G"
}, {
    "CODE": "EEE3001",
    "TITLE": "Control Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT434A",
    "SLOT": "G2+TG2",
    "FACULTY": "DHANAMJAYULU C"
}, {
    "CODE": "EEE3001",
    "TITLE": "Control Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT045",
    "SLOT": "L11+L12",
    "FACULTY": "DHANAMJAYULU C"
}, {
    "CODE": "EEE3001",
    "TITLE": "Control Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT045",
    "SLOT": "L23+L24",
    "FACULTY": "DHANAMJAYULU C"
}, {
    "CODE": "EEE3002",
    "TITLE": "Analog and Digital Circuits",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT423",
    "SLOT": "A2+TA2",
    "FACULTY": "PRABHU K.R"
}, {
    "CODE": "EEE3002",
    "TITLE": "Analog and Digital Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT128",
    "SLOT": "L3+L4",
    "FACULTY": "PRABHU K.R"
}, {
    "CODE": "EEE3002",
    "TITLE": "Analog and Digital Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT128",
    "SLOT": "L13+L14",
    "FACULTY": "PRABHU K.R"
}, {
    "CODE": "EEE3002",
    "TITLE": "Analog and Digital Circuits",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT423",
    "SLOT": "A1+TA1",
    "FACULTY": "SUDHAKAR N"
}, {
    "CODE": "EEE3002",
    "TITLE": "Analog and Digital Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT128",
    "SLOT": "L33+L34",
    "FACULTY": "SUDHAKAR N"
}, {
    "CODE": "EEE3002",
    "TITLE": "Analog and Digital Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT128",
    "SLOT": "L47+L48",
    "FACULTY": "SUDHAKAR N"
}, {
    "CODE": "EEE3002",
    "TITLE": "Analog and Digital Circuits",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT424",
    "SLOT": "A1+TA1",
    "FACULTY": "MONICA SUBASHINI M"
}, {
    "CODE": "EEE3002",
    "TITLE": "Analog and Digital Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT128",
    "SLOT": "L51+L52",
    "FACULTY": "MONICA SUBASHINI M"
}, {
    "CODE": "EEE3002",
    "TITLE": "Analog and Digital Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT128",
    "SLOT": "L55+L56",
    "FACULTY": "MONICA SUBASHINI M"
}, {
    "CODE": "EEE3002",
    "TITLE": "Analog and Digital Circuits",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT424",
    "SLOT": "A2+TA2",
    "FACULTY": "VENKATARAMAN M.N"
}, {
    "CODE": "EEE3002",
    "TITLE": "Analog and Digital Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT128",
    "SLOT": "L11+L12",
    "FACULTY": "VENKATARAMAN M.N"
}, {
    "CODE": "EEE3002",
    "TITLE": "Analog and Digital Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT128",
    "SLOT": "L29+L30",
    "FACULTY": "VENKATARAMAN M.N"
}, {
    "CODE": "EEE3002",
    "TITLE": "Analog and Digital Circuits",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT434",
    "SLOT": "A1+TA1",
    "FACULTY": "RASHMI RANJAN DAS"
}, {
    "CODE": "EEE3002",
    "TITLE": "Analog and Digital Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT128",
    "SLOT": "L49+L50",
    "FACULTY": "RASHMI RANJAN DAS"
}, {
    "CODE": "EEE3002",
    "TITLE": "Analog and Digital Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT128",
    "SLOT": "L53+L54",
    "FACULTY": "RASHMI RANJAN DAS"
}, {
    "CODE": "EEE3002",
    "TITLE": "Analog and Digital Circuits",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT434",
    "SLOT": "A2+TA2",
    "FACULTY": "VIDHYA SAGAR G"
}, {
    "CODE": "EEE3002",
    "TITLE": "Analog and Digital Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT128",
    "SLOT": "L19+L20",
    "FACULTY": "VIDHYA SAGAR G"
}, {
    "CODE": "EEE3002",
    "TITLE": "Analog and Digital Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT128",
    "SLOT": "L23+L24",
    "FACULTY": "VIDHYA SAGAR G"
}, {
    "CODE": "EEE3003",
    "TITLE": "Power System Engineering",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT204",
    "SLOT": "B2+TB2",
    "FACULTY": "KOWSALYA M"
}, {
    "CODE": "EEE3003",
    "TITLE": "Power System Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT247",
    "SLOT": "L3+L4",
    "FACULTY": "KOWSALYA M"
}, {
    "CODE": "EEE3003",
    "TITLE": "Power System Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT247",
    "SLOT": "L11+L12",
    "FACULTY": "KOWSALYA M"
}, {
    "CODE": "EEE3004",
    "TITLE": "Power Electronics and Drives",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT104",
    "SLOT": "C1+TC1",
    "FACULTY": "SARAVANAKUMAR R"
}, {
    "CODE": "EEE3004",
    "TITLE": "Power Electronics and Drives",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT044",
    "SLOT": "L33+L34",
    "FACULTY": "SARAVANAKUMAR R"
}, {
    "CODE": "EEE3004",
    "TITLE": "Power Electronics and Drives",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT044",
    "SLOT": "L57+L58",
    "FACULTY": "SARAVANAKUMAR R"
}, {
    "CODE": "EEE3004",
    "TITLE": "Power Electronics and Drives",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT104",
    "SLOT": "C2+TC2",
    "FACULTY": "YEDDULA PEDDA OBULESU"
}, {
    "CODE": "EEE3004",
    "TITLE": "Power Electronics and Drives",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT044",
    "SLOT": "L3+L4",
    "FACULTY": "YEDDULA PEDDA OBULESU"
}, {
    "CODE": "EEE3004",
    "TITLE": "Power Electronics and Drives",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT044",
    "SLOT": "L13+L14",
    "FACULTY": "YEDDULA PEDDA OBULESU"
}, {
    "CODE": "EEE3004",
    "TITLE": "Power Electronics and Drives",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT201",
    "SLOT": "C1+TC1",
    "FACULTY": "SUBRAMANIAN K"
}, {
    "CODE": "EEE3004",
    "TITLE": "Power Electronics and Drives",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT044",
    "SLOT": "L43+L44",
    "FACULTY": "SUBRAMANIAN K"
}, {
    "CODE": "EEE3004",
    "TITLE": "Power Electronics and Drives",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT044",
    "SLOT": "L53+L54",
    "FACULTY": "SUBRAMANIAN K"
}, {
    "CODE": "EEE3004",
    "TITLE": "Power Electronics and Drives",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT201",
    "SLOT": "C2+TC2",
    "FACULTY": "ARUN N"
}, {
    "CODE": "EEE3004",
    "TITLE": "Power Electronics and Drives",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT044",
    "SLOT": "L1+L2",
    "FACULTY": "ARUN N"
}, {
    "CODE": "EEE3004",
    "TITLE": "Power Electronics and Drives",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT044",
    "SLOT": "L9+L10",
    "FACULTY": "ARUN N"
}, {
    "CODE": "EEE3005",
    "TITLE": "Design of Electrical Apparatus",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT204",
    "SLOT": "F1",
    "FACULTY": "VIJAYAKUMAR D"
}, {
    "CODE": "EEE3005",
    "TITLE": "Design of Electrical Apparatus",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIJAYAKUMAR D"
}, {
    "CODE": "EEE3005",
    "TITLE": "Design of Electrical Apparatus",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT204",
    "SLOT": "F2",
    "FACULTY": "VIJAYAKUMAR D"
}, {
    "CODE": "EEE3005",
    "TITLE": "Design of Electrical Apparatus",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIJAYAKUMAR D"
}, {
    "CODE": "EEE3006",
    "TITLE": "Special Electrical Machines",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT201",
    "SLOT": "G2+TG2",
    "FACULTY": "SUBRAMANIAN K"
}, {
    "CODE": "EEE3006",
    "TITLE": "Special Electrical Machines",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT204",
    "SLOT": "G1+TG1",
    "FACULTY": "VIJAYA PRIYA P"
}, {
    "CODE": "EEE3009",
    "TITLE": "Digital Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT201",
    "SLOT": "E1+TE1",
    "FACULTY": "ABHISHEK G"
}, {
    "CODE": "EEE3009",
    "TITLE": "Digital Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ABHISHEK G"
}, {
    "CODE": "EEE3999",
    "TITLE": "Technical Answers for Real World\nProblems (TARP)",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "TT204",
    "SLOT": "TG2",
    "FACULTY": "ARULMOZHIVARMAN P"
}, {
    "CODE": "EEE3999",
    "TITLE": "Technical Answers for Real World\nProblems (TARP)",
    "TYPE": "EPJ",
    "CREDITS": "2",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ARULMOZHIVARMAN P"
}, {
    "CODE": "EEE4001",
    "TITLE": "Microprocessor and Microcontroller",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT104",
    "SLOT": "A2",
    "FACULTY": "SUDHA R"
}, {
    "CODE": "EEE4001",
    "TITLE": "Microprocessor and Microcontroller",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT515",
    "SLOT": "L9+L10",
    "FACULTY": "SUDHA R"
}, {
    "CODE": "EEE4001",
    "TITLE": "Microprocessor and Microcontroller",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT515",
    "SLOT": "L19+L20",
    "FACULTY": "SUDHA R"
}, {
    "CODE": "EEE4001",
    "TITLE": "Microprocessor and Microcontroller",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT201",
    "SLOT": "A2",
    "FACULTY": "PONNAMBALAM P"
}, {
    "CODE": "EEE4001",
    "TITLE": "Microprocessor and Microcontroller",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT515",
    "SLOT": "L5+L6",
    "FACULTY": "PONNAMBALAM P"
}, {
    "CODE": "EEE4001",
    "TITLE": "Microprocessor and Microcontroller",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT515",
    "SLOT": "L15+L16",
    "FACULTY": "PONNAMBALAM P"
}, {
    "CODE": "EEE4001",
    "TITLE": "Microprocessor and Microcontroller",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT204",
    "SLOT": "A2",
    "FACULTY": "RAMA PRABHA D"
}, {
    "CODE": "EEE4001",
    "TITLE": "Microprocessor and Microcontroller",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT515",
    "SLOT": "L11+L12",
    "FACULTY": "RAMA PRABHA D"
}, {
    "CODE": "EEE4001",
    "TITLE": "Microprocessor and Microcontroller",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT515",
    "SLOT": "L27+L28",
    "FACULTY": "RAMA PRABHA D"
}, {
    "CODE": "EEE4001",
    "TITLE": "Microprocessor and Microcontroller",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT104",
    "SLOT": "A1",
    "FACULTY": "MARIMUTHU R"
}, {
    "CODE": "EEE4001",
    "TITLE": "Microprocessor and Microcontroller",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT515",
    "SLOT": "L31+L32",
    "FACULTY": "MARIMUTHU R"
}, {
    "CODE": "EEE4001",
    "TITLE": "Microprocessor and Microcontroller",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT515",
    "SLOT": "L45+L46",
    "FACULTY": "MARIMUTHU R"
}, {
    "CODE": "EEE4001",
    "TITLE": "Microprocessor and Microcontroller",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT201",
    "SLOT": "A1",
    "FACULTY": "SANTHAKUMAR R"
}, {
    "CODE": "EEE4001",
    "TITLE": "Microprocessor and Microcontroller",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT515",
    "SLOT": "L47+L48",
    "FACULTY": "SANTHAKUMAR R"
}, {
    "CODE": "EEE4001",
    "TITLE": "Microprocessor and Microcontroller",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT515",
    "SLOT": "L49+L50",
    "FACULTY": "SANTHAKUMAR R"
}, {
    "CODE": "EEE4002",
    "TITLE": "Power System Protection and\nSwitchgear",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT104",
    "SLOT": "G1+TG1",
    "FACULTY": "JAYABARATHI T"
}, {
    "CODE": "EEE4002",
    "TITLE": "Power System Protection and\nSwitchgear",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT037",
    "SLOT": "L33+L34",
    "FACULTY": "JAYABARATHI T"
}, {
    "CODE": "EEE4002",
    "TITLE": "Power System Protection and\nSwitchgear",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT037",
    "SLOT": "L57+L58",
    "FACULTY": "JAYABARATHI T"
}, {
    "CODE": "EEE4003",
    "TITLE": "Generation and Utilization of Electrical\nEnergy",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT434A",
    "SLOT": "E1",
    "FACULTY": "SARAVANAN B"
}, {
    "CODE": "EEE4003",
    "TITLE": "Generation and Utilization of Electrical\nEnergy",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SARAVANAN B"
}, {
    "CODE": "EEE4004",
    "TITLE": "Distributed Generation and Microgrids",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT104",
    "SLOT": "E1+TE1",
    "FACULTY": "KOWSALYA M"
}, {
    "CODE": "EEE4004",
    "TITLE": "Distributed Generation and Microgrids",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KOWSALYA M"
}, {
    "CODE": "EEE4005",
    "TITLE": "Power System Operation and Control",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT434A",
    "SLOT": "F2",
    "FACULTY": "ANBARASAN P"
}, {
    "CODE": "EEE4005",
    "TITLE": "Power System Operation and Control",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANBARASAN P"
}, {
    "CODE": "EEE4006",
    "TITLE": "Restructured Power Systems",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT434A",
    "SLOT": "G1+TG1",
    "FACULTY": "PRABHAKAR KARTHIKEYAN S"
}, {
    "CODE": "EEE4007",
    "TITLE": "Energy Management and SCADA",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT434A",
    "SLOT": "C1+TC1",
    "FACULTY": "SRIHARI MANDAVA"
}, {
    "CODE": "EEE4009",
    "TITLE": "FACTS and HVDC",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT201",
    "SLOT": "E2+TE2",
    "FACULTY": "RAVI K"
}, {
    "CODE": "EEE4009",
    "TITLE": "FACTS and HVDC",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAVI K"
}, {
    "CODE": "EEE4010",
    "TITLE": "Power Quality",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT434A",
    "SLOT": "F1",
    "FACULTY": "CHILUKURI VENKATA\nMAHENDRA"
}, {
    "CODE": "EEE4010",
    "TITLE": "Power Quality",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "CHILUKURI VENKATA\nMAHENDRA"
}, {
    "CODE": "EEE4011",
    "TITLE": "Energy Audit and Conservation",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT434A",
    "SLOT": "E2",
    "FACULTY": "GOKULAKRISHNAN G"
}, {
    "CODE": "EEE4011",
    "TITLE": "Energy Audit and Conservation",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GOKULAKRISHNAN G"
}, {
    "CODE": "EEE4012",
    "TITLE": "Renewable Energy Sources",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT333",
    "SLOT": "D2+TD2",
    "FACULTY": "SANKARDOSS V"
}, {
    "CODE": "EEE4013",
    "TITLE": "Smart Grid",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT204",
    "SLOT": "E2+TE2",
    "FACULTY": "CHILUKURI VENKATA\nMAHENDRA"
}, {
    "CODE": "EEE4013",
    "TITLE": "Smart Grid",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "CHILUKURI VENKATA\nMAHENDRA"
}, {
    "CODE": "EEE4014",
    "TITLE": "Switched Mode Power Conversion",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT434",
    "SLOT": "D2",
    "FACULTY": "ELANGOVAN D"
}, {
    "CODE": "EEE4014",
    "TITLE": "Switched Mode Power Conversion",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ELANGOVAN D"
}, {
    "CODE": "EEE4016",
    "TITLE": "Electric Vehicles",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT334",
    "SLOT": "C2",
    "FACULTY": "CHITRA A"
}, {
    "CODE": "EEE4016",
    "TITLE": "Electric Vehicles",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "CHITRA A"
}, {
    "CODE": "EEE4018",
    "TITLE": "Advanced Control Theory",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT333",
    "SLOT": "B2+TB2",
    "FACULTY": "RAGHUNATHAN T"
}, {
    "CODE": "EEE4018",
    "TITLE": "Advanced Control Theory",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAGHUNATHAN T"
}, {
    "CODE": "EEE4018",
    "TITLE": "Advanced Control Theory",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT201",
    "SLOT": "B1+TB1",
    "FACULTY": "KAVITHA P"
}, {
    "CODE": "EEE4018",
    "TITLE": "Advanced Control Theory",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KAVITHA P"
}, {
    "CODE": "EEE4019",
    "TITLE": "Advanced Digital System Design With\nFPGAs",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT204",
    "SLOT": "G2",
    "FACULTY": "BALAMURUGAN S"
}, {
    "CODE": "EEE4019",
    "TITLE": "Advanced Digital System Design With\nFPGAs",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BALAMURUGAN S"
}, {
    "CODE": "EEE4021",
    "TITLE": "Sensors and Signal Conditioning",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT434A",
    "SLOT": "D1+TD1",
    "FACULTY": "RAJINI G.K"
}, {
    "CODE": "EEE4021",
    "TITLE": "Sensors and Signal Conditioning",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT514",
    "SLOT": "L37+L38",
    "FACULTY": "RAJINI G.K"
}, {
    "CODE": "EEE4021",
    "TITLE": "Sensors and Signal Conditioning",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT514",
    "SLOT": "L55+L56",
    "FACULTY": "RAJINI G.K"
}, {
    "CODE": "EEE4021",
    "TITLE": "Sensors and Signal Conditioning",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT434A",
    "SLOT": "D2+TD2",
    "FACULTY": "RAJINI G.K"
}, {
    "CODE": "EEE4021",
    "TITLE": "Sensors and Signal Conditioning",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT514",
    "SLOT": "L5+L6",
    "FACULTY": "RAJINI G.K"
}, {
    "CODE": "EEE4021",
    "TITLE": "Sensors and Signal Conditioning",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT514",
    "SLOT": "L9+L10",
    "FACULTY": "RAJINI G.K"
}, {
    "CODE": "EEE4024",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT204",
    "SLOT": "C2+TC2",
    "FACULTY": "MARIMUTHU R"
}, {
    "CODE": "EEE4027",
    "TITLE": "Robotics and Control",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT531A",
    "SLOT": "A2",
    "FACULTY": "RASHMI RANJAN DAS"
}, {
    "CODE": "EEE4027",
    "TITLE": "Robotics and Control",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RASHMI RANJAN DAS"
}, {
    "CODE": "EEE4027",
    "TITLE": "Robotics and Control",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT434A",
    "SLOT": "A1",
    "FACULTY": "VINODH KUMAR E"
}, {
    "CODE": "EEE4027",
    "TITLE": "Robotics and Control",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VINODH KUMAR E"
}, {
    "CODE": "EEE4028",
    "TITLE": "VLSI Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT204",
    "SLOT": "E1+TE1",
    "FACULTY": "BALAMURUGAN S"
}, {
    "CODE": "EEE4028",
    "TITLE": "VLSI Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT128",
    "SLOT": "L41+L42",
    "FACULTY": "BALAMURUGAN S"
}, {
    "CODE": "EEE4028",
    "TITLE": "VLSI Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT128",
    "SLOT": "L43+L44",
    "FACULTY": "BALAMURUGAN S"
}, {
    "CODE": "EEE4031",
    "TITLE": "Electrical and Electronic\nInstrumentation",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT434A",
    "SLOT": "A2+TA2",
    "FACULTY": "BAGYAVEERESWARAN V"
}, {
    "CODE": "EEE4031",
    "TITLE": "Electrical and Electronic\nInstrumentation",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT514",
    "SLOT": "L7+L8",
    "FACULTY": "BAGYAVEERESWARAN V"
}, {
    "CODE": "EEE4031",
    "TITLE": "Electrical and Electronic\nInstrumentation",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT514",
    "SLOT": "L13+L14",
    "FACULTY": "BAGYAVEERESWARAN V"
}, {
    "CODE": "EEE4032",
    "TITLE": "Process Automation and Control",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT104",
    "SLOT": "E2+TE2",
    "FACULTY": "JAGANATHA PANDIAN B"
}, {
    "CODE": "EEE4032",
    "TITLE": "Process Automation and Control",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT521",
    "SLOT": "L5+L6",
    "FACULTY": "JAGANATHA PANDIAN B"
}, {
    "CODE": "EEE4032",
    "TITLE": "Process Automation and Control",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT521",
    "SLOT": "L23+L24",
    "FACULTY": "JAGANATHA PANDIAN B"
}, {
    "CODE": "EEE4033",
    "TITLE": "Industrial Instrumentation",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT434",
    "SLOT": "F1+TF1",
    "FACULTY": "BAGYAVEERESWARAN V"
}, {
    "CODE": "EEE4033",
    "TITLE": "Industrial Instrumentation",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BAGYAVEERESWARAN V"
}, {
    "CODE": "EEE4034",
    "TITLE": "Wireless Sensor Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT104",
    "SLOT": "G2+TG2",
    "FACULTY": "BALAJI S"
}, {
    "CODE": "EEE4034",
    "TITLE": "Wireless Sensor Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BALAJI S"
}, {
    "CODE": "EEE4099",
    "TITLE": "Capstone Project",
    "TYPE": "PJT",
    "CREDITS": "20",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "EEE499",
    "TITLE": "Project Work",
    "TYPE": "PJT",
    "CREDITS": "20",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "EEE6099",
    "TITLE": "Masters Thesis",
    "TYPE": "PJT",
    "CREDITS": "16",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "EIE499",
    "TITLE": "Project Work",
    "TYPE": "PJT",
    "CREDITS": "20",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "ECE1002",
    "TITLE": "Semiconductor Devices and Circuits",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CBMR30\n1",
    "SLOT": "F1+TF1",
    "FACULTY": "GAUTAM NARAYAN"
}, {
    "CODE": "ECE1002",
    "TITLE": "Semiconductor Devices and Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "CBMR30\n5",
    "SLOT": "L31+L32",
    "FACULTY": "GAUTAM NARAYAN"
}, {
    "CODE": "ECE1002",
    "TITLE": "Semiconductor Devices and Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "CBMR30\n5",
    "SLOT": "L43+L44",
    "FACULTY": "GAUTAM NARAYAN"
}, {
    "CODE": "ECE1003",
    "TITLE": "Electromagnetic Field Theory",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT335",
    "SLOT": "G1+TG1",
    "FACULTY": "SRINIVASA RAO INABATHINI"
}, {
    "CODE": "ECE1003",
    "TITLE": "Electromagnetic Field Theory",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT335",
    "SLOT": "G2+TG2",
    "FACULTY": "SRINIVASA RAO INABATHINI"
}, {
    "CODE": "ECE1003",
    "TITLE": "Electromagnetic Field Theory",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT504",
    "SLOT": "G1+TG1",
    "FACULTY": "VIJAY KUMAR"
}, {
    "CODE": "ECE1003",
    "TITLE": "Electromagnetic Field Theory",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT504",
    "SLOT": "G2+TG2",
    "FACULTY": "VIJAY KUMAR"
}, {
    "CODE": "ECE1003",
    "TITLE": "Electromagnetic Field Theory",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT523",
    "SLOT": "G1+TG1",
    "FACULTY": "YOGESH KUMAR CHOUKIKER"
}, {
    "CODE": "ECE1003",
    "TITLE": "Electromagnetic Field Theory",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT523",
    "SLOT": "G2+TG2",
    "FACULTY": "YOGESH KUMAR CHOUKIKER"
}, {
    "CODE": "ECE1003",
    "TITLE": "Electromagnetic Field Theory",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT524",
    "SLOT": "G1+TG1",
    "FACULTY": "GAUTAM NARAYAN"
}, {
    "CODE": "ECE1003",
    "TITLE": "Electromagnetic Field Theory",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT524",
    "SLOT": "G2+TG2",
    "FACULTY": "GAUTAM NARAYAN"
}, {
    "CODE": "ECE1003",
    "TITLE": "Electromagnetic Field Theory",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT619",
    "SLOT": "G1+TG1",
    "FACULTY": "LAVANYA N"
}, {
    "CODE": "ECE1003",
    "TITLE": "Electromagnetic Field Theory",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT619",
    "SLOT": "G2+TG2",
    "FACULTY": "LAVANYA N"
}, {
    "CODE": "ECE1003",
    "TITLE": "Electromagnetic Field Theory",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT620",
    "SLOT": "G1+TG1",
    "FACULTY": "SUJATHA R"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT335",
    "SLOT": "C1",
    "FACULTY": "LOKANATH M"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "LOKANATH M"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT335",
    "SLOT": "C2",
    "FACULTY": "LOKANATH M"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "LOKANATH M"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT504",
    "SLOT": "C1",
    "FACULTY": "AVINASH CHANDRA"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AVINASH CHANDRA"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT504",
    "SLOT": "C2",
    "FACULTY": "AVINASH CHANDRA"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AVINASH CHANDRA"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT523",
    "SLOT": "C1",
    "FACULTY": "RAMACHANDRA REDDY"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMACHANDRA REDDY"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT523",
    "SLOT": "C2",
    "FACULTY": "RAJESH KUMAR M"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJESH KUMAR M"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT524",
    "SLOT": "C1",
    "FACULTY": "NAVEEN GUPTA"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NAVEEN GUPTA"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT524",
    "SLOT": "C2",
    "FACULTY": "NAVEEN GUPTA"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NAVEEN GUPTA"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT619",
    "SLOT": "C2",
    "FACULTY": "YEPUGANTI KARUNA"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "YEPUGANTI KARUNA"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CBMR30\n1",
    "SLOT": "C1",
    "FACULTY": "DEEPA MADATHIL"
}, {
    "CODE": "ECE1004",
    "TITLE": "Signals and Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DEEPA MADATHIL"
}, {
    "CODE": "ECE1005",
    "TITLE": "Sensors and Instrumentation",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "TT335",
    "SLOT": "TE2",
    "FACULTY": "MUTHU RAJA S"
}, {
    "CODE": "ECE1005",
    "TITLE": "Sensors and Instrumentation",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MUTHU RAJA S"
}, {
    "CODE": "ECE1006",
    "TITLE": "Introduction to Nanoscience and\nNanotechnology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT630",
    "SLOT": "E1",
    "FACULTY": "MUTHU RAJA S"
}, {
    "CODE": "ECE1006",
    "TITLE": "Introduction to Nanoscience and\nNanotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MUTHU RAJA S"
}, {
    "CODE": "ECE1006",
    "TITLE": "Introduction to Nanoscience and\nNanotechnology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT631",
    "SLOT": "E1",
    "FACULTY": "NIROJ KUMAR SAHU"
}, {
    "CODE": "ECE1006",
    "TITLE": "Introduction to Nanoscience and\nNanotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NIROJ KUMAR SAHU"
}, {
    "CODE": "ECE1006",
    "TITLE": "Introduction to Nanoscience and\nNanotechnology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT631",
    "SLOT": "E2",
    "FACULTY": "RAJA SELLAPPAN"
}, {
    "CODE": "ECE1006",
    "TITLE": "Introduction to Nanoscience and\nNanotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJA SELLAPPAN"
}, {
    "CODE": "ECE1006",
    "TITLE": "Introduction to Nanoscience and\nNanotechnology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT715",
    "SLOT": "E1",
    "FACULTY": "SAKTHI SWARRUP J"
}, {
    "CODE": "ECE1006",
    "TITLE": "Introduction to Nanoscience and\nNanotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SAKTHI SWARRUP J"
}, {
    "CODE": "ECE1006",
    "TITLE": "Introduction to Nanoscience and\nNanotechnology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT715",
    "SLOT": "E2",
    "FACULTY": "SATHYANARAYANAN P"
}, {
    "CODE": "ECE1006",
    "TITLE": "Introduction to Nanoscience and\nNanotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SATHYANARAYANAN P"
}, {
    "CODE": "ECE1006",
    "TITLE": "Introduction to Nanoscience and\nNanotechnology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CBMR10\n1",
    "SLOT": "F1",
    "FACULTY": "SAKTHI SWARRUP J"
}, {
    "CODE": "ECE1006",
    "TITLE": "Introduction to Nanoscience and\nNanotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SAKTHI SWARRUP J"
}, {
    "CODE": "ECE1006",
    "TITLE": "Introduction to Nanoscience and\nNanotechnology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CBMR30\n1",
    "SLOT": "F2",
    "FACULTY": "SATHYANARAYANAN P"
}, {
    "CODE": "ECE1006",
    "TITLE": "Introduction to Nanoscience and\nNanotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SATHYANARAYANAN P"
}, {
    "CODE": "ECE1006",
    "TITLE": "Introduction to Nanoscience and\nNanotechnology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT630",
    "SLOT": "D1",
    "FACULTY": "MUTHU RAJA S"
}, {
    "CODE": "ECE1006",
    "TITLE": "Introduction to Nanoscience and\nNanotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MUTHU RAJA S"
}, {
    "CODE": "ECE1006",
    "TITLE": "Introduction to Nanoscience and\nNanotechnology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT631",
    "SLOT": "D1",
    "FACULTY": "RAJA SELLAPPAN"
}, {
    "CODE": "ECE1006",
    "TITLE": "Introduction to Nanoscience and\nNanotechnology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJA SELLAPPAN"
}, {
    "CODE": "ECE1007",
    "TITLE": "Opto Electronics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT335",
    "SLOT": "F1+TF1",
    "FACULTY": "SANGEETHA A"
}, {
    "CODE": "ECE1007",
    "TITLE": "Opto Electronics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT335",
    "SLOT": "F2+TF2",
    "FACULTY": "SANGEETHA A"
}, {
    "CODE": "ECE1007",
    "TITLE": "Opto Electronics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT504",
    "SLOT": "F1+TF1",
    "FACULTY": "RAJALAKSHMI S"
}, {
    "CODE": "ECE1007",
    "TITLE": "Opto Electronics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT504",
    "SLOT": "F2+TF2",
    "FACULTY": "RAJALAKSHMI S"
}, {
    "CODE": "ECE1007",
    "TITLE": "Opto Electronics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT715",
    "SLOT": "D2+TD2",
    "FACULTY": "JABEENA A"
}, {
    "CODE": "ECE1007",
    "TITLE": "Opto Electronics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT716",
    "SLOT": "D1+TD1",
    "FACULTY": "REVATHI S"
}, {
    "CODE": "ECE1007",
    "TITLE": "Opto Electronics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT724",
    "SLOT": "D1+TD1",
    "FACULTY": "SANGEETHA N"
}, {
    "CODE": "ECE1011",
    "TITLE": "Medical Physics and Biomedical\nInstrumentation",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "CBMR30\n5",
    "SLOT": "L23+L24",
    "FACULTY": "BHASKAR MOHAN MURARI"
}, {
    "CODE": "ECE1011",
    "TITLE": "Medical Physics and Biomedical\nInstrumentation",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CBMR10\n1",
    "SLOT": "G2+TG2",
    "FACULTY": "BHASKAR MOHAN MURARI"
}, {
    "CODE": "ECE1011",
    "TITLE": "Medical Physics and Biomedical\nInstrumentation",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "CBMR30\n5",
    "SLOT": "L5+L6",
    "FACULTY": "BHASKAR MOHAN MURARI"
}, {
    "CODE": "ECE1014",
    "TITLE": "Sensors and Measurements",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT726",
    "SLOT": "A2",
    "FACULTY": "SUMIT KUMAR JINDAL"
}, {
    "CODE": "ECE1014",
    "TITLE": "Sensors and Measurements",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "CBMR30\n5",
    "SLOT": "L7+L8",
    "FACULTY": "SUMIT KUMAR JINDAL"
}, {
    "CODE": "ECE1014",
    "TITLE": "Sensors and Measurements",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "CBMR30\n5",
    "SLOT": "L27+L28",
    "FACULTY": "SUMIT KUMAR JINDAL"
}, {
    "CODE": "ECE1018",
    "TITLE": "Signal Analysis and Processing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT724",
    "SLOT": "A1",
    "FACULTY": "CHRISTOPHER CLEMENT J"
}, {
    "CODE": "ECE1018",
    "TITLE": "Signal Analysis and Processing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT724",
    "SLOT": "A2",
    "FACULTY": "CHRISTOPHER CLEMENT J"
}, {
    "CODE": "ECE1018",
    "TITLE": "Signal Analysis and Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT231",
    "SLOT": "L15+L16",
    "FACULTY": "CHRISTOPHER CLEMENT J"
}, {
    "CODE": "ECE1018",
    "TITLE": "Signal Analysis and Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "CHRISTOPHER CLEMENT J"
}, {
    "CODE": "ECE1018",
    "TITLE": "Signal Analysis and Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT231",
    "SLOT": "L21+L22",
    "FACULTY": "CHRISTOPHER CLEMENT J"
}, {
    "CODE": "ECE1018",
    "TITLE": "Signal Analysis and Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "CHRISTOPHER CLEMENT J"
}, {
    "CODE": "ECE1018",
    "TITLE": "Signal Analysis and Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT231",
    "SLOT": "L37+L38",
    "FACULTY": "CHRISTOPHER CLEMENT J"
}, {
    "CODE": "ECE1018",
    "TITLE": "Signal Analysis and Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "CHRISTOPHER CLEMENT J"
}, {
    "CODE": "ECE1018",
    "TITLE": "Signal Analysis and Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT231",
    "SLOT": "L55+L56",
    "FACULTY": "CHRISTOPHER CLEMENT J"
}, {
    "CODE": "ECE1018",
    "TITLE": "Signal Analysis and Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "CHRISTOPHER CLEMENT J"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT335",
    "SLOT": "B1",
    "FACULTY": "SURESH KUMAR T R"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT335",
    "SLOT": "B2",
    "FACULTY": "SURESH KUMAR T R"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT504",
    "SLOT": "B1",
    "FACULTY": "AARTHI G"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT504",
    "SLOT": "B2",
    "FACULTY": "AARTHI G"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT523",
    "SLOT": "B1",
    "FACULTY": "RAJEEV PANKAJ NELAPATI"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT523",
    "SLOT": "B2",
    "FACULTY": "RAJEEV PANKAJ NELAPATI"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT715",
    "SLOT": "B2",
    "FACULTY": "RAJESHKUMAR V"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT631",
    "SLOT": "B2",
    "FACULTY": "AARTHY M"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT630",
    "SLOT": "B1",
    "FACULTY": "SUBHA BHARATHI S"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT630",
    "SLOT": "B2",
    "FACULTY": "SUBHA BHARATHI S"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT715",
    "SLOT": "B1",
    "FACULTY": "RAJESHKUMAR V"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT631",
    "SLOT": "B1",
    "FACULTY": "AARTHY M"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L15+L16",
    "FACULTY": "SURESH KUMAR T R"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SURESH KUMAR T R"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L29+L30",
    "FACULTY": "SURESH KUMAR T R"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SURESH KUMAR T R"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L35+L36",
    "FACULTY": "SURESH KUMAR T R"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SURESH KUMAR T R"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L39+L40",
    "FACULTY": "SURESH KUMAR T R"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SURESH KUMAR T R"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L3+L4",
    "FACULTY": "AARTHI G"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AARTHI G"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L25+L26",
    "FACULTY": "AARTHI G"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AARTHI G"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L31+L32",
    "FACULTY": "AARTHI G"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AARTHI G"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L45+L46",
    "FACULTY": "AARTHI G"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AARTHI G"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L9+L10",
    "FACULTY": "RAJEEV PANKAJ NELAPATI"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJEEV PANKAJ NELAPATI"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L13+L14",
    "FACULTY": "RAJEEV PANKAJ NELAPATI"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJEEV PANKAJ NELAPATI"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L33+L34",
    "FACULTY": "RAJEEV PANKAJ NELAPATI"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJEEV PANKAJ NELAPATI"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L55+L56",
    "FACULTY": "RAJEEV PANKAJ NELAPATI"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJEEV PANKAJ NELAPATI"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L1+L2",
    "FACULTY": "RAJESHKUMAR V"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJESHKUMAR V"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L21+L22",
    "FACULTY": "RAJESHKUMAR V"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJESHKUMAR V"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L43+L44",
    "FACULTY": "RAJESHKUMAR V"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJESHKUMAR V"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L53+L54",
    "FACULTY": "RAJESHKUMAR V"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJESHKUMAR V"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L11+L12",
    "FACULTY": "AARTHY M"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AARTHY M"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L27+L28",
    "FACULTY": "AARTHY M"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AARTHY M"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L41+L42",
    "FACULTY": "AARTHY M"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AARTHY M"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L51+L52",
    "FACULTY": "AARTHY M"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AARTHY M"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L5+L6",
    "FACULTY": "SUBHA BHARATHI S"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUBHA BHARATHI S"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L23+L24",
    "FACULTY": "SUBHA BHARATHI S"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUBHA BHARATHI S"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L47+L48",
    "FACULTY": "SUBHA BHARATHI S"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUBHA BHARATHI S"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT503",
    "SLOT": "L57+L58",
    "FACULTY": "SUBHA BHARATHI S"
}, {
    "CODE": "ECE2002",
    "TITLE": "Analog Electronic Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUBHA BHARATHI S"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT335",
    "SLOT": "A1",
    "FACULTY": "SRI ADIBHATLA SRIDEVI"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT335",
    "SLOT": "A2",
    "FACULTY": "SRI ADIBHATLA SRIDEVI"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT504",
    "SLOT": "A1",
    "FACULTY": "JAGANNADHA NAIDU K"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT504",
    "SLOT": "A2",
    "FACULTY": "JAGANNADHA NAIDU K"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT523",
    "SLOT": "A1",
    "FACULTY": "PRAYLINE RAJABAI C"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT523",
    "SLOT": "A2",
    "FACULTY": "PRAYLINE RAJABAI C"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT524",
    "SLOT": "A1",
    "FACULTY": "RAGUNATH G"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT524",
    "SLOT": "A2",
    "FACULTY": "RAGUNATH G"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT619",
    "SLOT": "A1",
    "FACULTY": "RAVI S"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT619",
    "SLOT": "A2",
    "FACULTY": "RAVI S"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT620",
    "SLOT": "A1",
    "FACULTY": "JAYAKRISHNAN P"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT620",
    "SLOT": "A2",
    "FACULTY": "SATHEESH KUMAR S"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L37+L38",
    "FACULTY": "SRI ADIBHATLA SRIDEVI"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L51+L52",
    "FACULTY": "SRI ADIBHATLA SRIDEVI"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L9+L10",
    "FACULTY": "SRI ADIBHATLA SRIDEVI"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L19+L20",
    "FACULTY": "SRI ADIBHATLA SRIDEVI"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L35+L36",
    "FACULTY": "JAGANNADHA NAIDU K"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L39+L40",
    "FACULTY": "JAGANNADHA NAIDU K"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L11+L12",
    "FACULTY": "JAGANNADHA NAIDU K"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L21+L22",
    "FACULTY": "JAGANNADHA NAIDU K"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L33+L34",
    "FACULTY": "PRAYLINE RAJABAI C"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L57+L58",
    "FACULTY": "PRAYLINE RAJABAI C"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L15+L16",
    "FACULTY": "PRAYLINE RAJABAI C"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L25+L26",
    "FACULTY": "PRAYLINE RAJABAI C"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L45+L46",
    "FACULTY": "RAGUNATH G"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L49+L50",
    "FACULTY": "RAGUNATH G"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L5+L6",
    "FACULTY": "RAGUNATH G"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L7+L8",
    "FACULTY": "RAGUNATH G"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L47+L48",
    "FACULTY": "RAVI S"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L55+L56",
    "FACULTY": "RAVI S"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L3+L4",
    "FACULTY": "RAVI S"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L27+L28",
    "FACULTY": "RAVI S"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L41+L42",
    "FACULTY": "JAYAKRISHNAN P"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L43+L44",
    "FACULTY": "JAYAKRISHNAN P"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L13+L14",
    "FACULTY": "SATHEESH KUMAR S"
}, {
    "CODE": "ECE2003",
    "TITLE": "Digital Logic Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L23+L24",
    "FACULTY": "SATHEESH KUMAR S"
}, {
    "CODE": "ECE2004",
    "TITLE": "Transmission Lines and Waveguides",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT524",
    "SLOT": "B2+TB2",
    "FACULTY": "LAVANYA N"
}, {
    "CODE": "ECE2005",
    "TITLE": "Probability Theory and Random\nProcesses",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT619",
    "SLOT": "C1+TC1",
    "FACULTY": "YEPUGANTI KARUNA"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT630",
    "SLOT": "C1",
    "FACULTY": "MALAYA KUMAR HOTA"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT630",
    "SLOT": "C2",
    "FACULTY": "MALAYA KUMAR HOTA"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT631",
    "SLOT": "C1",
    "FACULTY": "KISHORE V. KRISHNAN"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT631",
    "SLOT": "C2",
    "FACULTY": "KISHORE V. KRISHNAN"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT715",
    "SLOT": "C1",
    "FACULTY": "SUDHAKAR M S"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT715",
    "SLOT": "C2",
    "FACULTY": "SUDHAKAR M S"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT716",
    "SLOT": "C1",
    "FACULTY": "ASHISH P"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT716",
    "SLOT": "C2",
    "FACULTY": "ASHISH P"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT232",
    "SLOT": "L33+L34",
    "FACULTY": "MALAYA KUMAR HOTA"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MALAYA KUMAR HOTA"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT232",
    "SLOT": "L57+L58",
    "FACULTY": "MALAYA KUMAR HOTA"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MALAYA KUMAR HOTA"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT232",
    "SLOT": "L39+L40",
    "FACULTY": "KISHORE V. KRISHNAN"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KISHORE V. KRISHNAN"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT232",
    "SLOT": "L51+L52",
    "FACULTY": "KISHORE V. KRISHNAN"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KISHORE V. KRISHNAN"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT232",
    "SLOT": "L15+L16",
    "FACULTY": "KISHORE V. KRISHNAN"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KISHORE V. KRISHNAN"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT232",
    "SLOT": "L19+L20",
    "FACULTY": "KISHORE V. KRISHNAN"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KISHORE V. KRISHNAN"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT232",
    "SLOT": "L31+L32",
    "FACULTY": "SUDHAKAR M S"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUDHAKAR M S"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT232",
    "SLOT": "L49+L50",
    "FACULTY": "SUDHAKAR M S"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUDHAKAR M S"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT232",
    "SLOT": "L9+L10",
    "FACULTY": "SUDHAKAR M S"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUDHAKAR M S"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT232",
    "SLOT": "L7+L8",
    "FACULTY": "MALAYA KUMAR HOTA"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MALAYA KUMAR HOTA"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT232",
    "SLOT": "L29+L30",
    "FACULTY": "MALAYA KUMAR HOTA"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MALAYA KUMAR HOTA"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT232",
    "SLOT": "L21+L22",
    "FACULTY": "SUDHAKAR M S"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUDHAKAR M S"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT232",
    "SLOT": "L35+L36",
    "FACULTY": "ASHISH P"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ASHISH P"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT232",
    "SLOT": "L45+L46",
    "FACULTY": "ASHISH P"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ASHISH P"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT232",
    "SLOT": "L5+L6",
    "FACULTY": "ASHISH P"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ASHISH P"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT232",
    "SLOT": "L27+L28",
    "FACULTY": "ASHISH P"
}, {
    "CODE": "ECE2006",
    "TITLE": "Digital Signal Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ASHISH P"
}, {
    "CODE": "ECE2008",
    "TITLE": "Robotics and Automation",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT716",
    "SLOT": "B1",
    "FACULTY": "VENUGOPAL P"
}, {
    "CODE": "ECE2008",
    "TITLE": "Robotics and Automation",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VENUGOPAL P"
}, {
    "CODE": "ECE2008",
    "TITLE": "Robotics and Automation",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT716",
    "SLOT": "B2",
    "FACULTY": "VENUGOPAL P"
}, {
    "CODE": "ECE2008",
    "TITLE": "Robotics and Automation",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VENUGOPAL P"
}, {
    "CODE": "ECE2010",
    "TITLE": "Control Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT308",
    "SLOT": "G1+TG1",
    "FACULTY": "VELMURUGAN V"
}, {
    "CODE": "ECE2010",
    "TITLE": "Control Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VELMURUGAN V"
}, {
    "CODE": "ECE2010",
    "TITLE": "Control Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT308",
    "SLOT": "G2+TG2",
    "FACULTY": "MUGELAN R K"
}, {
    "CODE": "ECE2010",
    "TITLE": "Control Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MUGELAN R K"
}, {
    "CODE": "ECE2010",
    "TITLE": "Control Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT621",
    "SLOT": "A1+TA1",
    "FACULTY": "BAGUBALI A"
}, {
    "CODE": "ECE2010",
    "TITLE": "Control Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BAGUBALI A"
}, {
    "CODE": "ECE2010",
    "TITLE": "Control Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT621",
    "SLOT": "A2+TA2",
    "FACULTY": "BAGUBALI A"
}, {
    "CODE": "ECE2010",
    "TITLE": "Control Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BAGUBALI A"
}, {
    "CODE": "ECE2010",
    "TITLE": "Control Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT630",
    "SLOT": "A1+TA1",
    "FACULTY": "RAJESH R"
}, {
    "CODE": "ECE2010",
    "TITLE": "Control Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJESH R"
}, {
    "CODE": "ECE2010",
    "TITLE": "Control Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT630",
    "SLOT": "A2+TA2",
    "FACULTY": "RAJESH R"
}, {
    "CODE": "ECE2010",
    "TITLE": "Control Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJESH R"
}, {
    "CODE": "ECE2010",
    "TITLE": "Control Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT631",
    "SLOT": "A1+TA1",
    "FACULTY": "GOVARDHAN K"
}, {
    "CODE": "ECE2010",
    "TITLE": "Control Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GOVARDHAN K"
}, {
    "CODE": "ECE2010",
    "TITLE": "Control Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT631",
    "SLOT": "A2+TA2",
    "FACULTY": "GOVARDHAN K"
}, {
    "CODE": "ECE2010",
    "TITLE": "Control Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GOVARDHAN K"
}, {
    "CODE": "ECE2010",
    "TITLE": "Control Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT726",
    "SLOT": "G2+TG2",
    "FACULTY": "VIDHYA S"
}, {
    "CODE": "ECE2010",
    "TITLE": "Control Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIDHYA S"
}, {
    "CODE": "ECE2015",
    "TITLE": "Integrated Circuits",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT523",
    "SLOT": "F2",
    "FACULTY": "SASIKUMAR K"
}, {
    "CODE": "ECE2015",
    "TITLE": "Integrated Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "CBMR30\n5",
    "SLOT": "L1+L2",
    "FACULTY": "SASIKUMAR K"
}, {
    "CODE": "ECE2015",
    "TITLE": "Integrated Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SASIKUMAR K"
}, {
    "CODE": "ECE2015",
    "TITLE": "Integrated Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "CBMR30\n5",
    "SLOT": "L29+L30",
    "FACULTY": "SASIKUMAR K"
}, {
    "CODE": "ECE2015",
    "TITLE": "Integrated Circuits",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SASIKUMAR K"
}, {
    "CODE": "ECE2017",
    "TITLE": "Physiological System Modeling",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CBMR30\n1",
    "SLOT": "G1",
    "FACULTY": "DEEPA MADATHIL"
}, {
    "CODE": "ECE2017",
    "TITLE": "Physiological System Modeling",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "CBMR30\n3",
    "SLOT": "L39+L40",
    "FACULTY": "DEEPA MADATHIL"
}, {
    "CODE": "ECE2017",
    "TITLE": "Physiological System Modeling",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "CBMR30\n3",
    "SLOT": "L47+L48",
    "FACULTY": "DEEPA MADATHIL"
}, {
    "CODE": "ECE2020",
    "TITLE": "Digital Electronics",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT726",
    "SLOT": "B2",
    "FACULTY": "NITHISH  KUMAR V"
}, {
    "CODE": "ECE2020",
    "TITLE": "Digital Electronics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "CBMR30\n5",
    "SLOT": "L3+L4",
    "FACULTY": "NITHISH  KUMAR V"
}, {
    "CODE": "ECE2020",
    "TITLE": "Digital Electronics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NITHISH  KUMAR V"
}, {
    "CODE": "ECE2020",
    "TITLE": "Digital Electronics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "CBMR30\n5",
    "SLOT": "L19+L20",
    "FACULTY": "NITHISH  KUMAR V"
}, {
    "CODE": "ECE2020",
    "TITLE": "Digital Electronics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NITHISH  KUMAR V"
}, {
    "CODE": "ECE2021",
    "TITLE": "Medical Imaging Equipment",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CBMR10\n1",
    "SLOT": "A1+TA1",
    "FACULTY": "VIDHYA S"
}, {
    "CODE": "ECE2023",
    "TITLE": "Principles of Sensors and Data\nAcquisition",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT531A",
    "SLOT": "C1+TC1",
    "FACULTY": "ABRAHAM SAMPSON S"
}, {
    "CODE": "ECE2023",
    "TITLE": "Principles of Sensors and Data\nAcquisition",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT531A",
    "SLOT": "C2+TC2",
    "FACULTY": "ABRAHAM SAMPSON S"
}, {
    "CODE": "ECE2023",
    "TITLE": "Principles of Sensors and Data\nAcquisition",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT501",
    "SLOT": "L31+L32",
    "FACULTY": "ABRAHAM SAMPSON S"
}, {
    "CODE": "ECE2023",
    "TITLE": "Principles of Sensors and Data\nAcquisition",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT501",
    "SLOT": "L51+L52",
    "FACULTY": "ABRAHAM SAMPSON S"
}, {
    "CODE": "ECE2023",
    "TITLE": "Principles of Sensors and Data\nAcquisition",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT501",
    "SLOT": "L5+L6",
    "FACULTY": "ABRAHAM SAMPSON S"
}, {
    "CODE": "ECE2023",
    "TITLE": "Principles of Sensors and Data\nAcquisition",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT501",
    "SLOT": "L7+L8",
    "FACULTY": "ABRAHAM SAMPSON S"
}, {
    "CODE": "ECE2024",
    "TITLE": "Principles of Communication\nEngineering",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "TT308",
    "SLOT": "F1",
    "FACULTY": "RAJESH A"
}, {
    "CODE": "ECE2024",
    "TITLE": "Principles of Communication\nEngineering",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "TT308",
    "SLOT": "F2",
    "FACULTY": "KALAPRAVEEN BAGADI"
}, {
    "CODE": "ECE2026",
    "TITLE": "Digital Circuit Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT308",
    "SLOT": "D1",
    "FACULTY": "ANITHA  R"
}, {
    "CODE": "ECE2026",
    "TITLE": "Digital Circuit Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT631",
    "SLOT": "D2",
    "FACULTY": "ANITHA  R"
}, {
    "CODE": "ECE2026",
    "TITLE": "Digital Circuit Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L1+L2",
    "FACULTY": "ANITHA  R"
}, {
    "CODE": "ECE2026",
    "TITLE": "Digital Circuit Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANITHA  R"
}, {
    "CODE": "ECE2026",
    "TITLE": "Digital Circuit Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L29+L30",
    "FACULTY": "ANITHA  R"
}, {
    "CODE": "ECE2026",
    "TITLE": "Digital Circuit Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANITHA  R"
}, {
    "CODE": "ECE2026",
    "TITLE": "Digital Circuit Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L31+L32",
    "FACULTY": "ANITHA  R"
}, {
    "CODE": "ECE2026",
    "TITLE": "Digital Circuit Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANITHA  R"
}, {
    "CODE": "ECE2026",
    "TITLE": "Digital Circuit Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT422",
    "SLOT": "L53+L54",
    "FACULTY": "ANITHA  R"
}, {
    "CODE": "ECE2026",
    "TITLE": "Digital Circuit Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANITHA  R"
}, {
    "CODE": "ECE3001",
    "TITLE": "Analog Communication Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT621",
    "SLOT": "G2+TG2",
    "FACULTY": "SHANKAR T"
}, {
    "CODE": "ECE3001",
    "TITLE": "Analog Communication Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT621",
    "SLOT": "G1+TG1",
    "FACULTY": "KAVITHA K.V.N."
}, {
    "CODE": "ECE3001",
    "TITLE": "Analog Communication Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CBMR10\n1",
    "SLOT": "G1+TG1",
    "FACULTY": "SHANKAR T"
}, {
    "CODE": "ECE3001",
    "TITLE": "Analog Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L59+L60",
    "FACULTY": "SHANKAR T"
}, {
    "CODE": "ECE3001",
    "TITLE": "Analog Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L49+L50",
    "FACULTY": "SHANKAR T"
}, {
    "CODE": "ECE3001",
    "TITLE": "Analog Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L3+L4",
    "FACULTY": "SHANKAR T"
}, {
    "CODE": "ECE3001",
    "TITLE": "Analog Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L29+L30",
    "FACULTY": "SHANKAR T"
}, {
    "CODE": "ECE3001",
    "TITLE": "Analog Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L41+L42",
    "FACULTY": "KAVITHA K.V.N."
}, {
    "CODE": "ECE3001",
    "TITLE": "Analog Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L55+L56",
    "FACULTY": "KAVITHA K.V.N."
}, {
    "CODE": "ECE3002",
    "TITLE": "VLSI System Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT620",
    "SLOT": "C1+TC1",
    "FACULTY": "SAKTHIVEL R"
}, {
    "CODE": "ECE3002",
    "TITLE": "VLSI System Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT237",
    "SLOT": "L37+L38",
    "FACULTY": "SAKTHIVEL R"
}, {
    "CODE": "ECE3002",
    "TITLE": "VLSI System Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT237",
    "SLOT": "L53+L54",
    "FACULTY": "SAKTHIVEL R"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT335",
    "SLOT": "E1",
    "FACULTY": "DHANABAL R"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT335",
    "SLOT": "E2",
    "FACULTY": "DHANABAL R"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT504",
    "SLOT": "E1",
    "FACULTY": "KARTHIKEYAN A"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT504",
    "SLOT": "E2",
    "FACULTY": "KARTHIKEYAN A"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT523",
    "SLOT": "E1",
    "FACULTY": "CHITRA P"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT523",
    "SLOT": "E2",
    "FACULTY": "CHITRA P"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT524",
    "SLOT": "E1",
    "FACULTY": "S. SUNDAR"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT524",
    "SLOT": "E2",
    "FACULTY": "S. SUNDAR"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT630",
    "SLOT": "E2",
    "FACULTY": "KARTHIKEYAN B"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT716",
    "SLOT": "E1",
    "FACULTY": "SHANMUGASUNDARAM M"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L35+L36",
    "FACULTY": "KARTHIKEYAN A"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KARTHIKEYAN A"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L43+L44",
    "FACULTY": "KARTHIKEYAN A"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KARTHIKEYAN A"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L3+L4",
    "FACULTY": "KARTHIKEYAN A"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KARTHIKEYAN A"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L15+L16",
    "FACULTY": "KARTHIKEYAN A"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KARTHIKEYAN A"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L37+L38",
    "FACULTY": "CHITRA P"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "CHITRA P"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L47+L48",
    "FACULTY": "CHITRA P"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "CHITRA P"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L21+L22",
    "FACULTY": "CHITRA P"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "CHITRA P"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L27+L28",
    "FACULTY": "CHITRA P"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "CHITRA P"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L31+L32",
    "FACULTY": "S. SUNDAR"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "S. SUNDAR"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L51+L52",
    "FACULTY": "S. SUNDAR"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "S. SUNDAR"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L11+L12",
    "FACULTY": "S. SUNDAR"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "S. SUNDAR"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L19+L20",
    "FACULTY": "S. SUNDAR"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "S. SUNDAR"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L33+L34",
    "FACULTY": "SHANMUGASUNDARAM M"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SHANMUGASUNDARAM M"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L49+L50",
    "FACULTY": "SHANMUGASUNDARAM M"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SHANMUGASUNDARAM M"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L23+L24",
    "FACULTY": "KARTHIKEYAN B"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KARTHIKEYAN B"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L25+L26",
    "FACULTY": "KARTHIKEYAN B"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KARTHIKEYAN B"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L41+L42",
    "FACULTY": "DHANABAL R"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DHANABAL R"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L45+L46",
    "FACULTY": "DHANABAL R"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DHANABAL R"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L5+L6",
    "FACULTY": "DHANABAL R"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DHANABAL R"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L29+L30",
    "FACULTY": "DHANABAL R"
}, {
    "CODE": "ECE3003",
    "TITLE": "Microcontroller and its Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DHANABAL R"
}, {
    "CODE": "ECE3004",
    "TITLE": "Computer Organization and\nArchitectures",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT524",
    "SLOT": "F1+TF1",
    "FACULTY": "ARUN M"
}, {
    "CODE": "ECE3004",
    "TITLE": "Computer Organization and\nArchitectures",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT631",
    "SLOT": "F2+TF2",
    "FACULTY": "JAYAKRISHNAN P"
}, {
    "CODE": "ECE3004",
    "TITLE": "Computer Organization and\nArchitectures",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT631",
    "SLOT": "F1+TF1",
    "FACULTY": "SATHEESH KUMAR S"
}, {
    "CODE": "ECE3005",
    "TITLE": "Digital Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT716",
    "SLOT": "A1+TA1",
    "FACULTY": "PADMINI T N"
}, {
    "CODE": "ECE3005",
    "TITLE": "Digital Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT716",
    "SLOT": "A2+TA2",
    "FACULTY": "PADMINI T N"
}, {
    "CODE": "ECE3005",
    "TITLE": "Digital Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CBMR30\n1",
    "SLOT": "A1+TA1",
    "FACULTY": "SANJAY  KUMAR SINGH"
}, {
    "CODE": "ECE3005",
    "TITLE": "Digital Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CBMR30\n1",
    "SLOT": "A2+TA2",
    "FACULTY": "JEEVA J.B"
}, {
    "CODE": "ECE3005",
    "TITLE": "Digital Image Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT231",
    "SLOT": "L9+L10",
    "FACULTY": "PADMINI T N"
}, {
    "CODE": "ECE3005",
    "TITLE": "Digital Image Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT231",
    "SLOT": "L23+L24",
    "FACULTY": "PADMINI T N"
}, {
    "CODE": "ECE3005",
    "TITLE": "Digital Image Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT231",
    "SLOT": "L33+L34",
    "FACULTY": "PADMINI T N"
}, {
    "CODE": "ECE3005",
    "TITLE": "Digital Image Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT231",
    "SLOT": "L49+L50",
    "FACULTY": "PADMINI T N"
}, {
    "CODE": "ECE3005",
    "TITLE": "Digital Image Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT231",
    "SLOT": "L27+L28",
    "FACULTY": "JEEVA J.B"
}, {
    "CODE": "ECE3005",
    "TITLE": "Digital Image Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT231",
    "SLOT": "L11+L12",
    "FACULTY": "JEEVA J.B"
}, {
    "CODE": "ECE3005",
    "TITLE": "Digital Image Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT231",
    "SLOT": "L39+L40",
    "FACULTY": "SANJAY  KUMAR SINGH"
}, {
    "CODE": "ECE3005",
    "TITLE": "Digital Image Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT231",
    "SLOT": "L43+L44",
    "FACULTY": "SANJAY  KUMAR SINGH"
}, {
    "CODE": "ECE3009",
    "TITLE": "Neural Networks and Fuzzy Control",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT621",
    "SLOT": "C1+TC1",
    "FACULTY": "SANKAR GANESH S"
}, {
    "CODE": "ECE3009",
    "TITLE": "Neural Networks and Fuzzy Control",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SANKAR GANESH S"
}, {
    "CODE": "ECE3009",
    "TITLE": "Neural Networks and Fuzzy Control",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT621",
    "SLOT": "C2+TC2",
    "FACULTY": "SANKAR GANESH S"
}, {
    "CODE": "ECE3009",
    "TITLE": "Neural Networks and Fuzzy Control",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SANKAR GANESH S"
}, {
    "CODE": "ECE3009",
    "TITLE": "Neural Networks and Fuzzy Control",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT724",
    "SLOT": "C1+TC1",
    "FACULTY": "SARANYA K.C."
}, {
    "CODE": "ECE3009",
    "TITLE": "Neural Networks and Fuzzy Control",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SARANYA K.C."
}, {
    "CODE": "ECE3009",
    "TITLE": "Neural Networks and Fuzzy Control",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT724",
    "SLOT": "C2+TC2",
    "FACULTY": "SARANYA K.C."
}, {
    "CODE": "ECE3009",
    "TITLE": "Neural Networks and Fuzzy Control",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SARANYA K.C."
}, {
    "CODE": "ECE3010",
    "TITLE": "Antennas and Wave Propagation",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT524",
    "SLOT": "F2+TF2",
    "FACULTY": "YOGESH KUMAR CHOUKIKER"
}, {
    "CODE": "ECE3010",
    "TITLE": "Antennas and Wave Propagation",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT620",
    "SLOT": "F1+TF1",
    "FACULTY": "VIJAY KUMAR"
}, {
    "CODE": "ECE3010",
    "TITLE": "Antennas and Wave Propagation",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT620",
    "SLOT": "F2+TF2",
    "FACULTY": "SRINIVASA RAO INABATHINI"
}, {
    "CODE": "ECE3010",
    "TITLE": "Antennas and Wave Propagation",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT621",
    "SLOT": "F1+TF1",
    "FACULTY": "POONKUZHALI R"
}, {
    "CODE": "ECE3010",
    "TITLE": "Antennas and Wave Propagation",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT619",
    "SLOT": "F2+TF2",
    "FACULTY": "BOOPALAN G"
}, {
    "CODE": "ECE3011",
    "TITLE": "Microwave Engineering",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT724",
    "SLOT": "B1+TB1",
    "FACULTY": "KANNADASSAN D"
}, {
    "CODE": "ECE3011",
    "TITLE": "Microwave Engineering",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT724",
    "SLOT": "B2+TB2",
    "FACULTY": "RAMYA S"
}, {
    "CODE": "ECE3011",
    "TITLE": "Microwave Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT145",
    "SLOT": "L37+L38",
    "FACULTY": "KANNADASSAN D"
}, {
    "CODE": "ECE3011",
    "TITLE": "Microwave Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KANNADASSAN D"
}, {
    "CODE": "ECE3011",
    "TITLE": "Microwave Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT145",
    "SLOT": "L51+L52",
    "FACULTY": "KANNADASSAN D"
}, {
    "CODE": "ECE3011",
    "TITLE": "Microwave Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KANNADASSAN D"
}, {
    "CODE": "ECE3011",
    "TITLE": "Microwave Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT145",
    "SLOT": "L7+L8",
    "FACULTY": "RAMYA S"
}, {
    "CODE": "ECE3011",
    "TITLE": "Microwave Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMYA S"
}, {
    "CODE": "ECE3011",
    "TITLE": "Microwave Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT145",
    "SLOT": "L23+L24",
    "FACULTY": "RAMYA S"
}, {
    "CODE": "ECE3011",
    "TITLE": "Microwave Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMYA S"
}, {
    "CODE": "ECE3013",
    "TITLE": "Linear Integrated Circuits",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT619",
    "SLOT": "F1+TF1",
    "FACULTY": "PRADHEEP T"
}, {
    "CODE": "ECE3013",
    "TITLE": "Linear Integrated Circuits",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT630",
    "SLOT": "F1+TF1",
    "FACULTY": "DEEPIKA RANI SONA"
}, {
    "CODE": "ECE3013",
    "TITLE": "Linear Integrated Circuits",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT726",
    "SLOT": "F2+TF2",
    "FACULTY": "NITHISH  KUMAR V"
}, {
    "CODE": "ECE3013",
    "TITLE": "Linear Integrated Circuits",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT621",
    "SLOT": "F2+TF2",
    "FACULTY": "PRADHEEP T"
}, {
    "CODE": "ECE3013",
    "TITLE": "Linear Integrated Circuits",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT630",
    "SLOT": "F2+TF2",
    "FACULTY": "DEEPIKA RANI SONA"
}, {
    "CODE": "ECE3013",
    "TITLE": "Linear Integrated Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT246",
    "SLOT": "L3+L4",
    "FACULTY": "DEEPIKA RANI SONA"
}, {
    "CODE": "ECE3013",
    "TITLE": "Linear Integrated Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT246",
    "SLOT": "L7+L8",
    "FACULTY": "DEEPIKA RANI SONA"
}, {
    "CODE": "ECE3013",
    "TITLE": "Linear Integrated Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT246",
    "SLOT": "L39+L40",
    "FACULTY": "DEEPIKA RANI SONA"
}, {
    "CODE": "ECE3013",
    "TITLE": "Linear Integrated Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT246",
    "SLOT": "L49+L50",
    "FACULTY": "DEEPIKA RANI SONA"
}, {
    "CODE": "ECE3013",
    "TITLE": "Linear Integrated Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT246",
    "SLOT": "L9+L10",
    "FACULTY": "PRADHEEP T"
}, {
    "CODE": "ECE3013",
    "TITLE": "Linear Integrated Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT246",
    "SLOT": "L25+L26",
    "FACULTY": "PRADHEEP T"
}, {
    "CODE": "ECE3013",
    "TITLE": "Linear Integrated Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT246",
    "SLOT": "L37+L38",
    "FACULTY": "PRADHEEP T"
}, {
    "CODE": "ECE3013",
    "TITLE": "Linear Integrated Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT246",
    "SLOT": "L55+L56",
    "FACULTY": "PRADHEEP T"
}, {
    "CODE": "ECE3013",
    "TITLE": "Linear Integrated Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT246",
    "SLOT": "L15+L16",
    "FACULTY": "NITHISH  KUMAR V"
}, {
    "CODE": "ECE3013",
    "TITLE": "Linear Integrated Circuits",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT246",
    "SLOT": "L11+L12",
    "FACULTY": "NITHISH  KUMAR V"
}, {
    "CODE": "ECE3023",
    "TITLE": "Microcontrollers and its Applications",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CBMR10\n1",
    "SLOT": "C1",
    "FACULTY": "SUMIT KUMAR JINDAL"
}, {
    "CODE": "ECE3023",
    "TITLE": "Microcontrollers and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L53+L54",
    "FACULTY": "SUMIT KUMAR JINDAL"
}, {
    "CODE": "ECE3023",
    "TITLE": "Microcontrollers and its Applications",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT729",
    "SLOT": "L57+L58",
    "FACULTY": "SUMIT KUMAR JINDAL"
}, {
    "CODE": "ECE3025",
    "TITLE": "Image Processing",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "CBMR30\n1",
    "SLOT": "TG1",
    "FACULTY": "SANJAY  KUMAR SINGH"
}, {
    "CODE": "ECE3025",
    "TITLE": "Image Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT231",
    "SLOT": "L31+L32",
    "FACULTY": "SANJAY  KUMAR SINGH"
}, {
    "CODE": "ECE3025",
    "TITLE": "Image Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT231",
    "SLOT": "L51+L52",
    "FACULTY": "SANJAY  KUMAR SINGH"
}, {
    "CODE": "ECE3026",
    "TITLE": "IoT System Architecture",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT308",
    "SLOT": "A1",
    "FACULTY": "SASIKUMAR P"
}, {
    "CODE": "ECE3026",
    "TITLE": "IoT System Architecture",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SASIKUMAR P"
}, {
    "CODE": "ECE3026",
    "TITLE": "IoT System Architecture",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT308",
    "SLOT": "A2",
    "FACULTY": "SUJATHA R"
}, {
    "CODE": "ECE3026",
    "TITLE": "IoT System Architecture",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUJATHA R"
}, {
    "CODE": "ECE3027",
    "TITLE": "Bio-Signal Processing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT308",
    "SLOT": "E1",
    "FACULTY": "MYTHILI A"
}, {
    "CODE": "ECE3027",
    "TITLE": "Bio-Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "CBMR30\n3",
    "SLOT": "L41+L42",
    "FACULTY": "MYTHILI A"
}, {
    "CODE": "ECE3027",
    "TITLE": "Bio-Signal Processing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "CBMR30\n3",
    "SLOT": "L55+L56",
    "FACULTY": "MYTHILI A"
}, {
    "CODE": "ECE3038",
    "TITLE": "MEMS and Nano Sensors",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT531A",
    "SLOT": "B1+TB1",
    "FACULTY": "DEBASHIS MAJI"
}, {
    "CODE": "ECE3038",
    "TITLE": "MEMS and Nano Sensors",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT531A",
    "SLOT": "B2+TB2",
    "FACULTY": "DEBASHIS MAJI"
}, {
    "CODE": "ECE3039",
    "TITLE": "Chemical and Bio-sensors",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT531A",
    "SLOT": "G1+TG1",
    "FACULTY": "SIVACOUMAR R"
}, {
    "CODE": "ECE3039",
    "TITLE": "Chemical and Bio-sensors",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT531A",
    "SLOT": "G2+TG2",
    "FACULTY": "SIVACOUMAR R"
}, {
    "CODE": "ECE3999",
    "TITLE": "Technical Answers for Real World\nProblems (TARP)",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "TT524",
    "SLOT": "TE2",
    "FACULTY": "YEPUGANTI KARUNA"
}, {
    "CODE": "ECE3999",
    "TITLE": "Technical Answers for Real World\nProblems (TARP)",
    "TYPE": "EPJ",
    "CREDITS": "2",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "YEPUGANTI KARUNA"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT630",
    "SLOT": "G2+TG2",
    "FACULTY": "KALAPRAVEEN BAGADI"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT631",
    "SLOT": "G1+TG1",
    "FACULTY": "HARIHARAN  S"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT631",
    "SLOT": "G2+TG2",
    "FACULTY": "HARIHARAN  S"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT715",
    "SLOT": "G1+TG1",
    "FACULTY": "NANDAKUMAR S"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT715",
    "SLOT": "G2+TG2",
    "FACULTY": "NANDAKUMAR S"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT716",
    "SLOT": "G1+TG1",
    "FACULTY": "VINOTH BABU K"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT716",
    "SLOT": "G2+TG2",
    "FACULTY": "VINOTH BABU K"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT724",
    "SLOT": "G1+TG1",
    "FACULTY": "VELMURUGAN T"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT724",
    "SLOT": "G2+TG2",
    "FACULTY": "VELMURUGAN T"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L7+L8",
    "FACULTY": "KALAPRAVEEN BAGADI"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L21+L22",
    "FACULTY": "KALAPRAVEEN BAGADI"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L33+L34",
    "FACULTY": "HARIHARAN  S"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L57+L58",
    "FACULTY": "HARIHARAN  S"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L13+L14",
    "FACULTY": "HARIHARAN  S"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L11+L12",
    "FACULTY": "HARIHARAN  S"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L45+L46",
    "FACULTY": "NANDAKUMAR S"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L53+L54",
    "FACULTY": "NANDAKUMAR S"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L9+L10",
    "FACULTY": "NANDAKUMAR S"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L27+L28",
    "FACULTY": "NANDAKUMAR S"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L39+L40",
    "FACULTY": "VINOTH BABU K"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L47+L48",
    "FACULTY": "VINOTH BABU K"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L23+L24",
    "FACULTY": "VINOTH BABU K"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L25+L26",
    "FACULTY": "VINOTH BABU K"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L31+L32",
    "FACULTY": "VELMURUGAN T"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L43+L44",
    "FACULTY": "VELMURUGAN T"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L15+L16",
    "FACULTY": "VELMURUGAN T"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L19+L20",
    "FACULTY": "VELMURUGAN T"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT630",
    "SLOT": "G1+TG1",
    "FACULTY": "THANIKAISELVAN V"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L37+L38",
    "FACULTY": "THANIKAISELVAN V"
}, {
    "CODE": "ECE4001",
    "TITLE": "Digital Communication Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135",
    "SLOT": "L51+L52",
    "FACULTY": "THANIKAISELVAN V"
}, {
    "CODE": "ECE4002",
    "TITLE": "Advanced Microcontrollers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT715",
    "SLOT": "F1+TF1",
    "FACULTY": "VIDHYAPATHI C.M"
}, {
    "CODE": "ECE4002",
    "TITLE": "Advanced Microcontrollers",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIDHYAPATHI C.M"
}, {
    "CODE": "ECE4002",
    "TITLE": "Advanced Microcontrollers",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT715",
    "SLOT": "F2+TF2",
    "FACULTY": "VIDHYAPATHI C.M"
}, {
    "CODE": "ECE4002",
    "TITLE": "Advanced Microcontrollers",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIDHYAPATHI C.M"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT715",
    "SLOT": "D1",
    "FACULTY": "JABEENA A"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT716",
    "SLOT": "D2",
    "FACULTY": "REVATHI S"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT724",
    "SLOT": "D2",
    "FACULTY": "SANGEETHA N"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT531A",
    "SLOT": "D1",
    "FACULTY": "SANGEETHA A"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT531A",
    "SLOT": "D2",
    "FACULTY": "RAJALAKSHMI S"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT724",
    "SLOT": "E1",
    "FACULTY": "ILAVARASAN T"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT724",
    "SLOT": "E2",
    "FACULTY": "ILAVARASAN T"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT144",
    "SLOT": "L3+L4",
    "FACULTY": "ILAVARASAN T"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ILAVARASAN T"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT144",
    "SLOT": "L23+L24",
    "FACULTY": "ILAVARASAN T"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ILAVARASAN T"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT144",
    "SLOT": "L33+L34",
    "FACULTY": "ILAVARASAN T"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ILAVARASAN T"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT144",
    "SLOT": "L51+L52",
    "FACULTY": "ILAVARASAN T"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ILAVARASAN T"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT144",
    "SLOT": "L31+L32",
    "FACULTY": "REVATHI S"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "REVATHI S"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT144",
    "SLOT": "L57+L58",
    "FACULTY": "REVATHI S"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "REVATHI S"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT144",
    "SLOT": "L37+L38",
    "FACULTY": "SANGEETHA A"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SANGEETHA A"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT144",
    "SLOT": "L55+L56",
    "FACULTY": "SANGEETHA A"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SANGEETHA A"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT144",
    "SLOT": "L11+L12",
    "FACULTY": "RAJALAKSHMI S"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJALAKSHMI S"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT144",
    "SLOT": "L21+L22",
    "FACULTY": "RAJALAKSHMI S"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJALAKSHMI S"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT144",
    "SLOT": "L39+L40",
    "FACULTY": "JABEENA A"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JABEENA A"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT144",
    "SLOT": "L43+L44",
    "FACULTY": "JABEENA A"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JABEENA A"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT144",
    "SLOT": "L5+L6",
    "FACULTY": "SANGEETHA N"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SANGEETHA N"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT144",
    "SLOT": "L27+L28",
    "FACULTY": "SANGEETHA N"
}, {
    "CODE": "ECE4005",
    "TITLE": "Optical Communication and  Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SANGEETHA N"
}, {
    "CODE": "ECE4007",
    "TITLE": "Information Theory and Coding",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT531A",
    "SLOT": "E1+TE1",
    "FACULTY": "NOOR MOHAMMED V"
}, {
    "CODE": "ECE4007",
    "TITLE": "Information Theory and Coding",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NOOR MOHAMMED V"
}, {
    "CODE": "ECE4007",
    "TITLE": "Information Theory and Coding",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT531A",
    "SLOT": "E2+TE2",
    "FACULTY": "NOOR MOHAMMED V"
}, {
    "CODE": "ECE4007",
    "TITLE": "Information Theory and Coding",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NOOR MOHAMMED V"
}, {
    "CODE": "ECE4008",
    "TITLE": "Computer Communication",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT523",
    "SLOT": "F1+TF1",
    "FACULTY": "RENUGA DEVI S"
}, {
    "CODE": "ECE4008",
    "TITLE": "Computer Communication",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT531A",
    "SLOT": "F1+TF1",
    "FACULTY": "RAVI KUMAR C V"
}, {
    "CODE": "ECE4008",
    "TITLE": "Computer Communication",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT531A",
    "SLOT": "F2+TF2",
    "FACULTY": "RAVI KUMAR C V"
}, {
    "CODE": "ECE4008",
    "TITLE": "Computer Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT134",
    "SLOT": "L39+L40",
    "FACULTY": "RENUGA DEVI S"
}, {
    "CODE": "ECE4008",
    "TITLE": "Computer Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT134",
    "SLOT": "L51+L52",
    "FACULTY": "RENUGA DEVI S"
}, {
    "CODE": "ECE4008",
    "TITLE": "Computer Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT134",
    "SLOT": "L9+L10",
    "FACULTY": "RAVI KUMAR C V"
}, {
    "CODE": "ECE4008",
    "TITLE": "Computer Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT134",
    "SLOT": "L21+L22",
    "FACULTY": "RAVI KUMAR C V"
}, {
    "CODE": "ECE4008",
    "TITLE": "Computer Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT134",
    "SLOT": "L43+L44",
    "FACULTY": "RAVI KUMAR C V"
}, {
    "CODE": "ECE4008",
    "TITLE": "Computer Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT134",
    "SLOT": "L55+L56",
    "FACULTY": "RAVI KUMAR C V"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT716",
    "SLOT": "F1+TF1",
    "FACULTY": "ABHIJIT BHOWMICK"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT716",
    "SLOT": "F2+TF2",
    "FACULTY": "ABHIJIT BHOWMICK"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT724",
    "SLOT": "F1+TF1",
    "FACULTY": "BUDHADITYA BHATTACHARYYA"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT724",
    "SLOT": "F2+TF2",
    "FACULTY": "BUDHADITYA BHATTACHARYYA"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT308",
    "SLOT": "C1+TC1",
    "FACULTY": "PREETHA K.S"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT308",
    "SLOT": "C2+TC2",
    "FACULTY": "PREETHA K.S"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135A",
    "SLOT": "L31+L32",
    "FACULTY": "PREETHA K.S"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PREETHA K.S"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135A",
    "SLOT": "L45+L46",
    "FACULTY": "PREETHA K.S"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PREETHA K.S"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135A",
    "SLOT": "L15+L16",
    "FACULTY": "PREETHA K.S"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PREETHA K.S"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135A",
    "SLOT": "L21+L22",
    "FACULTY": "PREETHA K.S"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PREETHA K.S"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135A",
    "SLOT": "L5+L6",
    "FACULTY": "ABHIJIT BHOWMICK"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ABHIJIT BHOWMICK"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135A",
    "SLOT": "L11+L12",
    "FACULTY": "ABHIJIT BHOWMICK"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ABHIJIT BHOWMICK"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135A",
    "SLOT": "L37+L38",
    "FACULTY": "ABHIJIT BHOWMICK"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ABHIJIT BHOWMICK"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135A",
    "SLOT": "L51+L52",
    "FACULTY": "ABHIJIT BHOWMICK"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ABHIJIT BHOWMICK"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135A",
    "SLOT": "L9+L10",
    "FACULTY": "BUDHADITYA BHATTACHARYYA"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BUDHADITYA BHATTACHARYYA"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135A",
    "SLOT": "L19+L20",
    "FACULTY": "BUDHADITYA BHATTACHARYYA"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BUDHADITYA BHATTACHARYYA"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135A",
    "SLOT": "L39+L40",
    "FACULTY": "BUDHADITYA BHATTACHARYYA"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BUDHADITYA BHATTACHARYYA"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135A",
    "SLOT": "L43+L44",
    "FACULTY": "BUDHADITYA BHATTACHARYYA"
}, {
    "CODE": "ECE4009",
    "TITLE": "Wireless and Mobile Communication",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BUDHADITYA BHATTACHARYYA"
}, {
    "CODE": "ECE4010",
    "TITLE": "Satellite Communication",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT715",
    "SLOT": "A1+TA1",
    "FACULTY": "MUGELAN R K"
}, {
    "CODE": "ECE4010",
    "TITLE": "Satellite Communication",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT715",
    "SLOT": "A2+TA2",
    "FACULTY": "MUGELAN R K"
}, {
    "CODE": "ECE4011",
    "TITLE": "Wireless Sensor Networks",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT620",
    "SLOT": "G2",
    "FACULTY": "KAVITHA K.V.N."
}, {
    "CODE": "ECE4011",
    "TITLE": "Wireless Sensor Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135A",
    "SLOT": "L13+L14",
    "FACULTY": "KAVITHA K.V.N."
}, {
    "CODE": "ECE4011",
    "TITLE": "Wireless Sensor Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KAVITHA K.V.N."
}, {
    "CODE": "ECE4011",
    "TITLE": "Wireless Sensor Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT135A",
    "SLOT": "L27+L28",
    "FACULTY": "KAVITHA K.V.N."
}, {
    "CODE": "ECE4011",
    "TITLE": "Wireless Sensor Networks",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KAVITHA K.V.N."
}, {
    "CODE": "ECE4023",
    "TITLE": "Biometric Systems",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CBMR10\n1",
    "SLOT": "A2+TA2",
    "FACULTY": "BHASKAR MOHAN MURARI"
}, {
    "CODE": "ECE4024",
    "TITLE": "Embedded Systems in Medical\nApplications",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CBMR10\n1",
    "SLOT": "C2",
    "FACULTY": "SASIKUMAR K"
}, {
    "CODE": "ECE4024",
    "TITLE": "Embedded Systems in Medical\nApplications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SASIKUMAR K"
}, {
    "CODE": "ECE499",
    "TITLE": "Project Work",
    "TYPE": "PJT",
    "CREDITS": "20",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "ECE6099",
    "TITLE": "Masters Thesis",
    "TYPE": "PJT",
    "CREDITS": "16",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "ITA1007",
    "TITLE": "Web Development",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT207A",
    "SLOT": "D1+TD1",
    "FACULTY": "MARY MEKALA A"
}, {
    "CODE": "ITA1007",
    "TITLE": "Web Development",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT208",
    "SLOT": "A1+TA1",
    "FACULTY": "MARY MEKALA A"
}, {
    "CODE": "ITA1007",
    "TITLE": "Web Development",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG18",
    "SLOT": "L49+L50",
    "FACULTY": "MARY MEKALA A"
}, {
    "CODE": "ITA1007",
    "TITLE": "Web Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MARY MEKALA A"
}, {
    "CODE": "ITA1007",
    "TITLE": "Web Development",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG18",
    "SLOT": "L55+L56",
    "FACULTY": "MARY MEKALA A"
}, {
    "CODE": "ITA1007",
    "TITLE": "Web Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MARY MEKALA A"
}, {
    "CODE": "ITA1008",
    "TITLE": "M-Commerce",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT333",
    "SLOT": "D1+TD1",
    "FACULTY": "MANI P"
}, {
    "CODE": "ITA1010",
    "TITLE": "Linux/Unix Programming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT211",
    "SLOT": "E1+TE1",
    "FACULTY": "S. DEEPIKAA"
}, {
    "CODE": "ITA1010",
    "TITLE": "Linux/Unix Programming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT211A",
    "SLOT": "F1+TF1",
    "FACULTY": "S. DEEPIKAA"
}, {
    "CODE": "ITA1010",
    "TITLE": "Linux/Unix Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT120",
    "SLOT": "L49+L50",
    "FACULTY": "S. DEEPIKAA"
}, {
    "CODE": "ITA1010",
    "TITLE": "Linux/Unix Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT120",
    "SLOT": "L11+L12",
    "FACULTY": "S. DEEPIKAA"
}, {
    "CODE": "ITA2002",
    "TITLE": "Software Testing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT207A",
    "SLOT": "C1+TC1",
    "FACULTY": "CHARANYA R"
}, {
    "CODE": "ITA2002",
    "TITLE": "Software Testing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT208",
    "SLOT": "F1+TF1",
    "FACULTY": "CHARANYA R"
}, {
    "CODE": "ITA2002",
    "TITLE": "Software Testing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG17",
    "SLOT": "L31+L32",
    "FACULTY": "CHARANYA R"
}, {
    "CODE": "ITA2002",
    "TITLE": "Software Testing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG17",
    "SLOT": "L37+L38",
    "FACULTY": "CHARANYA R"
}, {
    "CODE": "ITA2003",
    "TITLE": "Computer Architecture",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT207A",
    "SLOT": "F1+TF1",
    "FACULTY": "SUMATHI D"
}, {
    "CODE": "ITA2003",
    "TITLE": "Computer Architecture",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT208",
    "SLOT": "C1+TC1",
    "FACULTY": "SUMATHI D"
}, {
    "CODE": "ITA2004",
    "TITLE": "Fundamentals of Data Analytics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT207A",
    "SLOT": "E1+TE1",
    "FACULTY": "CHEMMALAR SELVI G"
}, {
    "CODE": "ITA2004",
    "TITLE": "Fundamentals of Data Analytics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT208",
    "SLOT": "B1+TB1",
    "FACULTY": "CHEMMALAR SELVI G"
}, {
    "CODE": "ITA2004",
    "TITLE": "Fundamentals of Data Analytics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG19",
    "SLOT": "L43+L44",
    "FACULTY": "CHEMMALAR SELVI G"
}, {
    "CODE": "ITA2004",
    "TITLE": "Fundamentals of Data Analytics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG19",
    "SLOT": "L31+L32",
    "FACULTY": "CHEMMALAR SELVI G"
}, {
    "CODE": "ITA2005",
    "TITLE": "Computer Graphics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT211",
    "SLOT": "B1+TB1",
    "FACULTY": "GUNASEKARAN G"
}, {
    "CODE": "ITA2005",
    "TITLE": "Computer Graphics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT211A",
    "SLOT": "C1+TC1",
    "FACULTY": "GUNASEKARAN G"
}, {
    "CODE": "ITA2005",
    "TITLE": "Computer Graphics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT207",
    "SLOT": "F1+TF1",
    "FACULTY": "NAVANEETHAN C"
}, {
    "CODE": "ITA2008",
    "TITLE": "Data Warehousing and Data Mining",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT211A",
    "SLOT": "E1+TE1",
    "FACULTY": "THIPPA REDDY G"
}, {
    "CODE": "ITA2008",
    "TITLE": "Data Warehousing and Data Mining",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "THIPPA REDDY G"
}, {
    "CODE": "ITA2009",
    "TITLE": "Cryptography",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT211",
    "SLOT": "C1+TC1",
    "FACULTY": "NAVANEETHAN C"
}, {
    "CODE": "ITA2009",
    "TITLE": "Cryptography",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT211A",
    "SLOT": "B1+TB1",
    "FACULTY": "USHA DEVI G"
}, {
    "CODE": "ITA2011",
    "TITLE": "Mobile Application Development",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT211",
    "SLOT": "D1+TD1",
    "FACULTY": "RAJAPRABHA M.N"
}, {
    "CODE": "ITA2011",
    "TITLE": "Mobile Application Development",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT211A",
    "SLOT": "A1+TA1",
    "FACULTY": "RAJAPRABHA M.N"
}, {
    "CODE": "ITA2011",
    "TITLE": "Mobile Application Development",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG19",
    "SLOT": "L23+L24",
    "FACULTY": "RAJAPRABHA M.N"
}, {
    "CODE": "ITA2011",
    "TITLE": "Mobile Application Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJAPRABHA M.N"
}, {
    "CODE": "ITA2011",
    "TITLE": "Mobile Application Development",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG19",
    "SLOT": "L37+L38",
    "FACULTY": "RAJAPRABHA M.N"
}, {
    "CODE": "ITA2011",
    "TITLE": "Mobile Application Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJAPRABHA M.N"
}, {
    "CODE": "ITA2012",
    "TITLE": "Cloud Computing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT207",
    "SLOT": "E1+TE1",
    "FACULTY": "BENJULA ANBU MALAR M B"
}, {
    "CODE": "ITA2012",
    "TITLE": "Cloud Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BENJULA ANBU MALAR M B"
}, {
    "CODE": "ITA2012",
    "TITLE": "Cloud Computing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG16",
    "SLOT": "C1+TC1",
    "FACULTY": "BENJULA ANBU MALAR M B"
}, {
    "CODE": "ITA2012",
    "TITLE": "Cloud Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BENJULA ANBU MALAR M B"
}, {
    "CODE": "ITA3001",
    "TITLE": "Object Oriented Programming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT208",
    "SLOT": "E1+TE1",
    "FACULTY": "BARATH P"
}, {
    "CODE": "ITA3001",
    "TITLE": "Object Oriented Programming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT207A",
    "SLOT": "B1+TB1",
    "FACULTY": "BARATH P"
}, {
    "CODE": "ITA3001",
    "TITLE": "Object Oriented Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG20",
    "SLOT": "L55+L56",
    "FACULTY": "BARATH P"
}, {
    "CODE": "ITA3001",
    "TITLE": "Object Oriented Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BARATH P"
}, {
    "CODE": "ITA3001",
    "TITLE": "Object Oriented Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG20",
    "SLOT": "L43+L44",
    "FACULTY": "BARATH P"
}, {
    "CODE": "ITA3001",
    "TITLE": "Object Oriented Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BARATH P"
}, {
    "CODE": "ITA3002",
    "TITLE": "Data Structures",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT207A",
    "SLOT": "A1+TA1",
    "FACULTY": "SEETHA R"
}, {
    "CODE": "ITA3002",
    "TITLE": "Data Structures",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT208",
    "SLOT": "D1+TD1",
    "FACULTY": "SEETHA R"
}, {
    "CODE": "ITA3002",
    "TITLE": "Data Structures",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT120",
    "SLOT": "L37+L38",
    "FACULTY": "SEETHA R"
}, {
    "CODE": "ITA3002",
    "TITLE": "Data Structures",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG19",
    "SLOT": "L49+L50",
    "FACULTY": "SEETHA R"
}, {
    "CODE": "ITA3003",
    "TITLE": "Software Project Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT211",
    "SLOT": "F1+TF1",
    "FACULTY": "ABRAHAM PAUL"
}, {
    "CODE": "ITA3009",
    "TITLE": "Internet of Things",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT211",
    "SLOT": "A1+TA1",
    "FACULTY": "DEEPA.K"
}, {
    "CODE": "ITA3009",
    "TITLE": "Internet of Things",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DEEPA.K"
}, {
    "CODE": "ITA3009",
    "TITLE": "Internet of Things",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT211A",
    "SLOT": "D1+TD1",
    "FACULTY": "DEEPA.K"
}, {
    "CODE": "ITA3009",
    "TITLE": "Internet of Things",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DEEPA.K"
}, {
    "CODE": "ITA3099",
    "TITLE": "Capstone Project",
    "TYPE": "PJT",
    "CREDITS": "10",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "ITA399",
    "TITLE": "Project Work",
    "TYPE": "PJT",
    "CREDITS": "10",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "ITA6005",
    "TITLE": "Online Transaction using Mainframe\nComputing",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT115",
    "SLOT": "A1+TA1",
    "FACULTY": "SUBHASHINI R"
}, {
    "CODE": "ITA6005",
    "TITLE": "Online Transaction using Mainframe\nComputing",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT115",
    "SLOT": "A2+TA2",
    "FACULTY": "SUBHASHINI R"
}, {
    "CODE": "ITA6006",
    "TITLE": "Storage Systems and Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT115",
    "SLOT": "F1+TF1",
    "FACULTY": "NALLAKARUPPAN M.K."
}, {
    "CODE": "ITA6006",
    "TITLE": "Storage Systems and Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT115",
    "SLOT": "F2+TF2",
    "FACULTY": "SIVA RAMA KRISHNAN S"
}, {
    "CODE": "ITA6006",
    "TITLE": "Storage Systems and Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT807",
    "SLOT": "F1+TF1",
    "FACULTY": "SIVA RAMA KRISHNAN S"
}, {
    "CODE": "ITA6008",
    "TITLE": "Big Data Analytics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT115",
    "SLOT": "B2+TB2",
    "FACULTY": "RAMKUMAR T"
}, {
    "CODE": "ITA6008",
    "TITLE": "Big Data Analytics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMKUMAR T"
}, {
    "CODE": "ITA6008",
    "TITLE": "Big Data Analytics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT223",
    "SLOT": "B1+TB1",
    "FACULTY": "DAPHNE LOPEZ"
}, {
    "CODE": "ITA6008",
    "TITLE": "Big Data Analytics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DAPHNE LOPEZ"
}, {
    "CODE": "ITA6010",
    "TITLE": "Internet of Things",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT115",
    "SLOT": "C1+TC1",
    "FACULTY": "VISWANATHAN P"
}, {
    "CODE": "ITA6010",
    "TITLE": "Internet of Things",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VISWANATHAN P"
}, {
    "CODE": "ITA6010",
    "TITLE": "Internet of Things",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT115",
    "SLOT": "C2+TC2",
    "FACULTY": "VISWANATHAN P"
}, {
    "CODE": "ITA6010",
    "TITLE": "Internet of Things",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VISWANATHAN P"
}, {
    "CODE": "ITA6013",
    "TITLE": "Advanced Software Testing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT115",
    "SLOT": "E1+TE1",
    "FACULTY": "PRASANNA M"
}, {
    "CODE": "ITA6013",
    "TITLE": "Advanced Software Testing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT115",
    "SLOT": "E2+TE2",
    "FACULTY": "PRASANNA M"
}, {
    "CODE": "ITA6013",
    "TITLE": "Advanced Software Testing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG17",
    "SLOT": "L43+L44",
    "FACULTY": "PRASANNA M"
}, {
    "CODE": "ITA6013",
    "TITLE": "Advanced Software Testing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG17",
    "SLOT": "L5+L6",
    "FACULTY": "PRASANNA M"
}, {
    "CODE": "ITA6014",
    "TITLE": "Software Process and Metrics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT115",
    "SLOT": "D1+TD1",
    "FACULTY": "CHANDRASEGAR.T"
}, {
    "CODE": "ITA6014",
    "TITLE": "Software Process and Metrics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT115",
    "SLOT": "D2+TD2",
    "FACULTY": "GITANJALI J"
}, {
    "CODE": "ITA6014",
    "TITLE": "Software Process and Metrics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT223",
    "SLOT": "D1+TD1",
    "FACULTY": "KUMARAN U"
}, {
    "CODE": "ITA6014",
    "TITLE": "Software Process and Metrics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT223",
    "SLOT": "D2+TD2",
    "FACULTY": "KUMARAN U"
}, {
    "CODE": "ITA6099",
    "TITLE": "Masters Thesis",
    "TYPE": "PJT",
    "CREDITS": "14",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "ITA699",
    "TITLE": "Masters Thesis",
    "TYPE": "PJT",
    "CREDITS": "10",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "ITE1001",
    "TITLE": "Digital Logic and Microprocessor",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT125",
    "SLOT": "D1+TD1",
    "FACULTY": "SHASHIKIRAN V"
}, {
    "CODE": "ITE1001",
    "TITLE": "Digital Logic and Microprocessor",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT121",
    "SLOT": "L41+L42",
    "FACULTY": "SHASHIKIRAN V"
}, {
    "CODE": "ITE1002",
    "TITLE": "Web Technologies",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJTG04",
    "SLOT": "B1",
    "FACULTY": "MAREESWARI V"
}, {
    "CODE": "ITE1002",
    "TITLE": "Web Technologies",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT217",
    "SLOT": "L31+L32",
    "FACULTY": "MAREESWARI V"
}, {
    "CODE": "ITE1002",
    "TITLE": "Web Technologies",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJTG04",
    "SLOT": "B2",
    "FACULTY": "MAREESWARI V"
}, {
    "CODE": "ITE1002",
    "TITLE": "Web Technologies",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG18",
    "SLOT": "L29+L30",
    "FACULTY": "MAREESWARI V"
}, {
    "CODE": "ITE1002",
    "TITLE": "Web Technologies",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJTG05",
    "SLOT": "B1",
    "FACULTY": "SUREKA S"
}, {
    "CODE": "ITE1002",
    "TITLE": "Web Technologies",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG18",
    "SLOT": "L45+L46",
    "FACULTY": "SUREKA S"
}, {
    "CODE": "ITE1002",
    "TITLE": "Web Technologies",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJTG05",
    "SLOT": "B2",
    "FACULTY": "SUREKA S"
}, {
    "CODE": "ITE1002",
    "TITLE": "Web Technologies",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG19",
    "SLOT": "L27+L28",
    "FACULTY": "SUREKA S"
}, {
    "CODE": "ITE1002",
    "TITLE": "Web Technologies",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT221",
    "SLOT": "B1",
    "FACULTY": "JAYAKUMAR S"
}, {
    "CODE": "ITE1002",
    "TITLE": "Web Technologies",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT217",
    "SLOT": "L51+L52",
    "FACULTY": "JAYAKUMAR S"
}, {
    "CODE": "ITE1002",
    "TITLE": "Web Technologies",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG18",
    "SLOT": "L5+L6",
    "FACULTY": "JAYAKUMAR S"
}, {
    "CODE": "ITE1002",
    "TITLE": "Web Technologies",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT222",
    "SLOT": "B2",
    "FACULTY": "JAYAKUMAR S"
}, {
    "CODE": "ITE1003",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJTG04",
    "SLOT": "G1",
    "FACULTY": "BIMAL KUMAR RAY"
}, {
    "CODE": "ITE1003",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG18",
    "SLOT": "L25+L26",
    "FACULTY": "BIMAL KUMAR RAY"
}, {
    "CODE": "ITE1003",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BIMAL KUMAR RAY"
}, {
    "CODE": "ITE1003",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJTG04",
    "SLOT": "G2",
    "FACULTY": "BIMAL KUMAR RAY"
}, {
    "CODE": "ITE1003",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT120",
    "SLOT": "L55+L56",
    "FACULTY": "BIMAL KUMAR RAY"
}, {
    "CODE": "ITE1003",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BIMAL KUMAR RAY"
}, {
    "CODE": "ITE1003",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJTG05",
    "SLOT": "G1",
    "FACULTY": "PARIMALA M"
}, {
    "CODE": "ITE1003",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJTG05",
    "SLOT": "G2",
    "FACULTY": "SENTHILKUMAR N C"
}, {
    "CODE": "ITE1003",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT120",
    "SLOT": "L23+L24",
    "FACULTY": "SENTHILKUMAR N C"
}, {
    "CODE": "ITE1003",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SENTHILKUMAR N C"
}, {
    "CODE": "ITE1003",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT115",
    "SLOT": "G2",
    "FACULTY": "JAYARAM REDDY A"
}, {
    "CODE": "ITE1003",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG18",
    "SLOT": "L3+L4",
    "FACULTY": "JAYARAM REDDY A"
}, {
    "CODE": "ITE1003",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JAYARAM REDDY A"
}, {
    "CODE": "ITE1003",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG18",
    "SLOT": "L57+L58",
    "FACULTY": "PARIMALA M"
}, {
    "CODE": "ITE1003",
    "TITLE": "Database Management Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PARIMALA M"
}, {
    "CODE": "ITE1004",
    "TITLE": "Data Structures and Algorithms",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG20",
    "SLOT": "L11+L12",
    "FACULTY": "VIJAYAN E"
}, {
    "CODE": "ITE1004",
    "TITLE": "Data Structures and Algorithms",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT125",
    "SLOT": "C2+TC2",
    "FACULTY": "VIJAYAN E"
}, {
    "CODE": "ITE1005",
    "TITLE": "Software Engineering-Principles and\nPractices",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG04",
    "SLOT": "C1+TC1",
    "FACULTY": "KALAIVANI S"
}, {
    "CODE": "ITE1005",
    "TITLE": "Software Engineering-Principles and\nPractices",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG04",
    "SLOT": "C2+TC2",
    "FACULTY": "KALAIVANI S"
}, {
    "CODE": "ITE1005",
    "TITLE": "Software Engineering-Principles and\nPractices",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG05",
    "SLOT": "C2+TC2",
    "FACULTY": "THILAGAVATHI M"
}, {
    "CODE": "ITE1005",
    "TITLE": "Software Engineering-Principles and\nPractices",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG05",
    "SLOT": "C1+TC1",
    "FACULTY": "KARTHIKEYAN J"
}, {
    "CODE": "ITE1006",
    "TITLE": "Theory of Computation",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG04",
    "SLOT": "F1+TF1",
    "FACULTY": "DHARMENDRA SINGH RAJPUT"
}, {
    "CODE": "ITE1006",
    "TITLE": "Theory of Computation",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG04",
    "SLOT": "F2+TF2",
    "FACULTY": "THIPPA REDDY G"
}, {
    "CODE": "ITE1006",
    "TITLE": "Theory of Computation",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG05",
    "SLOT": "F1+TF1",
    "FACULTY": "KURUVA LAKSHMANNA"
}, {
    "CODE": "ITE1006",
    "TITLE": "Theory of Computation",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG05",
    "SLOT": "F2+TF2",
    "FACULTY": "KURUVA LAKSHMANNA"
}, {
    "CODE": "ITE1006",
    "TITLE": "Theory of Computation",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT223",
    "SLOT": "F2+TF2",
    "FACULTY": "DHARMENDRA SINGH RAJPUT"
}, {
    "CODE": "ITE1007",
    "TITLE": "Object Oriented Analysis and Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG10",
    "SLOT": "E1+TE1",
    "FACULTY": "SHANTHARAJAH S P"
}, {
    "CODE": "ITE1007",
    "TITLE": "Object Oriented Analysis and Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SHANTHARAJAH S P"
}, {
    "CODE": "ITE1008",
    "TITLE": "Open Source programming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG10",
    "SLOT": "F1+TF1",
    "FACULTY": "VANITHA M"
}, {
    "CODE": "ITE1008",
    "TITLE": "Open Source programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VANITHA M"
}, {
    "CODE": "ITE1008",
    "TITLE": "Open Source programming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG10",
    "SLOT": "F2+TF2",
    "FACULTY": "VANITHA M"
}, {
    "CODE": "ITE1008",
    "TITLE": "Open Source programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VANITHA M"
}, {
    "CODE": "ITE1008",
    "TITLE": "Open Source programming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG14",
    "SLOT": "F1+TF1",
    "FACULTY": "VIJAYARANI A"
}, {
    "CODE": "ITE1008",
    "TITLE": "Open Source programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIJAYARANI A"
}, {
    "CODE": "ITE1010",
    "TITLE": "Digital Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG10",
    "SLOT": "A2+TA2",
    "FACULTY": "HEMALATHA S"
}, {
    "CODE": "ITE1010",
    "TITLE": "Digital Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "HEMALATHA S"
}, {
    "CODE": "ITE1014",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG14",
    "SLOT": "B1+TB1",
    "FACULTY": "DIVYA UDAYAN  J"
}, {
    "CODE": "ITE1014",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DIVYA UDAYAN  J"
}, {
    "CODE": "ITE1014",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT207A",
    "SLOT": "B2+TB2",
    "FACULTY": "DIVYA UDAYAN  J"
}, {
    "CODE": "ITE1014",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DIVYA UDAYAN  J"
}, {
    "CODE": "ITE1015",
    "TITLE": "Soft Computing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG10",
    "SLOT": "A1+TA1",
    "FACULTY": "AGILANDEESWARI.L"
}, {
    "CODE": "ITE1015",
    "TITLE": "Soft Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AGILANDEESWARI.L"
}, {
    "CODE": "ITE1015",
    "TITLE": "Soft Computing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG14",
    "SLOT": "A1+TA1",
    "FACULTY": "VALARMATHI B"
}, {
    "CODE": "ITE1015",
    "TITLE": "Soft Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VALARMATHI B"
}, {
    "CODE": "ITE1015",
    "TITLE": "Soft Computing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG16",
    "SLOT": "A2+TA2",
    "FACULTY": "NEELU KHARE"
}, {
    "CODE": "ITE1015",
    "TITLE": "Soft Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NEELU KHARE"
}, {
    "CODE": "ITE1015",
    "TITLE": "Soft Computing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG14",
    "SLOT": "A2+TA2",
    "FACULTY": "VALARMATHI B"
}, {
    "CODE": "ITE1015",
    "TITLE": "Soft Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VALARMATHI B"
}, {
    "CODE": "ITE1016",
    "TITLE": "Mobile Application Development",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG08",
    "SLOT": "G1+TG1",
    "FACULTY": "BHAVANI S"
}, {
    "CODE": "ITE1016",
    "TITLE": "Mobile Application Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BHAVANI S"
}, {
    "CODE": "ITE1016",
    "TITLE": "Mobile Application Development",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG08",
    "SLOT": "G2+TG2",
    "FACULTY": "BHAVANI S"
}, {
    "CODE": "ITE1016",
    "TITLE": "Mobile Application Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BHAVANI S"
}, {
    "CODE": "ITE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG04",
    "SLOT": "A1+TA1",
    "FACULTY": "ALAGIRI I"
}, {
    "CODE": "ITE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG04",
    "SLOT": "A2+TA2",
    "FACULTY": "ALAGIRI I"
}, {
    "CODE": "ITE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG05",
    "SLOT": "A1+TA1",
    "FACULTY": "DEEPA M"
}, {
    "CODE": "ITE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG05",
    "SLOT": "A2+TA2",
    "FACULTY": "DEEPA M"
}, {
    "CODE": "ITE2001",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT114",
    "SLOT": "A2+TA2",
    "FACULTY": "SHASHIKIRAN V"
}, {
    "CODE": "ITE2002",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG04",
    "SLOT": "D2+TD2",
    "FACULTY": "BRIJENDRA SINGH"
}, {
    "CODE": "ITE2002",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG18",
    "SLOT": "L15+L16",
    "FACULTY": "BRIJENDRA SINGH"
}, {
    "CODE": "ITE2002",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG04",
    "SLOT": "D1+TD1",
    "FACULTY": "KUMAR P.J"
}, {
    "CODE": "ITE2002",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG18",
    "SLOT": "L35+L36",
    "FACULTY": "KUMAR P.J"
}, {
    "CODE": "ITE2002",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG05",
    "SLOT": "D1+TD1",
    "FACULTY": "SIVAKUMAR. N"
}, {
    "CODE": "ITE2002",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG18",
    "SLOT": "L43+L44",
    "FACULTY": "SIVAKUMAR. N"
}, {
    "CODE": "ITE2002",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG05",
    "SLOT": "D2+TD2",
    "FACULTY": "SIVAKUMAR. N"
}, {
    "CODE": "ITE2002",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG18",
    "SLOT": "L9+L10",
    "FACULTY": "SIVAKUMAR. N"
}, {
    "CODE": "ITE2004",
    "TITLE": "Software Testing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG10",
    "SLOT": "C1+TC1",
    "FACULTY": "UMA K"
}, {
    "CODE": "ITE2004",
    "TITLE": "Software Testing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "UMA K"
}, {
    "CODE": "ITE2004",
    "TITLE": "Software Testing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG08",
    "SLOT": "C2+TC2",
    "FACULTY": "UMA K"
}, {
    "CODE": "ITE2004",
    "TITLE": "Software Testing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "UMA K"
}, {
    "CODE": "ITE2004",
    "TITLE": "Software Testing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG14",
    "SLOT": "C2+TC2",
    "FACULTY": "IYAPPARAJA M"
}, {
    "CODE": "ITE2004",
    "TITLE": "Software Testing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "IYAPPARAJA M"
}, {
    "CODE": "ITE2005",
    "TITLE": "Advanced Java Programming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG10",
    "SLOT": "G1+TG1",
    "FACULTY": "PUVIARASI G"
}, {
    "CODE": "ITE2005",
    "TITLE": "Advanced Java Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT121",
    "SLOT": "L49+L50",
    "FACULTY": "PUVIARASI G"
}, {
    "CODE": "ITE2005",
    "TITLE": "Advanced Java Programming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG10",
    "SLOT": "G2+TG2",
    "FACULTY": "PRIYA V"
}, {
    "CODE": "ITE2005",
    "TITLE": "Advanced Java Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT121",
    "SLOT": "L25+L26",
    "FACULTY": "PRIYA V"
}, {
    "CODE": "ITE2006",
    "TITLE": "Data Mining Techniques",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG16",
    "SLOT": "B1+TB1",
    "FACULTY": "PRABHAVATHY P"
}, {
    "CODE": "ITE2006",
    "TITLE": "Data Mining Techniques",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PRABHAVATHY P"
}, {
    "CODE": "ITE2006",
    "TITLE": "Data Mining Techniques",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG16",
    "SLOT": "B2+TB2",
    "FACULTY": "PRABHAVATHY P"
}, {
    "CODE": "ITE2006",
    "TITLE": "Data Mining Techniques",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PRABHAVATHY P"
}, {
    "CODE": "ITE2006",
    "TITLE": "Data Mining Techniques",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG23",
    "SLOT": "B1+TB1",
    "FACULTY": "LAKSHMI PRIYA G G"
}, {
    "CODE": "ITE2006",
    "TITLE": "Data Mining Techniques",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "LAKSHMI PRIYA G G"
}, {
    "CODE": "ITE2009",
    "TITLE": "Storage Technologies",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG16",
    "SLOT": "F1+TF1",
    "FACULTY": "SUBHA S"
}, {
    "CODE": "ITE2009",
    "TITLE": "Storage Technologies",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUBHA S"
}, {
    "CODE": "ITE2009",
    "TITLE": "Storage Technologies",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG14",
    "SLOT": "F2+TF2",
    "FACULTY": "SUBHA S"
}, {
    "CODE": "ITE2009",
    "TITLE": "Storage Technologies",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUBHA S"
}, {
    "CODE": "ITE2010",
    "TITLE": "Artificial Intelligence",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG14",
    "SLOT": "C1+TC1",
    "FACULTY": "AJIT KUMAR SANTRA"
}, {
    "CODE": "ITE2010",
    "TITLE": "Artificial Intelligence",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AJIT KUMAR SANTRA"
}, {
    "CODE": "ITE2010",
    "TITLE": "Artificial Intelligence",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG16",
    "SLOT": "C2+TC2",
    "FACULTY": "AJIT KUMAR SANTRA"
}, {
    "CODE": "ITE2010",
    "TITLE": "Artificial Intelligence",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "AJIT KUMAR SANTRA"
}, {
    "CODE": "ITE2011",
    "TITLE": "Machine Learning",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT127",
    "SLOT": "E1+TE1",
    "FACULTY": "DURAI RAJ VINCENT P.M"
}, {
    "CODE": "ITE2011",
    "TITLE": "Machine Learning",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DURAI RAJ VINCENT P.M"
}, {
    "CODE": "ITE2011",
    "TITLE": "Machine Learning",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG08",
    "SLOT": "E2+TE2",
    "FACULTY": "KATHIRAVAN S"
}, {
    "CODE": "ITE2011",
    "TITLE": "Machine Learning",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KATHIRAVAN S"
}, {
    "CODE": "ITE2012",
    "TITLE": ".Net Programming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG14",
    "SLOT": "G2+TG2",
    "FACULTY": "SUMANGALI K"
}, {
    "CODE": "ITE2012",
    "TITLE": ".Net Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG19",
    "SLOT": "L29+L30",
    "FACULTY": "SUMANGALI K"
}, {
    "CODE": "ITE2013",
    "TITLE": "Big Data Analytics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG16",
    "SLOT": "E1+TE1",
    "FACULTY": "GANESAN K"
}, {
    "CODE": "ITE2013",
    "TITLE": "Big Data Analytics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GANESAN K"
}, {
    "CODE": "ITE2013",
    "TITLE": "Big Data Analytics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG16",
    "SLOT": "E2+TE2",
    "FACULTY": "RANICHANDRA C"
}, {
    "CODE": "ITE2013",
    "TITLE": "Big Data Analytics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RANICHANDRA C"
}, {
    "CODE": "ITE2013",
    "TITLE": "Big Data Analytics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG14",
    "SLOT": "E2+TE2",
    "FACULTY": "PARIMALA M"
}, {
    "CODE": "ITE2013",
    "TITLE": "Big Data Analytics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PARIMALA M"
}, {
    "CODE": "ITE2014",
    "TITLE": "Software Project Management",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "SJT127",
    "SLOT": "F1",
    "FACULTY": "THANDEESWARAN R"
}, {
    "CODE": "ITE2014",
    "TITLE": "Software Project Management",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "SJTG16",
    "SLOT": "F2",
    "FACULTY": "KARTHIKEYAN J"
}, {
    "CODE": "ITE2015",
    "TITLE": "Information System Audit",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "SJT127",
    "SLOT": "G2",
    "FACULTY": "HARI RAM VISHWAKARMA"
}, {
    "CODE": "ITE3001",
    "TITLE": "Data Communication and Computer\nNetworks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG10",
    "SLOT": "B1+TB1",
    "FACULTY": "VANI M P"
}, {
    "CODE": "ITE3001",
    "TITLE": "Data Communication and Computer\nNetworks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG10",
    "SLOT": "B2+TB2",
    "FACULTY": "VANI M P"
}, {
    "CODE": "ITE3001",
    "TITLE": "Data Communication and Computer\nNetworks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG24",
    "SLOT": "B1+TB1",
    "FACULTY": "DINAKARAN M"
}, {
    "CODE": "ITE3001",
    "TITLE": "Data Communication and Computer\nNetworks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT120",
    "SLOT": "L57+L58",
    "FACULTY": "VANI M P"
}, {
    "CODE": "ITE3001",
    "TITLE": "Data Communication and Computer\nNetworks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT120",
    "SLOT": "L15+L16",
    "FACULTY": "VANI M P"
}, {
    "CODE": "ITE3001",
    "TITLE": "Data Communication and Computer\nNetworks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT120",
    "SLOT": "L51+L52",
    "FACULTY": "DINAKARAN M"
}, {
    "CODE": "ITE3002",
    "TITLE": "Embedded Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG08",
    "SLOT": "D1+TD1",
    "FACULTY": "KATHIRAVAN S"
}, {
    "CODE": "ITE3002",
    "TITLE": "Embedded Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT122",
    "SLOT": "L45+L46",
    "FACULTY": "KATHIRAVAN S"
}, {
    "CODE": "ITE3004",
    "TITLE": "Distributed Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG14",
    "SLOT": "G1+TG1",
    "FACULTY": "SUDHA M"
}, {
    "CODE": "ITE3004",
    "TITLE": "Distributed Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUDHA M"
}, {
    "CODE": "ITE3007",
    "TITLE": "Cloud Computing and Virtualization",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT127",
    "SLOT": "D1+TD1",
    "FACULTY": "PRIYA V"
}, {
    "CODE": "ITE3007",
    "TITLE": "Cloud Computing and Virtualization",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PRIYA V"
}, {
    "CODE": "ITE398",
    "TITLE": "Mini Project",
    "TYPE": "PJT",
    "CREDITS": "2",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "ITE3999",
    "TITLE": "Technical Answers for Real World\nProblems (TARP)",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJTG23",
    "SLOT": "TG1",
    "FACULTY": "ASWANI KUMAR CHERUKURI"
}, {
    "CODE": "ITE3999",
    "TITLE": "Technical Answers for Real World\nProblems (TARP)",
    "TYPE": "EPJ",
    "CREDITS": "2",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ASWANI KUMAR CHERUKURI"
}, {
    "CODE": "ITE4001",
    "TITLE": "Network and Information Security",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG08",
    "SLOT": "C1+TC1",
    "FACULTY": "JEYANTHI N"
}, {
    "CODE": "ITE4001",
    "TITLE": "Network and Information Security",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JEYANTHI N"
}, {
    "CODE": "ITE4001",
    "TITLE": "Network and Information Security",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG10",
    "SLOT": "C2+TC2",
    "FACULTY": "JEYANTHI N"
}, {
    "CODE": "ITE4001",
    "TITLE": "Network and Information Security",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JEYANTHI N"
}, {
    "CODE": "ITE4001",
    "TITLE": "Network and Information Security",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT127",
    "SLOT": "C1+TC1",
    "FACULTY": "GUNDALA SWATHI"
}, {
    "CODE": "ITE4001",
    "TITLE": "Network and Information Security",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GUNDALA SWATHI"
}, {
    "CODE": "ITE4001",
    "TITLE": "Network and Information Security",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT127",
    "SLOT": "C2+TC2",
    "FACULTY": "GUNDALA SWATHI"
}, {
    "CODE": "ITE4001",
    "TITLE": "Network and Information Security",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GUNDALA SWATHI"
}, {
    "CODE": "ITE4003",
    "TITLE": "Internet of Things",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG08",
    "SLOT": "D2+TD2",
    "FACULTY": "DAPHNE LOPEZ"
}, {
    "CODE": "ITE4003",
    "TITLE": "Internet of Things",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DAPHNE LOPEZ"
}, {
    "CODE": "ITE499",
    "TITLE": "Project Work",
    "TYPE": "PJT",
    "CREDITS": "20",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "ITE6099",
    "TITLE": "Masters Thesis",
    "TYPE": "PJT",
    "CREDITS": "16",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "ITE699",
    "TITLE": "Masters Thesis",
    "TYPE": "PJT",
    "CREDITS": "14",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "MMA110",
    "TITLE": "Concepts of Storyboarding",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT825",
    "SLOT": "A1+TA1",
    "FACULTY": "ANURAG BASAK"
}, {
    "CODE": "MMA2005",
    "TITLE": "Lighting and Rendering",
    "TYPE": "ELA",
    "CREDITS": "3",
    "VENUE": "SJT218",
    "SLOT": "L19+L20+L23+L24+L\n29+L30",
    "FACULTY": "RAJA M"
}, {
    "CODE": "MMA2005",
    "TITLE": "Lighting and Rendering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJA M"
}, {
    "CODE": "MMA2007",
    "TITLE": "Game Development",
    "TYPE": "ELA",
    "CREDITS": "4",
    "VENUE": "SJT219",
    "SLOT": "L9+L10+L11+L12+L2\n7+L28+L29+L30",
    "FACULTY": "DINESH KUMAR R"
}, {
    "CODE": "MMA2007",
    "TITLE": "Game Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DINESH KUMAR R"
}, {
    "CODE": "MMA215",
    "TITLE": "Mini Project I",
    "TYPE": "PJT",
    "CREDITS": "2",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "MMA3001",
    "TITLE": "Modeling and Texturing",
    "TYPE": "ELA",
    "CREDITS": "4",
    "VENUE": "SJT218",
    "SLOT": "L9+L10+L11+L12+L2\n5+L26+L27+L28",
    "FACULTY": "ARUL NITHISH C K"
}, {
    "CODE": "MMA3001",
    "TITLE": "Modeling and Texturing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ARUL NITHISH C K"
}, {
    "CODE": "MMA3002",
    "TITLE": "3D Animation",
    "TYPE": "LO",
    "CREDITS": "4",
    "VENUE": "SJT219",
    "SLOT": "L37+L38+L39+L40+L\n49+L50+L51+L52",
    "FACULTY": "MAHADEVAN R"
}, {
    "CODE": "MMA3005",
    "TITLE": "Scripting and Storyboarding Techniques",
    "TYPE": "ELA",
    "CREDITS": "4",
    "VENUE": "SJT212",
    "SLOT": "L1+L2+L3+L4+L13+L\n14+L15+L16",
    "FACULTY": "RAJA M"
}, {
    "CODE": "MMA3005",
    "TITLE": "Scripting and Storyboarding Techniques",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJA M"
}, {
    "CODE": "MMA3007",
    "TITLE": "Rigging",
    "TYPE": "ELA",
    "CREDITS": "4",
    "VENUE": "SJT218",
    "SLOT": "L31+L32+L33+L34+L\n43+L44+L55+L56",
    "FACULTY": "PRANAVA KUMAR R"
}, {
    "CODE": "MMA3007",
    "TITLE": "Rigging",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PRANAVA KUMAR R"
}, {
    "CODE": "MMA301",
    "TITLE": "Lighting and Rendering",
    "TYPE": "LO",
    "CREDITS": "3",
    "VENUE": "SJT218",
    "SLOT": "L35+L36+L39+L40+L\n59+L60",
    "FACULTY": "SARAVANAN S"
}, {
    "CODE": "MMA3011",
    "TITLE": "Advanced Compositing",
    "TYPE": "ELA",
    "CREDITS": "4",
    "VENUE": "SJT219",
    "SLOT": "L1+L2+L3+L4+L13+L\n14+L15+L16",
    "FACULTY": "DINESH KUMAR R"
}, {
    "CODE": "MMA3011",
    "TITLE": "Advanced Compositing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DINESH KUMAR R"
}, {
    "CODE": "MMA302",
    "TITLE": "Rigging",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT825",
    "SLOT": "D1+TD1",
    "FACULTY": "PRANAVA KUMAR R"
}, {
    "CODE": "MMA302",
    "TITLE": "Rigging",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "SJT219",
    "SLOT": "L47+L48+L53+L54",
    "FACULTY": "PRANAVA KUMAR R"
}, {
    "CODE": "MMA303",
    "TITLE": "3D Animation",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT222",
    "SLOT": "F2+TF2",
    "FACULTY": "ARUL NITHISH C K"
}, {
    "CODE": "MMA303",
    "TITLE": "3D Animation",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "SJT218",
    "SLOT": "L41+L42+L51+L52",
    "FACULTY": "ARUL NITHISH C K"
}, {
    "CODE": "MMA304",
    "TITLE": "Visual Effects",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT825",
    "SLOT": "F1+TF1",
    "FACULTY": "MAHADEVAN R"
}, {
    "CODE": "MMA307",
    "TITLE": "Mini Project II",
    "TYPE": "PJT",
    "CREDITS": "2",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "MMA399",
    "TITLE": "Project Work",
    "TYPE": "PJT",
    "CREDITS": "10",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "SWE1003",
    "TITLE": "Digital Logic and Microprocessor",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT109",
    "SLOT": "D1+TD1",
    "FACULTY": "ASHA JERLIN M"
}, {
    "CODE": "SWE1003",
    "TITLE": "Digital Logic and Microprocessor",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT122",
    "SLOT": "L39+L40",
    "FACULTY": "ASHA JERLIN M"
}, {
    "CODE": "SWE1003",
    "TITLE": "Digital Logic and Microprocessor",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT109",
    "SLOT": "D2+TD2",
    "FACULTY": "ASHA JERLIN M"
}, {
    "CODE": "SWE1003",
    "TITLE": "Digital Logic and Microprocessor",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT122",
    "SLOT": "L5+L6",
    "FACULTY": "ASHA JERLIN M"
}, {
    "CODE": "SWE1003",
    "TITLE": "Digital Logic and Microprocessor",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT112",
    "SLOT": "D1+TD1",
    "FACULTY": "SUGANYA P"
}, {
    "CODE": "SWE1003",
    "TITLE": "Digital Logic and Microprocessor",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT122",
    "SLOT": "L41+L42",
    "FACULTY": "SUGANYA P"
}, {
    "CODE": "SWE1003",
    "TITLE": "Digital Logic and Microprocessor",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT112",
    "SLOT": "D2+TD2",
    "FACULTY": "SUGANYA P"
}, {
    "CODE": "SWE1003",
    "TITLE": "Digital Logic and Microprocessor",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT122",
    "SLOT": "L7+L8",
    "FACULTY": "SUGANYA P"
}, {
    "CODE": "SWE1003",
    "TITLE": "Digital Logic and Microprocessor",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT113",
    "SLOT": "D1+TD1",
    "FACULTY": "PRAVEEN KUMAR REDDY M."
}, {
    "CODE": "SWE1003",
    "TITLE": "Digital Logic and Microprocessor",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT122",
    "SLOT": "L59+L60",
    "FACULTY": "PRAVEEN KUMAR REDDY M."
}, {
    "CODE": "SWE1003",
    "TITLE": "Digital Logic and Microprocessor",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT113",
    "SLOT": "D2+TD2",
    "FACULTY": "PRAVEEN KUMAR REDDY M."
}, {
    "CODE": "SWE1003",
    "TITLE": "Digital Logic and Microprocessor",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT122",
    "SLOT": "L11+L12",
    "FACULTY": "PRAVEEN KUMAR REDDY M."
}, {
    "CODE": "SWE1003",
    "TITLE": "Digital Logic and Microprocessor",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT114",
    "SLOT": "D2+TD2",
    "FACULTY": "SWARNA PRIYA R.M"
}, {
    "CODE": "SWE1003",
    "TITLE": "Digital Logic and Microprocessor",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT122",
    "SLOT": "L23+L24",
    "FACULTY": "SWARNA PRIYA R.M"
}, {
    "CODE": "SWE1004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT112",
    "SLOT": "C2+TC2",
    "FACULTY": "TAPAN KUMAR DAS"
}, {
    "CODE": "SWE1004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG19",
    "SLOT": "L9+L10",
    "FACULTY": "TAPAN KUMAR DAS"
}, {
    "CODE": "SWE1004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT109",
    "SLOT": "C1+TC1",
    "FACULTY": "MOHAN KUMAR P"
}, {
    "CODE": "SWE1004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG19",
    "SLOT": "L35+L36",
    "FACULTY": "MOHAN KUMAR P"
}, {
    "CODE": "SWE1004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT109",
    "SLOT": "C2+TC2",
    "FACULTY": "MOHAN KUMAR P"
}, {
    "CODE": "SWE1004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG19",
    "SLOT": "L3+L4",
    "FACULTY": "MOHAN KUMAR P"
}, {
    "CODE": "SWE1004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT112",
    "SLOT": "C1+TC1",
    "FACULTY": "SENTHILKUMAR N C"
}, {
    "CODE": "SWE1004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG19",
    "SLOT": "L55+L56",
    "FACULTY": "SENTHILKUMAR N C"
}, {
    "CODE": "SWE1004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT113",
    "SLOT": "C1+TC1",
    "FACULTY": "MUTHAMIL SELVAN T"
}, {
    "CODE": "SWE1004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT219",
    "SLOT": "L33+L34",
    "FACULTY": "MUTHAMIL SELVAN T"
}, {
    "CODE": "SWE1004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT113",
    "SLOT": "C2+TC2",
    "FACULTY": "SARAVANAKUMAR K"
}, {
    "CODE": "SWE1004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG19",
    "SLOT": "L15+L16",
    "FACULTY": "SARAVANAKUMAR K"
}, {
    "CODE": "SWE1004",
    "TITLE": "Database Management Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT114",
    "SLOT": "C1+TC1",
    "FACULTY": "JAYARAM REDDY A"
}, {
    "CODE": "SWE1004",
    "TITLE": "Database Management Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT219",
    "SLOT": "L43+L44",
    "FACULTY": "JAYARAM REDDY A"
}, {
    "CODE": "SWE1005",
    "TITLE": "Computer Architecture and\nOrganization",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG23",
    "SLOT": "D2+TD2",
    "FACULTY": "NAVANEETHAN C"
}, {
    "CODE": "SWE1006",
    "TITLE": "Theory of Computation",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT215",
    "SLOT": "C1+TC1",
    "FACULTY": "SWARNA PRIYA R.M"
}, {
    "CODE": "SWE1006",
    "TITLE": "Theory of Computation",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT221",
    "SLOT": "C1+TC1",
    "FACULTY": "RAMYA.G"
}, {
    "CODE": "SWE1006",
    "TITLE": "Theory of Computation",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT221",
    "SLOT": "C2+TC2",
    "FACULTY": "RAMYA.G"
}, {
    "CODE": "SWE1006",
    "TITLE": "Theory of Computation",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT215",
    "SLOT": "C2+TC2",
    "FACULTY": "DHARMENDRA SINGH RAJPUT"
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT113",
    "SLOT": "B1+TB1",
    "FACULTY": "SUBA SHANTHINI S"
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT120",
    "SLOT": "L53+L54",
    "FACULTY": "SUBA SHANTHINI S"
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUBA SHANTHINI S"
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT113",
    "SLOT": "B2+TB2",
    "FACULTY": "SUBA SHANTHINI S"
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT120",
    "SLOT": "L29+L30",
    "FACULTY": "SUBA SHANTHINI S"
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUBA SHANTHINI S"
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT114",
    "SLOT": "B1+TB1",
    "FACULTY": "MALATHY E"
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG19",
    "SLOT": "L47+L48",
    "FACULTY": "MALATHY E"
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MALATHY E"
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT114",
    "SLOT": "B2+TB2",
    "FACULTY": "MALATHY E"
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT120",
    "SLOT": "L27+L28",
    "FACULTY": "MALATHY E"
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MALATHY E"
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT112",
    "SLOT": "B1+TB1",
    "FACULTY": "IYAPPARAJA M"
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT120",
    "SLOT": "L45+L46",
    "FACULTY": "IYAPPARAJA M"
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "IYAPPARAJA M"
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT208",
    "SLOT": "B2+TB2",
    "FACULTY": "NALLAKARUPPAN M.K."
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG20",
    "SLOT": "L25+L26",
    "FACULTY": "NALLAKARUPPAN M.K."
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NALLAKARUPPAN M.K."
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT115",
    "SLOT": "B1+TB1",
    "FACULTY": "ASIS KUMAR TRIPATHY"
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG20",
    "SLOT": "L57+L58",
    "FACULTY": "ASIS KUMAR TRIPATHY"
}, {
    "CODE": "SWE1007",
    "TITLE": "Programming in Java",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ASIS KUMAR TRIPATHY"
}, {
    "CODE": "SWE1008",
    "TITLE": "Web Technologies",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT118",
    "SLOT": "B1+TB1",
    "FACULTY": "RATHI R"
}, {
    "CODE": "SWE1008",
    "TITLE": "Web Technologies",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT216",
    "SLOT": "L45+L46",
    "FACULTY": "RATHI R"
}, {
    "CODE": "SWE1008",
    "TITLE": "Web Technologies",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT118",
    "SLOT": "B2+TB2",
    "FACULTY": "RATHI R"
}, {
    "CODE": "SWE1008",
    "TITLE": "Web Technologies",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT216",
    "SLOT": "L23+L24",
    "FACULTY": "RATHI R"
}, {
    "CODE": "SWE1008",
    "TITLE": "Web Technologies",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT124",
    "SLOT": "B1+TB1",
    "FACULTY": "BRINDHA K"
}, {
    "CODE": "SWE1008",
    "TITLE": "Web Technologies",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT216",
    "SLOT": "L55+L56",
    "FACULTY": "BRINDHA K"
}, {
    "CODE": "SWE1008",
    "TITLE": "Web Technologies",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT124",
    "SLOT": "B2+TB2",
    "FACULTY": "BRINDHA K"
}, {
    "CODE": "SWE1008",
    "TITLE": "Web Technologies",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT216",
    "SLOT": "L11+L12",
    "FACULTY": "BRINDHA K"
}, {
    "CODE": "SWE1009",
    "TITLE": ".Net Programming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT118",
    "SLOT": "C1+TC1",
    "FACULTY": "LAWANYA SHRI M"
}, {
    "CODE": "SWE1009",
    "TITLE": ".Net Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG19",
    "SLOT": "L57+L58",
    "FACULTY": "LAWANYA SHRI M"
}, {
    "CODE": "SWE1009",
    "TITLE": ".Net Programming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT118",
    "SLOT": "C2+TC2",
    "FACULTY": "SATHIYAMOORTHY E"
}, {
    "CODE": "SWE1009",
    "TITLE": ".Net Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG19",
    "SLOT": "L19+L20",
    "FACULTY": "SATHIYAMOORTHY E"
}, {
    "CODE": "SWE1009",
    "TITLE": ".Net Programming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT124",
    "SLOT": "C1+TC1",
    "FACULTY": "SUMANGALI K"
}, {
    "CODE": "SWE1009",
    "TITLE": ".Net Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG19",
    "SLOT": "L41+L42",
    "FACULTY": "SUMANGALI K"
}, {
    "CODE": "SWE1010",
    "TITLE": "Digital Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT124",
    "SLOT": "E1+TE1",
    "FACULTY": "PRABUKUMAR M"
}, {
    "CODE": "SWE1010",
    "TITLE": "Digital Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PRABUKUMAR M"
}, {
    "CODE": "SWE1010",
    "TITLE": "Digital Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT124",
    "SLOT": "E2+TE2",
    "FACULTY": "PRABUKUMAR M"
}, {
    "CODE": "SWE1010",
    "TITLE": "Digital Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PRABUKUMAR M"
}, {
    "CODE": "SWE1010",
    "TITLE": "Digital Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT125",
    "SLOT": "E1+TE1",
    "FACULTY": "SRINIVAS KOPPU"
}, {
    "CODE": "SWE1010",
    "TITLE": "Digital Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SRINIVAS KOPPU"
}, {
    "CODE": "SWE1010",
    "TITLE": "Digital Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT125",
    "SLOT": "E2+TE2",
    "FACULTY": "SRINIVAS KOPPU"
}, {
    "CODE": "SWE1010",
    "TITLE": "Digital Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SRINIVAS KOPPU"
}, {
    "CODE": "SWE1010",
    "TITLE": "Digital Image Processing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG08",
    "SLOT": "E1+TE1",
    "FACULTY": "HEMALATHA S"
}, {
    "CODE": "SWE1010",
    "TITLE": "Digital Image Processing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "HEMALATHA S"
}, {
    "CODE": "SWE1011",
    "TITLE": "Soft Computing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT109",
    "SLOT": "B1+TB1",
    "FACULTY": "RAJESH KALURI"
}, {
    "CODE": "SWE1011",
    "TITLE": "Soft Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJESH KALURI"
}, {
    "CODE": "SWE1011",
    "TITLE": "Soft Computing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT109",
    "SLOT": "B2+TB2",
    "FACULTY": "RAJESH KALURI"
}, {
    "CODE": "SWE1011",
    "TITLE": "Soft Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJESH KALURI"
}, {
    "CODE": "SWE1011",
    "TITLE": "Soft Computing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT215",
    "SLOT": "B1+TB1",
    "FACULTY": "SENTHIL KUMAR P"
}, {
    "CODE": "SWE1011",
    "TITLE": "Soft Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SENTHIL KUMAR P"
}, {
    "CODE": "SWE1011",
    "TITLE": "Soft Computing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT215",
    "SLOT": "B2+TB2",
    "FACULTY": "SENTHIL KUMAR P"
}, {
    "CODE": "SWE1011",
    "TITLE": "Soft Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SENTHIL KUMAR P"
}, {
    "CODE": "SWE1012",
    "TITLE": "E-Governance",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT125",
    "SLOT": "C1",
    "FACULTY": "ALAGIRI I"
}, {
    "CODE": "SWE1012",
    "TITLE": "E-Governance",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ALAGIRI I"
}, {
    "CODE": "SWE1012",
    "TITLE": "E-Governance",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT124",
    "SLOT": "C2",
    "FACULTY": "JAGADEESH G"
}, {
    "CODE": "SWE1012",
    "TITLE": "E-Governance",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JAGADEESH G"
}, {
    "CODE": "SWE1012",
    "TITLE": "E-Governance",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT126",
    "SLOT": "C2",
    "FACULTY": "KUMARESAN P"
}, {
    "CODE": "SWE1012",
    "TITLE": "E-Governance",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KUMARESAN P"
}, {
    "CODE": "SWE1012",
    "TITLE": "E-Governance",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT126",
    "SLOT": "C1",
    "FACULTY": "KUMARESAN P"
}, {
    "CODE": "SWE1012",
    "TITLE": "E-Governance",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KUMARESAN P"
}, {
    "CODE": "SWE1013",
    "TITLE": "Multimedia Systems",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG08",
    "SLOT": "F2+TF2",
    "FACULTY": "GUNASEKARAN G"
}, {
    "CODE": "SWE1013",
    "TITLE": "Multimedia Systems",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG08",
    "SLOT": "F1+TF1",
    "FACULTY": "RAHAMATHUNNISA U"
}, {
    "CODE": "SWE1013",
    "TITLE": "Multimedia Systems",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT221",
    "SLOT": "F2+TF2",
    "FACULTY": "RAHAMATHUNNISA U"
}, {
    "CODE": "SWE1013",
    "TITLE": "Multimedia Systems",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG23",
    "SLOT": "F1+TF1",
    "FACULTY": "SARAVANAN S"
}, {
    "CODE": "SWE1014",
    "TITLE": "Enterprise Resource Planning",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT126",
    "SLOT": "F1",
    "FACULTY": "NADESH R.K"
}, {
    "CODE": "SWE1014",
    "TITLE": "Enterprise Resource Planning",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NADESH R.K"
}, {
    "CODE": "SWE1014",
    "TITLE": "Enterprise Resource Planning",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT215",
    "SLOT": "F1",
    "FACULTY": "SUJATHA R"
}, {
    "CODE": "SWE1014",
    "TITLE": "Enterprise Resource Planning",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUJATHA R"
}, {
    "CODE": "SWE1014",
    "TITLE": "Enterprise Resource Planning",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT215",
    "SLOT": "F2",
    "FACULTY": "SUJATHA R"
}, {
    "CODE": "SWE1014",
    "TITLE": "Enterprise Resource Planning",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUJATHA R"
}, {
    "CODE": "SWE1014",
    "TITLE": "Enterprise Resource Planning",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJTG23",
    "SLOT": "F2",
    "FACULTY": "NADESH R.K"
}, {
    "CODE": "SWE1014",
    "TITLE": "Enterprise Resource Planning",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NADESH R.K"
}, {
    "CODE": "SWE1015",
    "TITLE": "Biometric Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT126",
    "SLOT": "D1",
    "FACULTY": "CHIRANJI LAL CHOWDHARY"
}, {
    "CODE": "SWE1015",
    "TITLE": "Biometric Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "CHIRANJI LAL CHOWDHARY"
}, {
    "CODE": "SWE1015",
    "TITLE": "Biometric Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT126",
    "SLOT": "D2",
    "FACULTY": "RAMYA.G"
}, {
    "CODE": "SWE1015",
    "TITLE": "Biometric Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMYA.G"
}, {
    "CODE": "SWE1018",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT109",
    "SLOT": "A2",
    "FACULTY": "RAJESWARI C"
}, {
    "CODE": "SWE1018",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJESWARI C"
}, {
    "CODE": "SWE1018",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT112",
    "SLOT": "A1",
    "FACULTY": "RAJESWARI C"
}, {
    "CODE": "SWE1018",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJESWARI C"
}, {
    "CODE": "SWE1018",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT112",
    "SLOT": "A2",
    "FACULTY": "KAMALAKANNAN J"
}, {
    "CODE": "SWE1018",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KAMALAKANNAN J"
}, {
    "CODE": "SWE1018",
    "TITLE": "Human Computer Interaction",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT109",
    "SLOT": "A1",
    "FACULTY": "CHIRANJI LAL CHOWDHARY"
}, {
    "CODE": "SWE1018",
    "TITLE": "Human Computer Interaction",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "CHIRANJI LAL CHOWDHARY"
}, {
    "CODE": "SWE1701",
    "TITLE": "Software Engineering",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG24",
    "SLOT": "F1+TF1",
    "FACULTY": "THILAGAVATHI M"
}, {
    "CODE": "SWE2001",
    "TITLE": "Data Structures and Algorithms",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG24",
    "SLOT": "C1+TC1",
    "FACULTY": "SARAVANAKUMAR K"
}, {
    "CODE": "SWE2001",
    "TITLE": "Data Structures and Algorithms",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT218",
    "SLOT": "L37+L38",
    "FACULTY": "SARAVANAKUMAR K"
}, {
    "CODE": "SWE2002",
    "TITLE": "Computer Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT118",
    "SLOT": "A1+TA1",
    "FACULTY": "VIJAYAN R"
}, {
    "CODE": "SWE2002",
    "TITLE": "Computer Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT216",
    "SLOT": "L53+L54",
    "FACULTY": "VIJAYAN R"
}, {
    "CODE": "SWE2002",
    "TITLE": "Computer Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT118",
    "SLOT": "A2+TA2",
    "FACULTY": "VIJAYAN R"
}, {
    "CODE": "SWE2002",
    "TITLE": "Computer Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT120",
    "SLOT": "L21+L22",
    "FACULTY": "VIJAYAN R"
}, {
    "CODE": "SWE2002",
    "TITLE": "Computer Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT124",
    "SLOT": "A1+TA1",
    "FACULTY": "PRIYA M"
}, {
    "CODE": "SWE2002",
    "TITLE": "Computer Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG18",
    "SLOT": "L47+L48",
    "FACULTY": "PRIYA M"
}, {
    "CODE": "SWE2002",
    "TITLE": "Computer Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT124",
    "SLOT": "A2+TA2",
    "FACULTY": "PRIYA M"
}, {
    "CODE": "SWE2002",
    "TITLE": "Computer Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT216",
    "SLOT": "L3+L4",
    "FACULTY": "PRIYA M"
}, {
    "CODE": "SWE2002",
    "TITLE": "Computer Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT125",
    "SLOT": "A2+TA2",
    "FACULTY": "USHA DEVI G"
}, {
    "CODE": "SWE2002",
    "TITLE": "Computer Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT120",
    "SLOT": "L13+L14",
    "FACULTY": "USHA DEVI G"
}, {
    "CODE": "SWE2002",
    "TITLE": "Computer Networks",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT125",
    "SLOT": "A1+TA1",
    "FACULTY": "DINAKARAN M"
}, {
    "CODE": "SWE2002",
    "TITLE": "Computer Networks",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT217",
    "SLOT": "L43+L44",
    "FACULTY": "DINAKARAN M"
}, {
    "CODE": "SWE2003",
    "TITLE": "Requirements Engineering and\nManagement",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT113",
    "SLOT": "E1",
    "FACULTY": "DEEPA P"
}, {
    "CODE": "SWE2003",
    "TITLE": "Requirements Engineering and\nManagement",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DEEPA P"
}, {
    "CODE": "SWE2003",
    "TITLE": "Requirements Engineering and\nManagement",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT113",
    "SLOT": "E2",
    "FACULTY": "DEEPA P"
}, {
    "CODE": "SWE2003",
    "TITLE": "Requirements Engineering and\nManagement",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DEEPA P"
}, {
    "CODE": "SWE2003",
    "TITLE": "Requirements Engineering and\nManagement",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT112",
    "SLOT": "E1",
    "FACULTY": "KIRUBA THANGAM R"
}, {
    "CODE": "SWE2003",
    "TITLE": "Requirements Engineering and\nManagement",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KIRUBA THANGAM R"
}, {
    "CODE": "SWE2003",
    "TITLE": "Requirements Engineering and\nManagement",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT112",
    "SLOT": "E2",
    "FACULTY": "KIRUBA THANGAM R"
}, {
    "CODE": "SWE2003",
    "TITLE": "Requirements Engineering and\nManagement",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KIRUBA THANGAM R"
}, {
    "CODE": "SWE2003",
    "TITLE": "Requirements Engineering and\nManagement",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT114",
    "SLOT": "E1",
    "FACULTY": "DEEPA M"
}, {
    "CODE": "SWE2003",
    "TITLE": "Requirements Engineering and\nManagement",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DEEPA M"
}, {
    "CODE": "SWE2003",
    "TITLE": "Requirements Engineering and\nManagement",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT109",
    "SLOT": "E1",
    "FACULTY": "KRITHIKA L.B"
}, {
    "CODE": "SWE2003",
    "TITLE": "Requirements Engineering and\nManagement",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KRITHIKA L.B"
}, {
    "CODE": "SWE2003",
    "TITLE": "Requirements Engineering and\nManagement",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT109",
    "SLOT": "E2",
    "FACULTY": "KRITHIKA L.B"
}, {
    "CODE": "SWE2003",
    "TITLE": "Requirements Engineering and\nManagement",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KRITHIKA L.B"
}, {
    "CODE": "SWE2004",
    "TITLE": "Software Architecture and Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT118",
    "SLOT": "D1",
    "FACULTY": "SENTHIL KUMARAN U"
}, {
    "CODE": "SWE2004",
    "TITLE": "Software Architecture and Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SENTHIL KUMARAN U"
}, {
    "CODE": "SWE2004",
    "TITLE": "Software Architecture and Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT125",
    "SLOT": "D2",
    "FACULTY": "SENTHIL KUMARAN U"
}, {
    "CODE": "SWE2004",
    "TITLE": "Software Architecture and Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SENTHIL KUMARAN U"
}, {
    "CODE": "SWE2004",
    "TITLE": "Software Architecture and Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT127",
    "SLOT": "D2",
    "FACULTY": "KARTHIKEYAN P"
}, {
    "CODE": "SWE2004",
    "TITLE": "Software Architecture and Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KARTHIKEYAN P"
}, {
    "CODE": "SWE2004",
    "TITLE": "Software Architecture and Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT114",
    "SLOT": "D1",
    "FACULTY": "SREE DHARINYA S"
}, {
    "CODE": "SWE2004",
    "TITLE": "Software Architecture and Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SREE DHARINYA S"
}, {
    "CODE": "SWE2005",
    "TITLE": "Software Testing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT222",
    "SLOT": "B1+TB1",
    "FACULTY": "SENTHIL KUMAR. M"
}, {
    "CODE": "SWE2005",
    "TITLE": "Software Testing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SENTHIL KUMAR. M"
}, {
    "CODE": "SWE2005",
    "TITLE": "Software Testing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT223",
    "SLOT": "B2+TB2",
    "FACULTY": "SENTHIL KUMAR. M"
}, {
    "CODE": "SWE2005",
    "TITLE": "Software Testing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SENTHIL KUMAR. M"
}, {
    "CODE": "SWE2005",
    "TITLE": "Software Testing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT126",
    "SLOT": "B1+TB1",
    "FACULTY": "MAGESH G"
}, {
    "CODE": "SWE2005",
    "TITLE": "Software Testing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MAGESH G"
}, {
    "CODE": "SWE2005",
    "TITLE": "Software Testing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT221",
    "SLOT": "B2+TB2",
    "FACULTY": "MAGESH G"
}, {
    "CODE": "SWE2005",
    "TITLE": "Software Testing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MAGESH G"
}, {
    "CODE": "SWE2006",
    "TITLE": "Software Project Management",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT215",
    "SLOT": "E1",
    "FACULTY": "KAMALAKANNAN J"
}, {
    "CODE": "SWE2006",
    "TITLE": "Software Project Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KAMALAKANNAN J"
}, {
    "CODE": "SWE2006",
    "TITLE": "Software Project Management",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT118",
    "SLOT": "E2",
    "FACULTY": "KAMALAKANNAN J"
}, {
    "CODE": "SWE2006",
    "TITLE": "Software Project Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KAMALAKANNAN J"
}, {
    "CODE": "SWE2007",
    "TITLE": "Software Construction and\nMaintenance",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT118",
    "SLOT": "D2",
    "FACULTY": "DHINESH BABU L.D"
}, {
    "CODE": "SWE2007",
    "TITLE": "Software Construction and\nMaintenance",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DHINESH BABU L.D"
}, {
    "CODE": "SWE2007",
    "TITLE": "Software Construction and\nMaintenance",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT124",
    "SLOT": "D1",
    "FACULTY": "TAMIL PRIYA D"
}, {
    "CODE": "SWE2007",
    "TITLE": "Software Construction and\nMaintenance",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "TAMIL PRIYA D"
}, {
    "CODE": "SWE2007",
    "TITLE": "Software Construction and\nMaintenance",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT124",
    "SLOT": "D2",
    "FACULTY": "TAMIL PRIYA D"
}, {
    "CODE": "SWE2007",
    "TITLE": "Software Construction and\nMaintenance",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "TAMIL PRIYA D"
}, {
    "CODE": "SWE2008",
    "TITLE": "Android Programming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG23",
    "SLOT": "E2+TE2",
    "FACULTY": "NAGA RAJA G"
}, {
    "CODE": "SWE2008",
    "TITLE": "Android Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NAGA RAJA G"
}, {
    "CODE": "SWE2008",
    "TITLE": "Android Programming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT223",
    "SLOT": "E1+TE1",
    "FACULTY": "SENTHIL MURUGAN B"
}, {
    "CODE": "SWE2008",
    "TITLE": "Android Programming",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SENTHIL MURUGAN B"
}, {
    "CODE": "SWE2009",
    "TITLE": "Data Mining Techniques",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT126",
    "SLOT": "A1+TA1",
    "FACULTY": "NEELU KHARE"
}, {
    "CODE": "SWE2009",
    "TITLE": "Data Mining Techniques",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NEELU KHARE"
}, {
    "CODE": "SWE2009",
    "TITLE": "Data Mining Techniques",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT126",
    "SLOT": "A2+TA2",
    "FACULTY": "SUDHA M"
}, {
    "CODE": "SWE2009",
    "TITLE": "Data Mining Techniques",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUDHA M"
}, {
    "CODE": "SWE2009",
    "TITLE": "Data Mining Techniques",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT223",
    "SLOT": "A1+TA1",
    "FACULTY": "SATHIYAMOORTHY E"
}, {
    "CODE": "SWE2009",
    "TITLE": "Data Mining Techniques",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SATHIYAMOORTHY E"
}, {
    "CODE": "SWE2012",
    "TITLE": "Software Security",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT125",
    "SLOT": "B1",
    "FACULTY": "SUMAIYA THASEEN I"
}, {
    "CODE": "SWE2012",
    "TITLE": "Software Security",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUMAIYA THASEEN I"
}, {
    "CODE": "SWE2012",
    "TITLE": "Software Security",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT125",
    "SLOT": "B2",
    "FACULTY": "SUMAIYA THASEEN I"
}, {
    "CODE": "SWE2012",
    "TITLE": "Software Security",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUMAIYA THASEEN I"
}, {
    "CODE": "SWE2012",
    "TITLE": "Software Security",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT126",
    "SLOT": "B2",
    "FACULTY": "RAMESH P.S"
}, {
    "CODE": "SWE2012",
    "TITLE": "Software Security",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMESH P.S"
}, {
    "CODE": "SWE2018",
    "TITLE": "Object Oriented Analysis and Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT126",
    "SLOT": "F2+TF2",
    "FACULTY": "SHANTHARAJAH S P"
}, {
    "CODE": "SWE2018",
    "TITLE": "Object Oriented Analysis and Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG17",
    "SLOT": "L11+L12",
    "FACULTY": "SHANTHARAJAH S P"
}, {
    "CODE": "SWE2018",
    "TITLE": "Object Oriented Analysis and Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT112",
    "SLOT": "F1+TF1",
    "FACULTY": "KARTHIKEYAN P"
}, {
    "CODE": "SWE2018",
    "TITLE": "Object Oriented Analysis and Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG17",
    "SLOT": "L51+L52",
    "FACULTY": "KARTHIKEYAN P"
}, {
    "CODE": "SWE2018",
    "TITLE": "Object Oriented Analysis and Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT109",
    "SLOT": "F2+TF2",
    "FACULTY": "PRABHU J"
}, {
    "CODE": "SWE2018",
    "TITLE": "Object Oriented Analysis and Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG17",
    "SLOT": "L21+L22",
    "FACULTY": "PRABHU J"
}, {
    "CODE": "SWE2018",
    "TITLE": "Object Oriented Analysis and Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT221",
    "SLOT": "F1+TF1",
    "FACULTY": "PRABHU J"
}, {
    "CODE": "SWE2018",
    "TITLE": "Object Oriented Analysis and Design",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG17",
    "SLOT": "L49+L50",
    "FACULTY": "PRABHU J"
}, {
    "CODE": "SWE2019",
    "TITLE": "Design Patterns",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT207A",
    "SLOT": "A2+TA2",
    "FACULTY": "KUMARAN U"
}, {
    "CODE": "SWE2019",
    "TITLE": "Design Patterns",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT215",
    "SLOT": "A1+TA1",
    "FACULTY": "USHAPREETHI P"
}, {
    "CODE": "SWE2019",
    "TITLE": "Design Patterns",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT215",
    "SLOT": "A2+TA2",
    "FACULTY": "USHAPREETHI P"
}, {
    "CODE": "SWE2019",
    "TITLE": "Design Patterns",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG08",
    "SLOT": "A1+TA1",
    "FACULTY": "SENTHIL KUMARAN U"
}, {
    "CODE": "SWE2020",
    "TITLE": "Software Metrics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT221",
    "SLOT": "A1+TA1",
    "FACULTY": "SRINIVASA PERUMAL R"
}, {
    "CODE": "SWE2020",
    "TITLE": "Software Metrics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT221",
    "SLOT": "A2+TA2",
    "FACULTY": "SRINIVASA PERUMAL R"
}, {
    "CODE": "SWE2020",
    "TITLE": "Software Metrics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT222",
    "SLOT": "A1+TA1",
    "FACULTY": "CHANDRASEGAR.T"
}, {
    "CODE": "SWE2020",
    "TITLE": "Software Metrics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT222",
    "SLOT": "A2+TA2",
    "FACULTY": "CHANDRASEGAR.T"
}, {
    "CODE": "SWE2021",
    "TITLE": "Software Configuration Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT221",
    "SLOT": "D1+TD1",
    "FACULTY": "JAGADEESH G"
}, {
    "CODE": "SWE2021",
    "TITLE": "Software Configuration Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT221",
    "SLOT": "D2+TD2",
    "FACULTY": "JAGADEESH G"
}, {
    "CODE": "SWE2021",
    "TITLE": "Software Configuration Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT215",
    "SLOT": "D2+TD2",
    "FACULTY": "KRITHIKA L.B"
}, {
    "CODE": "SWE2021",
    "TITLE": "Software Configuration Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT215",
    "SLOT": "D1+TD1",
    "FACULTY": "KIRUBA THANGAM R"
}, {
    "CODE": "SWE2022",
    "TITLE": "Software Engineering Process, Tools\nand Methods",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT222",
    "SLOT": "C1",
    "FACULTY": "DHINESH BABU L.D"
}, {
    "CODE": "SWE2022",
    "TITLE": "Software Engineering Process, Tools\nand Methods",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DHINESH BABU L.D"
}, {
    "CODE": "SWE2022",
    "TITLE": "Software Engineering Process, Tools\nand Methods",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT222",
    "SLOT": "C2",
    "FACULTY": "DHINESH BABU L.D"
}, {
    "CODE": "SWE2022",
    "TITLE": "Software Engineering Process, Tools\nand Methods",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DHINESH BABU L.D"
}, {
    "CODE": "SWE2024",
    "TITLE": "Software Reuse",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT113",
    "SLOT": "F1+TF1",
    "FACULTY": "RAMA PRABHA K.P"
}, {
    "CODE": "SWE2024",
    "TITLE": "Software Reuse",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT113",
    "SLOT": "F2+TF2",
    "FACULTY": "RAMA PRABHA K.P"
}, {
    "CODE": "SWE2024",
    "TITLE": "Software Reuse",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT207A",
    "SLOT": "F2+TF2",
    "FACULTY": "ASHA N"
}, {
    "CODE": "SWE2024",
    "TITLE": "Software Reuse",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT114",
    "SLOT": "F1+TF1",
    "FACULTY": "ASHA N"
}, {
    "CODE": "SWE2027",
    "TITLE": "Knowledge Management System",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT222",
    "SLOT": "D1",
    "FACULTY": "HARI RAM VISHWAKARMA"
}, {
    "CODE": "SWE2027",
    "TITLE": "Knowledge Management System",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "HARI RAM VISHWAKARMA"
}, {
    "CODE": "SWE2027",
    "TITLE": "Knowledge Management System",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT222",
    "SLOT": "D2",
    "FACULTY": "HARI RAM VISHWAKARMA"
}, {
    "CODE": "SWE2027",
    "TITLE": "Knowledge Management System",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "HARI RAM VISHWAKARMA"
}, {
    "CODE": "SWE2029",
    "TITLE": "Agile Development Process",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT825",
    "SLOT": "E1+TE1",
    "FACULTY": "VIJAY ANAND R"
}, {
    "CODE": "SWE2029",
    "TITLE": "Agile Development Process",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT222",
    "SLOT": "E2+TE2",
    "FACULTY": "VIJAY ANAND R"
}, {
    "CODE": "SWE2029",
    "TITLE": "Agile Development Process",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT221",
    "SLOT": "E2+TE2",
    "FACULTY": "KUMARESAN P"
}, {
    "CODE": "SWE207",
    "TITLE": "Object Oriented Analysis and Design Lab",
    "TYPE": "LO",
    "CREDITS": "2",
    "VENUE": "SJTG17",
    "SLOT": "L27+L28+L29+L30",
    "FACULTY": "MANIKANDAN N"
}, {
    "CODE": "SWE3001",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT124",
    "SLOT": "F1+TF1",
    "FACULTY": "ARIVUSELVAN K"
}, {
    "CODE": "SWE3001",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT216",
    "SLOT": "L37+L38",
    "FACULTY": "ARIVUSELVAN K"
}, {
    "CODE": "SWE3001",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT124",
    "SLOT": "F2+TF2",
    "FACULTY": "ARIVUSELVAN K"
}, {
    "CODE": "SWE3001",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT216",
    "SLOT": "L9+L10",
    "FACULTY": "ARIVUSELVAN K"
}, {
    "CODE": "SWE3001",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT118",
    "SLOT": "F2+TF2",
    "FACULTY": "KUMAR P.J"
}, {
    "CODE": "SWE3001",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT216",
    "SLOT": "L5+L6",
    "FACULTY": "KUMAR P.J"
}, {
    "CODE": "SWE3001",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT125",
    "SLOT": "F1+TF1",
    "FACULTY": "SUDHA.S"
}, {
    "CODE": "SWE3001",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT217",
    "SLOT": "L49+L50",
    "FACULTY": "SUDHA.S"
}, {
    "CODE": "SWE3001",
    "TITLE": "Operating Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT216",
    "SLOT": "L25+L26",
    "FACULTY": "SUDHA.S"
}, {
    "CODE": "SWE3001",
    "TITLE": "Operating Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT125",
    "SLOT": "F2+TF2",
    "FACULTY": "SUDHA.S"
}, {
    "CODE": "SWE3002",
    "TITLE": "Information and System Security",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT126",
    "SLOT": "E2+TE2",
    "FACULTY": "MANGAYARKARASI R"
}, {
    "CODE": "SWE3002",
    "TITLE": "Information and System Security",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MANGAYARKARASI R"
}, {
    "CODE": "SWE3002",
    "TITLE": "Information and System Security",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG23",
    "SLOT": "E1+TE1",
    "FACULTY": "MANGAYARKARASI R"
}, {
    "CODE": "SWE3002",
    "TITLE": "Information and System Security",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MANGAYARKARASI R"
}, {
    "CODE": "SWE3005",
    "TITLE": "Software Quality and Reliability",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT112",
    "SLOT": "B2+TB2",
    "FACULTY": "RAMA PRABHA K.P"
}, {
    "CODE": "SWE3005",
    "TITLE": "Software Quality and Reliability",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT807",
    "SLOT": "B1+TB1",
    "FACULTY": "ABRAHAM PAUL"
}, {
    "CODE": "SWE311",
    "TITLE": "Internet and Web Programming",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT211A",
    "SLOT": "G2+TG2",
    "FACULTY": "JOHN SINGH K."
}, {
    "CODE": "SWE313",
    "TITLE": "Android Programming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG24",
    "SLOT": "C2+TC2",
    "FACULTY": "KAVITHA G"
}, {
    "CODE": "SWE313",
    "TITLE": "Android Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT121",
    "SLOT": "L11+L12",
    "FACULTY": "KAVITHA G"
}, {
    "CODE": "SWE314",
    "TITLE": "Soft Computing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJTG23",
    "SLOT": "A1+TA1",
    "FACULTY": "TAPAN KUMAR DAS"
}, {
    "CODE": "SWE314",
    "TITLE": "Soft Computing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG18",
    "SLOT": "L23+L24",
    "FACULTY": "TAPAN KUMAR DAS"
}, {
    "CODE": "SWE4002",
    "TITLE": "Cloud Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT223",
    "SLOT": "C2",
    "FACULTY": "NADESH R.K"
}, {
    "CODE": "SWE4002",
    "TITLE": "Cloud Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NADESH R.K"
}, {
    "CODE": "SWE4002",
    "TITLE": "Cloud Computing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT223",
    "SLOT": "C1",
    "FACULTY": "SIVA RAMA KRISHNAN S"
}, {
    "CODE": "SWE4002",
    "TITLE": "Cloud Computing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SIVA RAMA KRISHNAN S"
}, {
    "CODE": "SWE4005",
    "TITLE": "Internet of Things",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT127",
    "SLOT": "A1",
    "FACULTY": "POUNAMBAL M"
}, {
    "CODE": "SWE4005",
    "TITLE": "Internet of Things",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "POUNAMBAL M"
}, {
    "CODE": "SWE4005",
    "TITLE": "Internet of Things",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT127",
    "SLOT": "A2",
    "FACULTY": "POUNAMBAL M"
}, {
    "CODE": "SWE4005",
    "TITLE": "Internet of Things",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "POUNAMBAL M"
}, {
    "CODE": "SWE401",
    "TITLE": "Software Architecture and Design",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG23",
    "SLOT": "B2+TB2",
    "FACULTY": "USHAPREETHI P"
}, {
    "CODE": "SWE402",
    "TITLE": "CASE Tools Lab-1",
    "TYPE": "LO",
    "CREDITS": "2",
    "VENUE": "SJTG17",
    "SLOT": "L7+L8+L9+L10",
    "FACULTY": "PRABADEVI B"
}, {
    "CODE": "SWE403",
    "TITLE": "System Programming",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG16",
    "SLOT": "G1+TG1",
    "FACULTY": "SUREKA S"
}, {
    "CODE": "SWE404",
    "TITLE": "System Programming Lab",
    "TYPE": "LO",
    "CREDITS": "2",
    "VENUE": "SJTG20",
    "SLOT": "L41+L42+L53+L54",
    "FACULTY": "SATHISH KUMAR  M"
}, {
    "CODE": "SWE406",
    "TITLE": "Software Project Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG23",
    "SLOT": "A2+TA2",
    "FACULTY": "JAYALAKSHMI P"
}, {
    "CODE": "SWE407",
    "TITLE": "Open Source Programming",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG07",
    "SLOT": "F2+TF2",
    "FACULTY": "SUMAIYA THASEEN I"
}, {
    "CODE": "SWE408",
    "TITLE": "Open Source Programming Lab",
    "TYPE": "LO",
    "CREDITS": "2",
    "VENUE": "SJTG20",
    "SLOT": "L9+L10+L23+L24",
    "FACULTY": "KAVITHA B.R"
}, {
    "CODE": "SWE409",
    "TITLE": "Web Services and Service Oriented\nArchitecture",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT211A",
    "SLOT": "A2+TA2",
    "FACULTY": "NIRMALA M"
}, {
    "CODE": "SWE410",
    "TITLE": "Web Services Lab",
    "TYPE": "LO",
    "CREDITS": "2",
    "VENUE": "SJT120",
    "SLOT": "L1+L2+L3+L4",
    "FACULTY": "MAREESWARI V"
}, {
    "CODE": "SWE415",
    "TITLE": "Biometric Systems",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT114",
    "SLOT": "C2+TC2",
    "FACULTY": "SRINIVASA PERUMAL R"
}, {
    "CODE": "SWE416",
    "TITLE": "Enterprise Resource Planning",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG07",
    "SLOT": "D2+TD2",
    "FACULTY": "PRABADEVI B"
}, {
    "CODE": "SWE428",
    "TITLE": "E-Governance",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT114",
    "SLOT": "A1+TA1",
    "FACULTY": "BRIJENDRA SINGH"
}, {
    "CODE": "SWE430",
    "TITLE": "Data Analytics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT211A",
    "SLOT": "E2+TE2",
    "FACULTY": "DURAI RAJ VINCENT P.M"
}, {
    "CODE": "SWE430",
    "TITLE": "Data Analytics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG20",
    "SLOT": "L1+L2",
    "FACULTY": "DURAI RAJ VINCENT P.M"
}, {
    "CODE": "SWE432",
    "TITLE": "Agile Software Development",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG24",
    "SLOT": "D2+TD2",
    "FACULTY": "VIJAY ANAND R"
}, {
    "CODE": "SWE497",
    "TITLE": "Mini Project (Team based)",
    "TYPE": "PJT",
    "CREDITS": "8",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "SWE502",
    "TITLE": "Principles of User Interface Design",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG24",
    "SLOT": "E1+TE1",
    "FACULTY": "JAYAKUMAR S"
}, {
    "CODE": "SWE504",
    "TITLE": "Software Quality and Reliability",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT215",
    "SLOT": "E2+TE2",
    "FACULTY": "ABRAHAM PAUL"
}, {
    "CODE": "SWE505",
    "TITLE": "Software Metrics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT223",
    "SLOT": "A2+TA2",
    "FACULTY": "RAHAMATHUNNISA U"
}, {
    "CODE": "SWE505",
    "TITLE": "Software Metrics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG24",
    "SLOT": "D1+TD1",
    "FACULTY": "NITHYA.S"
}, {
    "CODE": "SWE506",
    "TITLE": "Software Metrics Lab",
    "TYPE": "LO",
    "CREDITS": "2",
    "VENUE": "SJT122",
    "SLOT": "L13+L14+L21+L22",
    "FACULTY": "NITHYA.S"
}, {
    "CODE": "SWE506",
    "TITLE": "Software Metrics Lab",
    "TYPE": "LO",
    "CREDITS": "2",
    "VENUE": "SJTG17",
    "SLOT": "L33+L34+L41+L42",
    "FACULTY": "NITHYA.S"
}, {
    "CODE": "SWE509",
    "TITLE": "Distributed Computing",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG24",
    "SLOT": "B2+TB2",
    "FACULTY": "POUNAMBAL M"
}, {
    "CODE": "SWE511",
    "TITLE": "Information and System Security",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT118",
    "SLOT": "E1+TE1",
    "FACULTY": "JASMINE NORMAN"
}, {
    "CODE": "SWE512",
    "TITLE": "Software Engineering Process, Tools\nand Methods",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT223",
    "SLOT": "G1+TG1",
    "FACULTY": "SWETA BHATTACHARYA"
}, {
    "CODE": "SWE513",
    "TITLE": "CASE Tools Lab-2",
    "TYPE": "LO",
    "CREDITS": "2",
    "VENUE": "SJTG17",
    "SLOT": "L35+L36+L47+L48",
    "FACULTY": "SATHISH KUMAR  M"
}, {
    "CODE": "SWE513",
    "TITLE": "CASE Tools Lab-2",
    "TYPE": "LO",
    "CREDITS": "2",
    "VENUE": "SJTG17",
    "SLOT": "L3+L4+L13+L14",
    "FACULTY": "SATHISH KUMAR  M"
}, {
    "CODE": "SWE530",
    "TITLE": "Python Programming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT211",
    "SLOT": "E2+TE2",
    "FACULTY": "KURUVA LAKSHMANNA"
}, {
    "CODE": "SWE530",
    "TITLE": "Python Programming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT120",
    "SLOT": "L9+L10",
    "FACULTY": "KURUVA LAKSHMANNA"
}, {
    "CODE": "SWE531",
    "TITLE": "Advanced Software Testing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT107",
    "SLOT": "F2+TF2",
    "FACULTY": "DEEPA P"
}, {
    "CODE": "SWE531",
    "TITLE": "Advanced Software Testing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJTG17",
    "SLOT": "L23+L24",
    "FACULTY": "DEEPA P"
}, {
    "CODE": "SWE599",
    "TITLE": "Student Project",
    "TYPE": "PJT",
    "CREDITS": "24",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "MEE1002",
    "TITLE": "Engineering Mechanics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB102",
    "SLOT": "A2+TA2+V3",
    "FACULTY": "SOVAN SUNDAR DASGUPTA"
}, {
    "CODE": "MEE1002",
    "TITLE": "Engineering Mechanics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB203",
    "SLOT": "A2+TA2+V3",
    "FACULTY": "FATHIMA PATHAM K"
}, {
    "CODE": "MEE1003",
    "TITLE": "Engineering Thermodynamics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB110",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "PORPATHAM E"
}, {
    "CODE": "MEE1003",
    "TITLE": "Engineering Thermodynamics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDN120",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "SENTHILKUMAR P"
}, {
    "CODE": "MEE1003",
    "TITLE": "Engineering Thermodynamics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDN121",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "THUNDIL KARUPPA RAJ R"
}, {
    "CODE": "MEE1003",
    "TITLE": "Engineering Thermodynamics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDN123",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "SENTHIL KUMAR M"
}, {
    "CODE": "MEE1003",
    "TITLE": "Engineering Thermodynamics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB203",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "SHARU B.K."
}, {
    "CODE": "MEE1003",
    "TITLE": "Engineering Thermodynamics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB124",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "SENTHILKUMAR P"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB214",
    "SLOT": "D2+TD2+V6",
    "FACULTY": "SEKARAPANDIAN N"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB227",
    "SLOT": "D2+TD2+V6",
    "FACULTY": "MOHAMED IBRAHIM  M"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB203",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "CHINMAYA PRASAD MOHANTY"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB225",
    "SLOT": "D2+TD2+V6",
    "FACULTY": "GUNDABATTINI EDISON"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB202",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "MOHAN C.G"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN109",
    "SLOT": "D2+TD2+V6",
    "FACULTY": "MOHAN C.G"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB225",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "PADMANATHAN P"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB224",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "PRAKASH R"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB201",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "SATHEESH A"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN123",
    "SLOT": "D2+TD2+V6",
    "FACULTY": "SATHEESH A"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN128",
    "SLOT": "D2+TD2+V6",
    "FACULTY": "JAYAPRAKASH NARAYAN M"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB315",
    "SLOT": "D2+TD2+V6",
    "FACULTY": "PRAVEEN KUMAR"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L41+L42",
    "FACULTY": "CHINMAYA PRASAD MOHANTY"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L47+L48",
    "FACULTY": "CHINMAYA PRASAD MOHANTY"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L3+L4",
    "FACULTY": "PRAVEEN KUMAR"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L21+L22",
    "FACULTY": "PRAVEEN KUMAR"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L5+L6",
    "FACULTY": "MOHAMED IBRAHIM  M"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L7+L8",
    "FACULTY": "MOHAMED IBRAHIM  M"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L11+L12",
    "FACULTY": "SEKARAPANDIAN N"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L15+L16",
    "FACULTY": "SEKARAPANDIAN N"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L23+L24",
    "FACULTY": "GUNDABATTINI EDISON"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L9+L10",
    "FACULTY": "GUNDABATTINI EDISON"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L39+L40",
    "FACULTY": "MOHAN C.G"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L39+L40",
    "FACULTY": "VIGNESH M"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L53+L54",
    "FACULTY": "MOHAN C.G"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L55+L56",
    "FACULTY": "MOHAN C.G"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L29+L30",
    "FACULTY": "MOHAN C.G"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L29+L30",
    "FACULTY": "MR. SATHISHKUMAR M"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L35+L36",
    "FACULTY": "PADMANATHAN P"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L45+L46",
    "FACULTY": "PADMANATHAN P"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L59+L60",
    "FACULTY": "PRAKASH R"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L1+L2",
    "FACULTY": "SATHEESH A"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L1+L2",
    "FACULTY": "NARAYANA MOORTHY N"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L27+L28",
    "FACULTY": "SATHEESH A"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L27+L28",
    "FACULTY": "NARAYANA MOORTHY N"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L13+L14",
    "FACULTY": "SATHEESH A"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L13+L14",
    "FACULTY": "MR. SATHISHKUMAR M"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L25+L26",
    "FACULTY": "JAYAPRAKASH NARAYAN M"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L43+L44",
    "FACULTY": "JAYAPRAKASH NARAYAN M"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV105",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "CHITRA D"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L37+L38",
    "FACULTY": "CHITRA D"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L51+L52",
    "FACULTY": "CHITRA D"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV109",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "ANAND VEERABADRA PRASAD\nGURUMOORTHY"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L31+L32",
    "FACULTY": "ANAND VEERABADRA PRASAD\nGURUMOORTHY"
}, {
    "CODE": "MEE1004",
    "TITLE": "Fluid Mechanics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN131",
    "SLOT": "L57+L58",
    "FACULTY": "ANAND VEERABADRA PRASAD\nGURUMOORTHY"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN109",
    "SLOT": "B2+TB2",
    "FACULTY": "DEVENDRANATH RAMKUMAR"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN139",
    "SLOT": "L5+L6",
    "FACULTY": "DEVENDRANATH RAMKUMAR"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN139",
    "SLOT": "L11+L12",
    "FACULTY": "DEVENDRANATH RAMKUMAR"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN109",
    "SLOT": "B1+TB1",
    "FACULTY": "MUTHUCHAMY A"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN139",
    "SLOT": "L23+L24",
    "FACULTY": "MUTHUCHAMY A"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN139",
    "SLOT": "L29+L30",
    "FACULTY": "MUTHUCHAMY A"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN128",
    "SLOT": "B1+TB1",
    "FACULTY": "PADMANABHAN K"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN139",
    "SLOT": "L55+L56",
    "FACULTY": "PADMANABHAN K"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN139",
    "SLOT": "L41+L42",
    "FACULTY": "PADMANABHAN K"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN129",
    "SLOT": "B1+TB1",
    "FACULTY": "SK ARIFUL RAHAMAN"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN129",
    "SLOT": "B2+TB2",
    "FACULTY": "SK ARIFUL RAHAMAN"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN139",
    "SLOT": "L1+L2",
    "FACULTY": "SK ARIFUL RAHAMAN"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN139",
    "SLOT": "L9+L10",
    "FACULTY": "SK ARIFUL RAHAMAN"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN139",
    "SLOT": "L43+L44",
    "FACULTY": "SK ARIFUL RAHAMAN"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN139",
    "SLOT": "L47+L48",
    "FACULTY": "SK ARIFUL RAHAMAN"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB219",
    "SLOT": "B1+TB1",
    "FACULTY": "RIJESH M"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN139",
    "SLOT": "L35+L36",
    "FACULTY": "RIJESH M"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN139",
    "SLOT": "L53+L54",
    "FACULTY": "RIJESH M"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB226",
    "SLOT": "B2+TB2",
    "FACULTY": "SITARAM DASH"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN139",
    "SLOT": "L3+L4",
    "FACULTY": "SITARAM DASH"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN139",
    "SLOT": "L15+L16",
    "FACULTY": "RIJESH M"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB225",
    "SLOT": "B2+TB2",
    "FACULTY": "SREEKANTH M. S"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN139",
    "SLOT": "L7+L8",
    "FACULTY": "SREEKANTH M. S"
}, {
    "CODE": "MEE1005",
    "TITLE": "Materials Engineering and Technology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN139",
    "SLOT": "L21+L22",
    "FACULTY": "SREEKANTH M. S"
}, {
    "CODE": "MEE1006",
    "TITLE": "Applied Mechanics and Thermal\nEngineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT424",
    "SLOT": "G1",
    "FACULTY": "ASOKAN M.A"
}, {
    "CODE": "MEE1006",
    "TITLE": "Applied Mechanics and Thermal\nEngineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT424",
    "SLOT": "G2",
    "FACULTY": "ASOKAN M.A"
}, {
    "CODE": "MEE1006",
    "TITLE": "Applied Mechanics and Thermal\nEngineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG06",
    "SLOT": "L23+L24",
    "FACULTY": "ASOKAN M.A"
}, {
    "CODE": "MEE1006",
    "TITLE": "Applied Mechanics and Thermal\nEngineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG06",
    "SLOT": "L29+L30",
    "FACULTY": "ASOKAN M.A"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB218",
    "SLOT": "G2",
    "FACULTY": "KARTHIKEYAN S"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG26",
    "SLOT": "L1+L2",
    "FACULTY": "KARTHIKEYAN S"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB212",
    "SLOT": "G1",
    "FACULTY": "BABU C"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG26",
    "SLOT": "L33+L34",
    "FACULTY": "BABU C"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB227",
    "SLOT": "G2",
    "FACULTY": "CHINMAYA PRASAD MOHANTY"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG26",
    "SLOT": "L7+L8",
    "FACULTY": "CHINMAYA PRASAD MOHANTY"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB227",
    "SLOT": "G1",
    "FACULTY": "JEYAPANDIARAJAN P"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG26",
    "SLOT": "L41+L42",
    "FACULTY": "JEYAPANDIARAJAN P"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB226",
    "SLOT": "G1",
    "FACULTY": "SIVAPRASAD DARLA"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG26",
    "SLOT": "L35+L36",
    "FACULTY": "SIVAPRASAD DARLA"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB226",
    "SLOT": "G2",
    "FACULTY": "SOLAMAN BOBBY S"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB103",
    "SLOT": "G2",
    "FACULTY": "SREETHUL DAS"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG26",
    "SLOT": "L9+L10",
    "FACULTY": "SREETHUL DAS"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB111",
    "SLOT": "G1",
    "FACULTY": "SUNDARAMALI G"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG26",
    "SLOT": "L47+L48",
    "FACULTY": "SUNDARAMALI G"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDN123",
    "SLOT": "G1",
    "FACULTY": "RAJAMURUGAN G"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDN123",
    "SLOT": "G2",
    "FACULTY": "RAJAMURUGAN G"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG26",
    "SLOT": "L23+L24",
    "FACULTY": "RAJAMURUGAN G"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG26",
    "SLOT": "L49+L50",
    "FACULTY": "RAJAMURUGAN G"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB203",
    "SLOT": "G2",
    "FACULTY": "SENTHIL KUMARAN S"
}, {
    "CODE": "MEE1007",
    "TITLE": "Manufacturing Processes",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG26",
    "SLOT": "L15+L16",
    "FACULTY": "SENTHIL KUMARAN S"
}, {
    "CODE": "MEE1008",
    "TITLE": "MEMS",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB102",
    "SLOT": "G2+TG2",
    "FACULTY": "BHARANIDARAN R"
}, {
    "CODE": "MEE1008",
    "TITLE": "MEMS",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB213",
    "SLOT": "D2+TD2",
    "FACULTY": "BOOPATHI M"
}, {
    "CODE": "MEE1008",
    "TITLE": "MEMS",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB219",
    "SLOT": "G2+TG2",
    "FACULTY": "GIRIRAJ M"
}, {
    "CODE": "MEE1008",
    "TITLE": "MEMS",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB213",
    "SLOT": "F1+TF1",
    "FACULTY": "RAGHURAMAN D R S"
}, {
    "CODE": "MEE1008",
    "TITLE": "MEMS",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB202",
    "SLOT": "F1+TF1",
    "FACULTY": "SOVAN SUNDAR DASGUPTA"
}, {
    "CODE": "MEE1008",
    "TITLE": "MEMS",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB202",
    "SLOT": "D2+TD2",
    "FACULTY": "SOVAN SUNDAR DASGUPTA"
}, {
    "CODE": "MEE1009",
    "TITLE": "New Product Development",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB110",
    "SLOT": "E1",
    "FACULTY": "ARUN TOM MATHEW"
}, {
    "CODE": "MEE1009",
    "TITLE": "New Product Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ARUN TOM MATHEW"
}, {
    "CODE": "MEE1009",
    "TITLE": "New Product Development",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB110",
    "SLOT": "E2",
    "FACULTY": "ARUN TOM MATHEW"
}, {
    "CODE": "MEE1009",
    "TITLE": "New Product Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ARUN TOM MATHEW"
}, {
    "CODE": "MEE1009",
    "TITLE": "New Product Development",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB219",
    "SLOT": "E1",
    "FACULTY": "KRISHNA KISHORE K.V.S"
}, {
    "CODE": "MEE1009",
    "TITLE": "New Product Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KRISHNA KISHORE K.V.S"
}, {
    "CODE": "MEE1009",
    "TITLE": "New Product Development",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB212",
    "SLOT": "E1",
    "FACULTY": "RAMAKRISHNAN R"
}, {
    "CODE": "MEE1009",
    "TITLE": "New Product Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMAKRISHNAN R"
}, {
    "CODE": "MEE1009",
    "TITLE": "New Product Development",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB201",
    "SLOT": "F1",
    "FACULTY": "MURUGAN M"
}, {
    "CODE": "MEE1009",
    "TITLE": "New Product Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MURUGAN M"
}, {
    "CODE": "MEE1009",
    "TITLE": "New Product Development",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDN109",
    "SLOT": "E2",
    "FACULTY": "KRISHNA KISHORE K.V.S"
}, {
    "CODE": "MEE1009",
    "TITLE": "New Product Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KRISHNA KISHORE K.V.S"
}, {
    "CODE": "MEE1011",
    "TITLE": "Renewable Energy Sources",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB111",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "VIGNESH G"
}, {
    "CODE": "MEE1011",
    "TITLE": "Renewable Energy Sources",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN135",
    "SLOT": "L33+L34",
    "FACULTY": "VIGNESH G"
}, {
    "CODE": "MEE1011",
    "TITLE": "Renewable Energy Sources",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN135",
    "SLOT": "L37+L38",
    "FACULTY": "VIGNESH G"
}, {
    "CODE": "MEE1011",
    "TITLE": "Renewable Energy Sources",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN122",
    "SLOT": "A2+TA2+V3",
    "FACULTY": "ANOOP KUMAR"
}, {
    "CODE": "MEE1011",
    "TITLE": "Renewable Energy Sources",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN128",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "ANOOP KUMAR"
}, {
    "CODE": "MEE1011",
    "TITLE": "Renewable Energy Sources",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN135",
    "SLOT": "L5+L6",
    "FACULTY": "ANOOP KUMAR"
}, {
    "CODE": "MEE1011",
    "TITLE": "Renewable Energy Sources",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN135",
    "SLOT": "L9+L10",
    "FACULTY": "ANOOP KUMAR"
}, {
    "CODE": "MEE1011",
    "TITLE": "Renewable Energy Sources",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN135",
    "SLOT": "L39+L40",
    "FACULTY": "ANOOP KUMAR"
}, {
    "CODE": "MEE1011",
    "TITLE": "Renewable Energy Sources",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN135",
    "SLOT": "L49+L50",
    "FACULTY": "ANOOP KUMAR"
}, {
    "CODE": "MEE1011",
    "TITLE": "Renewable Energy Sources",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN109",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "NATARAJAN M"
}, {
    "CODE": "MEE1011",
    "TITLE": "Renewable Energy Sources",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN135",
    "SLOT": "L3+L4",
    "FACULTY": "NATARAJAN M"
}, {
    "CODE": "MEE1011",
    "TITLE": "Renewable Energy Sources",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN135",
    "SLOT": "L15+L16",
    "FACULTY": "NATARAJAN M"
}, {
    "CODE": "MEE1011",
    "TITLE": "Renewable Energy Sources",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB219",
    "SLOT": "A2+TA2+V3",
    "FACULTY": "GAURAV DWIVEDI"
}, {
    "CODE": "MEE1011",
    "TITLE": "Renewable Energy Sources",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN135",
    "SLOT": "L29+L30",
    "FACULTY": "GAURAV DWIVEDI"
}, {
    "CODE": "MEE1011",
    "TITLE": "Renewable Energy Sources",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN135",
    "SLOT": "L25+L26",
    "FACULTY": "GAURAV DWIVEDI"
}, {
    "CODE": "MEE1012",
    "TITLE": "Alternative Fuels",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB201",
    "SLOT": "A2+TA2",
    "FACULTY": "VIJAYALAKSHMI S"
}, {
    "CODE": "MEE1012",
    "TITLE": "Alternative Fuels",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB219",
    "SLOT": "D1+TD1",
    "FACULTY": "JAYAPRAKASH NARAYAN M"
}, {
    "CODE": "MEE1012",
    "TITLE": "Alternative Fuels",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB218",
    "SLOT": "B1+TB1",
    "FACULTY": "GAURAV DWIVEDI"
}, {
    "CODE": "MEE1012",
    "TITLE": "Alternative Fuels",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV104",
    "SLOT": "G2+TG2",
    "FACULTY": "SHISHIR KUMAR BEHERA"
}, {
    "CODE": "MEE1014",
    "TITLE": "Industrial Engineering and Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB213",
    "SLOT": "E2+TE2",
    "FACULTY": "BABU C"
}, {
    "CODE": "MEE1014",
    "TITLE": "Industrial Engineering and Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB315",
    "SLOT": "F2+TF2",
    "FACULTY": "JAYAKRISHNA K"
}, {
    "CODE": "MEE1014",
    "TITLE": "Industrial Engineering and Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM1\n02",
    "SLOT": "D2+TD2",
    "FACULTY": "RAJYALAKSHMI G"
}, {
    "CODE": "MEE1014",
    "TITLE": "Industrial Engineering and Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB224",
    "SLOT": "D1+TD1",
    "FACULTY": "SOUMEN PAL"
}, {
    "CODE": "MEE1014",
    "TITLE": "Industrial Engineering and Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB225",
    "SLOT": "D1+TD1",
    "FACULTY": "SRINIVASA GUPTA N"
}, {
    "CODE": "MEE1014",
    "TITLE": "Industrial Engineering and Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB102",
    "SLOT": "C2+TC2",
    "FACULTY": "SRINIVASA GUPTA N"
}, {
    "CODE": "MEE1014",
    "TITLE": "Industrial Engineering and Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMVG11",
    "SLOT": "F2+TF2",
    "FACULTY": "NAGAMALLESWARA RAO K"
}, {
    "CODE": "MEE1015",
    "TITLE": "Total Quality Management and\nReliability",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB219",
    "SLOT": "E2+TE2",
    "FACULTY": "JAYAKRISHNA K"
}, {
    "CODE": "MEE1015",
    "TITLE": "Total Quality Management and\nReliability",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB211",
    "SLOT": "E1+TE1",
    "FACULTY": "JOHN RAJAN A"
}, {
    "CODE": "MEE1015",
    "TITLE": "Total Quality Management and\nReliability",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDN109",
    "SLOT": "C1+TC1",
    "FACULTY": "JEEVANANTHAM A.K."
}, {
    "CODE": "MEE1015",
    "TITLE": "Total Quality Management and\nReliability",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB203",
    "SLOT": "G1+TG1",
    "FACULTY": "SENTHIL KUMARAN S"
}, {
    "CODE": "MEE1015",
    "TITLE": "Total Quality Management and\nReliability",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB203",
    "SLOT": "F2+TF2",
    "FACULTY": "SENTHIL KUMARAN S"
}, {
    "CODE": "MEE1015",
    "TITLE": "Total Quality Management and\nReliability",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDN128",
    "SLOT": "E1+TE1",
    "FACULTY": "SRINIVASAN NARAYANAN"
}, {
    "CODE": "MEE1015",
    "TITLE": "Total Quality Management and\nReliability",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDN128",
    "SLOT": "E2+TE2",
    "FACULTY": "SRINIVASAN NARAYANAN"
}, {
    "CODE": "MEE1015",
    "TITLE": "Total Quality Management and\nReliability",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB225",
    "SLOT": "E1+TE1",
    "FACULTY": "VIMAL K E K"
}, {
    "CODE": "MEE1015",
    "TITLE": "Total Quality Management and\nReliability",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB111",
    "SLOT": "F2+TF2",
    "FACULTY": "VIMAL K E K"
}, {
    "CODE": "MEE1016",
    "TITLE": "Lean Enterprises and New\nManufacturing Technology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB225",
    "SLOT": "A2+TA2",
    "FACULTY": "ARAVIND RAJ S"
}, {
    "CODE": "MEE1016",
    "TITLE": "Lean Enterprises and New\nManufacturing Technology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDN121",
    "SLOT": "A1+TA1",
    "FACULTY": "VEZHAVENDHAN R"
}, {
    "CODE": "MEE1017",
    "TITLE": "New Venture Planning and\nManagement",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDN121",
    "SLOT": "A2",
    "FACULTY": "VEZHAVENDHAN R"
}, {
    "CODE": "MEE1017",
    "TITLE": "New Venture Planning and\nManagement",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VEZHAVENDHAN R"
}, {
    "CODE": "MEE1018",
    "TITLE": "Facilities and Process Planning",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB219",
    "SLOT": "F1+TF1",
    "FACULTY": "JAYAKRISHNA K"
}, {
    "CODE": "MEE1018",
    "TITLE": "Facilities and Process Planning",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB218",
    "SLOT": "C2+TC2",
    "FACULTY": "SAMPATH KUMAR T"
}, {
    "CODE": "MEE1024",
    "TITLE": "Operations Research",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB111",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "JOHN RAJAN A"
}, {
    "CODE": "MEE1024",
    "TITLE": "Operations Research",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB111",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "JOHN RAJAN A"
}, {
    "CODE": "MEE1024",
    "TITLE": "Operations Research",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB226",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "NARAYANAN S."
}, {
    "CODE": "MEE1024",
    "TITLE": "Operations Research",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB225",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "JEEVA P.A"
}, {
    "CODE": "MEE1024",
    "TITLE": "Operations Research",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM1\n02",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "SOUMEN PAL"
}, {
    "CODE": "MEE1024",
    "TITLE": "Operations Research",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDN121",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "VIMAL K E K"
}, {
    "CODE": "MEE1027",
    "TITLE": "Instrumentation and Control\nEngineering",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB226",
    "SLOT": "A2+TA2",
    "FACULTY": "DENIS ASHOK S"
}, {
    "CODE": "MEE1027",
    "TITLE": "Instrumentation and Control\nEngineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN138",
    "SLOT": "L47+L48",
    "FACULTY": "DENIS ASHOK S"
}, {
    "CODE": "MEE1027",
    "TITLE": "Instrumentation and Control\nEngineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN138",
    "SLOT": "L59+L60",
    "FACULTY": "DENIS ASHOK S"
}, {
    "CODE": "MEE1027",
    "TITLE": "Instrumentation and Control\nEngineering",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB110",
    "SLOT": "F2+TF2",
    "FACULTY": "RAGHURAMAN D R S"
}, {
    "CODE": "MEE1027",
    "TITLE": "Instrumentation and Control\nEngineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN138",
    "SLOT": "L23+L24",
    "FACULTY": "RAGHURAMAN D R S"
}, {
    "CODE": "MEE1027",
    "TITLE": "Instrumentation and Control\nEngineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN138",
    "SLOT": "L11+L12",
    "FACULTY": "RAGHURAMAN D R S"
}, {
    "CODE": "MEE1030",
    "TITLE": "Robotics",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB218",
    "SLOT": "F2",
    "FACULTY": "RAJAY VEDARAJ  I.S"
}, {
    "CODE": "MEE1030",
    "TITLE": "Robotics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN152",
    "SLOT": "L23+L24",
    "FACULTY": "RAJAY VEDARAJ  I.S"
}, {
    "CODE": "MEE1030",
    "TITLE": "Robotics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN152",
    "SLOT": "L29+L30",
    "FACULTY": "RAJAY VEDARAJ  I.S"
}, {
    "CODE": "MEE1030",
    "TITLE": "Robotics",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB110",
    "SLOT": "G2",
    "FACULTY": "RAMAKRISHNAN R"
}, {
    "CODE": "MEE1030",
    "TITLE": "Robotics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN152",
    "SLOT": "L5+L6",
    "FACULTY": "RAMAKRISHNAN R"
}, {
    "CODE": "MEE1030",
    "TITLE": "Robotics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN152",
    "SLOT": "L11+L12",
    "FACULTY": "RAMAKRISHNAN R"
}, {
    "CODE": "MEE1030",
    "TITLE": "Robotics",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB213",
    "SLOT": "G1",
    "FACULTY": "RAJAY VEDARAJ  I.S"
}, {
    "CODE": "MEE1030",
    "TITLE": "Robotics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN152",
    "SLOT": "L35+L36",
    "FACULTY": "RAJAY VEDARAJ  I.S"
}, {
    "CODE": "MEE1030",
    "TITLE": "Robotics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN152",
    "SLOT": "L41+L42",
    "FACULTY": "RAJAY VEDARAJ  I.S"
}, {
    "CODE": "MEE1032",
    "TITLE": "Mechanics of Solids and Fluids",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB110",
    "SLOT": "F1+TF1",
    "FACULTY": "DEEPA A"
}, {
    "CODE": "MEE1032",
    "TITLE": "Mechanics of Solids and Fluids",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB124",
    "SLOT": "F2+TF2",
    "FACULTY": "NITHIN BATTULA"
}, {
    "CODE": "MEE1032",
    "TITLE": "Mechanics of Solids and Fluids",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB224",
    "SLOT": "B1+TB1",
    "FACULTY": "SREEJA SADASIVAN"
}, {
    "CODE": "MEE1032",
    "TITLE": "Mechanics of Solids and Fluids",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB202",
    "SLOT": "F2+TF2",
    "FACULTY": "SREEJA SADASIVAN"
}, {
    "CODE": "MEE1032",
    "TITLE": "Mechanics of Solids and Fluids",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L43+L44",
    "FACULTY": "DEEPA A"
}, {
    "CODE": "MEE1032",
    "TITLE": "Mechanics of Solids and Fluids",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L7+L8",
    "FACULTY": "NITHIN BATTULA"
}, {
    "CODE": "MEE1032",
    "TITLE": "Mechanics of Solids and Fluids",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L33+L34",
    "FACULTY": "SREEJA SADASIVAN"
}, {
    "CODE": "MEE1032",
    "TITLE": "Mechanics of Solids and Fluids",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG06",
    "SLOT": "L11+L12",
    "FACULTY": "SREEJA SADASIVAN"
}, {
    "CODE": "MEE1033",
    "TITLE": "Thermodynamics and Heat Transfer",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN128",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "TAPANO KUMAR HOTTA"
}, {
    "CODE": "MEE1033",
    "TITLE": "Thermodynamics and Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L47+L48",
    "FACULTY": "TAPANO KUMAR HOTTA"
}, {
    "CODE": "MEE1033",
    "TITLE": "Thermodynamics and Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L31+L32",
    "FACULTY": "TAPANO KUMAR HOTTA"
}, {
    "CODE": "MEE1034",
    "TITLE": "Statistical Quality Control",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB227",
    "SLOT": "B1",
    "FACULTY": "JEEVANANTHAM A.K."
}, {
    "CODE": "MEE1034",
    "TITLE": "Statistical Quality Control",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JEEVANANTHAM A.K."
}, {
    "CODE": "MEE1035",
    "TITLE": "Automotive Electricals",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB201",
    "SLOT": "E1+TE1",
    "FACULTY": "ASHOK B"
}, {
    "CODE": "MEE1036",
    "TITLE": "Automotive Chassis",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN109",
    "SLOT": "D1+TD1",
    "FACULTY": "KANNAN C"
}, {
    "CODE": "MEE1036",
    "TITLE": "Automotive Chassis",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L23+L24",
    "FACULTY": "KANNAN C"
}, {
    "CODE": "MEE1036",
    "TITLE": "Automotive Chassis",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L33+L34",
    "FACULTY": "KANNAN C"
}, {
    "CODE": "MEE1036",
    "TITLE": "Automotive Chassis",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN123",
    "SLOT": "F2+TF2",
    "FACULTY": "PRABU K"
}, {
    "CODE": "MEE1036",
    "TITLE": "Automotive Chassis",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L29+L30",
    "FACULTY": "PRABU K"
}, {
    "CODE": "MEE1036",
    "TITLE": "Automotive Chassis",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L15+L16",
    "FACULTY": "PRABU K"
}, {
    "CODE": "MEE1037",
    "TITLE": "Automotive Electronics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN121",
    "SLOT": "F2+TF2",
    "FACULTY": "KRISHNA S"
}, {
    "CODE": "MEE1037",
    "TITLE": "Automotive Electronics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KRISHNA S"
}, {
    "CODE": "MEE1038",
    "TITLE": "Solar Photovoltaic System Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB212",
    "SLOT": "E2",
    "FACULTY": "RAJA SEKHAR Y"
}, {
    "CODE": "MEE1038",
    "TITLE": "Solar Photovoltaic System Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJA SEKHAR Y"
}, {
    "CODE": "MEE1067",
    "TITLE": "Wind Energy Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDN123",
    "SLOT": "E1",
    "FACULTY": "VIGNESH G"
}, {
    "CODE": "MEE1067",
    "TITLE": "Wind Energy Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIGNESH G"
}, {
    "CODE": "MEE1067",
    "TITLE": "Wind Energy Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDN123",
    "SLOT": "E2",
    "FACULTY": "VIGNESH G"
}, {
    "CODE": "MEE1067",
    "TITLE": "Wind Energy Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIGNESH G"
}, {
    "CODE": "MEE1074",
    "TITLE": "Energy, Environment and Impact\nAssessment",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDN129",
    "SLOT": "C2",
    "FACULTY": "SATYAJIT GHOSH"
}, {
    "CODE": "MEE1074",
    "TITLE": "Energy, Environment and Impact\nAssessment",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SATYAJIT GHOSH"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB203",
    "SLOT": "B2+TB2+V4",
    "FACULTY": "AKASH MOHANTY"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB203",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "AKASH MOHANTY"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB219",
    "SLOT": "D2+TD2+V6",
    "FACULTY": "GANAPATHI M"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB124",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "RAJESH M"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB224",
    "SLOT": "B2+TB2+V4",
    "FACULTY": "RAJESH M"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB224",
    "SLOT": "D2+TD2+V6",
    "FACULTY": "SENTHILNATHAN N"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB202",
    "SLOT": "B2+TB2+V4",
    "FACULTY": "SHARAN CHANDRAN M"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB202",
    "SLOT": "A2+TA2+V3",
    "FACULTY": "SUGAVANESWARAN M"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB315",
    "SLOT": "A2+TA2+V3",
    "FACULTY": "MANOHARAN R"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT801",
    "SLOT": "A2+TA2+V3",
    "FACULTY": "ANANDAVEL K"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN128",
    "SLOT": "B2+TB2+V4",
    "FACULTY": "ANANDAVEL K"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L3+L4",
    "FACULTY": "AKASH MOHANTY"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L3+L4",
    "FACULTY": "SUDHAGARA RAJAN S"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L31+L32",
    "FACULTY": "AKASH MOHANTY"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L21+L22",
    "FACULTY": "GANAPATHI M"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L9+L10",
    "FACULTY": "RAJESH M"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L23+L24",
    "FACULTY": "RAJESH M"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L23+L24",
    "FACULTY": "SUDHAGARA RAJAN S"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L19+L20",
    "FACULTY": "SENTHILNATHAN N"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L27+L28",
    "FACULTY": "SHARAN CHANDRAN M"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L5+L6",
    "FACULTY": "SUGAVANESWARAN M"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG06",
    "SLOT": "L15+L16",
    "FACULTY": "MANOHARAN R"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L45+L46",
    "FACULTY": "ANANDAVEL K"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L11+L12",
    "FACULTY": "ANANDAVEL K"
}, {
    "CODE": "MEE2002",
    "TITLE": "Strength of Materials",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10\nA",
    "SLOT": "L11+L12",
    "FACULTY": "VIGNESH M"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB219",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "BIBHUTI BHUSAN SAHOO"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB219",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "BIBHUTI BHUSAN SAHOO"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG11",
    "SLOT": "L3+L4",
    "FACULTY": "BIBHUTI BHUSAN SAHOO"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG11",
    "SLOT": "L33+L34",
    "FACULTY": "BIBHUTI BHUSAN SAHOO"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG11",
    "SLOT": "L15+L16",
    "FACULTY": "BIBHUTI BHUSAN SAHOO"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG11",
    "SLOT": "L45+L46",
    "FACULTY": "BIBHUTI BHUSAN SAHOO"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB214",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "GOVINDHA RASU N"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG11",
    "SLOT": "L5+L6",
    "FACULTY": "GOVINDHA RASU N"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG11",
    "SLOT": "L13+L14",
    "FACULTY": "GOVINDHA RASU N"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN122",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "NANTHA GOPAL K"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L31+L32",
    "FACULTY": "NANTHA GOPAL K"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L37+L38",
    "FACULTY": "NANTHA GOPAL K"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN123",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "SENTHIL KUMAR M"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L21+L22",
    "FACULTY": "SENTHIL KUMAR M"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L27+L28",
    "FACULTY": "SENTHIL KUMAR M"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN129",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "BIBIN JOHN"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG11",
    "SLOT": "L37+L38",
    "FACULTY": "BIBIN JOHN"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG11",
    "SLOT": "L43+L44",
    "FACULTY": "BIBIN JOHN"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB226",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "IMMANUEL SELWYN RAJ A"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB226",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "IMMANUEL SELWYN RAJ A"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L7+L8",
    "FACULTY": "IMMANUEL SELWYN RAJ A"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L35+L36",
    "FACULTY": "IMMANUEL SELWYN RAJ A"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L57+L58",
    "FACULTY": "IMMANUEL SELWYN RAJ A"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG11",
    "SLOT": "L47+L48",
    "FACULTY": "IMMANUEL SELWYN RAJ A"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB224",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "PRAKASH R"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG11",
    "SLOT": "L19+L20",
    "FACULTY": "PRAKASH R"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG11",
    "SLOT": "L27+L28",
    "FACULTY": "PRAKASH R"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB201",
    "SLOT": "C1+TC1+TCC1",
    "FACULTY": "SABOOR S"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG11",
    "SLOT": "L35+L36",
    "FACULTY": "SABOOR S"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L45+L46",
    "FACULTY": "SABOOR S"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n01",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "PONNUSAMY P"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n02",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "VINOD KUMAR SHARMA"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L39+L40",
    "FACULTY": "VINOD KUMAR SHARMA"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L55+L56",
    "FACULTY": "VINOD KUMAR SHARMA"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L19+L20",
    "FACULTY": "PONNUSAMY P"
}, {
    "CODE": "MEE2003",
    "TITLE": "Thermal Engineering Systems",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L47+L48",
    "FACULTY": "PONNUSAMY P"
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB110",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "ANIL P.M."
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25",
    "SLOT": "L33+L34",
    "FACULTY": "ANIL P.M."
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25",
    "SLOT": "L41+L42",
    "FACULTY": "ANIL P.M."
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB102",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "DARIUS GNANARAJ S"
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25",
    "SLOT": "L31+L32",
    "FACULTY": "DARIUS GNANARAJ S"
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25",
    "SLOT": "L43+L44",
    "FACULTY": "DARIUS GNANARAJ S"
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB227",
    "SLOT": "B2+TB2+V4",
    "FACULTY": "KHALID HUSSAIN SYED"
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25",
    "SLOT": "L9+L10",
    "FACULTY": "KHALID HUSSAIN SYED"
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25",
    "SLOT": "L21+L22",
    "FACULTY": "KHALID HUSSAIN SYED"
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB224",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "MANIKANDAN M"
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB224",
    "SLOT": "A2+TA2+V3",
    "FACULTY": "MANIKANDAN M"
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25",
    "SLOT": "L3+L4",
    "FACULTY": "MANIKANDAN M"
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25",
    "SLOT": "L35+L36",
    "FACULTY": "MANIKANDAN M"
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25",
    "SLOT": "L23+L24",
    "FACULTY": "MANIKANDAN M"
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25",
    "SLOT": "L53+L54",
    "FACULTY": "MANIKANDAN M"
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB124",
    "SLOT": "A2+TA2+V3",
    "FACULTY": "KRISHNA KISHORE K.V.S"
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25",
    "SLOT": "L5+L6",
    "FACULTY": "KRISHNA KISHORE K.V.S"
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25",
    "SLOT": "L11+L12",
    "FACULTY": "KRISHNA KISHORE K.V.S"
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB315",
    "SLOT": "B2+TB2+V4",
    "FACULTY": "RENOLD ELSEN S"
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25",
    "SLOT": "L27+L28",
    "FACULTY": "RENOLD ELSEN S"
}, {
    "CODE": "MEE2004",
    "TITLE": "Mechanics of Machines",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN152",
    "SLOT": "L13+L14",
    "FACULTY": "RENOLD ELSEN S"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN109",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "AHANKARI SANDEEP\nSURESHRAO"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN109",
    "SLOT": "A2+TA2+V3",
    "FACULTY": "AHANKARI SANDEEP\nSURESHRAO"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN128",
    "SLOT": "A2+TA2+V3",
    "FACULTY": "DEVENDRA KUMAR"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB102",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "DEVENDRA KUMAR"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB103",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "KAMATCHI R"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN120",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "VIJESH V JOSHI"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN120",
    "SLOT": "A2+TA2+V3",
    "FACULTY": "RAJU ABRAHAM"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB202",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "SENTHUR PRABU S"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN128",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "TAPANO KUMAR HOTTA"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM3\n02",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "PRAVEEN KUMAR"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV102",
    "SLOT": "A2+TA2+V3",
    "FACULTY": "VIJESH V JOSHI"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L43+L44",
    "FACULTY": "PRAVEEN KUMAR"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L55+L56",
    "FACULTY": "PRAVEEN KUMAR"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L3+L4",
    "FACULTY": "AHANKARI SANDEEP\nSURESHRAO"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L33+L34",
    "FACULTY": "AHANKARI SANDEEP\nSURESHRAO"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L29+L30",
    "FACULTY": "AHANKARI SANDEEP\nSURESHRAO"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L59+L60",
    "FACULTY": "AHANKARI SANDEEP\nSURESHRAO"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L7+L8",
    "FACULTY": "VIJESH V JOSHI"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L11+L12",
    "FACULTY": "VIJESH V JOSHI"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L37+L38",
    "FACULTY": "VIJESH V JOSHI"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L41+L42",
    "FACULTY": "VIJESH V JOSHI"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L5+L6",
    "FACULTY": "DEVENDRA KUMAR"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L15+L16",
    "FACULTY": "DEVENDRA KUMAR"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L45+L46",
    "FACULTY": "DEVENDRA KUMAR"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L39+L40",
    "FACULTY": "DEVENDRA KUMAR"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L19+L20",
    "FACULTY": "KAMATCHI R"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L27+L28",
    "FACULTY": "KAMATCHI R"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L9+L10",
    "FACULTY": "RAJU ABRAHAM"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L21+L22",
    "FACULTY": "RAJU ABRAHAM"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L13+L14",
    "FACULTY": "SENTHUR PRABU S"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L25+L26",
    "FACULTY": "SENTHUR PRABU S"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L1+L2",
    "FACULTY": "TAPANO KUMAR HOTTA"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L35+L36",
    "FACULTY": "TAPANO KUMAR HOTTA"
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB226",
    "SLOT": "D2+TD2+V6",
    "FACULTY": "SHARU B.K."
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L23+L24",
    "FACULTY": "SHARU B.K."
}, {
    "CODE": "MEE2005",
    "TITLE": "Heat Transfer",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SMVG26",
    "SLOT": "L53+L54",
    "FACULTY": "SHARU B.K."
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB218",
    "SLOT": "G1",
    "FACULTY": "BALAN A.S.S"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG16",
    "SLOT": "L33+L34",
    "FACULTY": "BALAN A.S.S"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG16",
    "SLOT": "L43+L44",
    "FACULTY": "BALAN A.S.S"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB103",
    "SLOT": "G1",
    "FACULTY": "KANISH T.C"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG16",
    "SLOT": "L35+L36",
    "FACULTY": "KANISH T.C"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG16",
    "SLOT": "L45+L46",
    "FACULTY": "KANISH T.C"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB315",
    "SLOT": "G2",
    "FACULTY": "JEYAPANDIARAJAN P"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG16",
    "SLOT": "L3+L4",
    "FACULTY": "JEYAPANDIARAJAN P"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG16",
    "SLOT": "L15+L16",
    "FACULTY": "JEYAPANDIARAJAN P"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB214",
    "SLOT": "G2",
    "FACULTY": "JOEL J"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB315",
    "SLOT": "G1",
    "FACULTY": "JOEL J"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG16",
    "SLOT": "L9+L10",
    "FACULTY": "JOEL J"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG16",
    "SLOT": "L39+L40",
    "FACULTY": "JOEL J"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG16",
    "SLOT": "L23+L24",
    "FACULTY": "JOEL J"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG16",
    "SLOT": "L53+L54",
    "FACULTY": "JOEL J"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB201",
    "SLOT": "G2",
    "FACULTY": "MURALIDHARAN B"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG16",
    "SLOT": "L21+L22",
    "FACULTY": "MURALIDHARAN B"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG16",
    "SLOT": "L1+L2",
    "FACULTY": "MURALIDHARAN B"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDN129",
    "SLOT": "G2",
    "FACULTY": "OYYARAVELU R"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG16",
    "SLOT": "L11+L12",
    "FACULTY": "OYYARAVELU R"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG16",
    "SLOT": "L29+L30",
    "FACULTY": "OYYARAVELU R"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDN109",
    "SLOT": "G1",
    "FACULTY": "PANDIVELAN C"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG16",
    "SLOT": "L31+L32",
    "FACULTY": "PANDIVELAN C"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG14",
    "SLOT": "L41+L42",
    "FACULTY": "PANDIVELAN C"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDN121",
    "SLOT": "G1",
    "FACULTY": "VENKATESHWARLU B"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDN121",
    "SLOT": "G2",
    "FACULTY": "VENKATESHWARLU B"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG16",
    "SLOT": "L27+L28",
    "FACULTY": "VENKATESHWARLU B"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG16",
    "SLOT": "L5+L6",
    "FACULTY": "VENKATESHWARLU B"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG16",
    "SLOT": "L49+L50",
    "FACULTY": "VENKATESHWARLU B"
}, {
    "CODE": "MEE2006",
    "TITLE": "Machining Processes and Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG16",
    "SLOT": "L57+L58",
    "FACULTY": "VENKATESHWARLU B"
}, {
    "CODE": "MEE2007",
    "TITLE": "CAD/CAM",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB110",
    "SLOT": "G1",
    "FACULTY": "OYYARAVELU R"
}, {
    "CODE": "MEE2007",
    "TITLE": "CAD/CAM",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "GDN130",
    "SLOT": "L53+L54+L55+L56",
    "FACULTY": "OYYARAVELU R"
}, {
    "CODE": "MEE2007",
    "TITLE": "CAD/CAM",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "GDN130",
    "SLOT": "L53+L54+L55+L56",
    "FACULTY": "VIGNESH M"
}, {
    "CODE": "MEE2007",
    "TITLE": "CAD/CAM",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB202",
    "SLOT": "G1",
    "FACULTY": "VENKATESAN S"
}, {
    "CODE": "MEE2007",
    "TITLE": "CAD/CAM",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "MB114",
    "SLOT": "L53+L54+L55+L56",
    "FACULTY": "VENKATESAN S"
}, {
    "CODE": "MEE2007",
    "TITLE": "CAD/CAM",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "MB114",
    "SLOT": "L53+L54+L55+L56",
    "FACULTY": "MR. SATHISHKUMAR M"
}, {
    "CODE": "MEE2008",
    "TITLE": "Product Design for Manufacturing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB211",
    "SLOT": "D2",
    "FACULTY": "DARIUS GNANARAJ S"
}, {
    "CODE": "MEE2008",
    "TITLE": "Product Design for Manufacturing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DARIUS GNANARAJ S"
}, {
    "CODE": "MEE2009",
    "TITLE": "Tribology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB227",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "NIRANJANA BEHERA"
}, {
    "CODE": "MEE2009",
    "TITLE": "Tribology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT801",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "ANANDAVEL K"
}, {
    "CODE": "MEE2010",
    "TITLE": "Design of Composite Materials",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB201",
    "SLOT": "B2+TB2+V4",
    "FACULTY": "DEEPA A"
}, {
    "CODE": "MEE2010",
    "TITLE": "Design of Composite Materials",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB218",
    "SLOT": "D2+TD2+V6",
    "FACULTY": "RAHUL SINGH SIKARWAR"
}, {
    "CODE": "MEE2011",
    "TITLE": "Welding Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDN109",
    "SLOT": "F1",
    "FACULTY": "MUTHUCHAMY A"
}, {
    "CODE": "MEE2011",
    "TITLE": "Welding Engineering",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MUTHUCHAMY A"
}, {
    "CODE": "MEE2012",
    "TITLE": "Manufacturing Automation",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB219",
    "SLOT": "G1+TG1",
    "FACULTY": "BOOPATHI M"
}, {
    "CODE": "MEE2012",
    "TITLE": "Manufacturing Automation",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN137",
    "SLOT": "L11+L12",
    "FACULTY": "BOOPATHI M"
}, {
    "CODE": "MEE2012",
    "TITLE": "Manufacturing Automation",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN137",
    "SLOT": "L59+L60",
    "FACULTY": "BOOPATHI M"
}, {
    "CODE": "MEE2013",
    "TITLE": "Modelling and Simulation of\nManufacturing Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB218",
    "SLOT": "E2+TE2",
    "FACULTY": "DEGA NAGARAJU"
}, {
    "CODE": "MEE2013",
    "TITLE": "Modelling and Simulation of\nManufacturing Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DEGA NAGARAJU"
}, {
    "CODE": "MEE2014",
    "TITLE": "Metal Casting Technology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB212",
    "SLOT": "F1",
    "FACULTY": "BABU C"
}, {
    "CODE": "MEE2014",
    "TITLE": "Metal Casting Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BABU C"
}, {
    "CODE": "MEE2014",
    "TITLE": "Metal Casting Technology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM1\n01",
    "SLOT": "F2",
    "FACULTY": "RIJESH M"
}, {
    "CODE": "MEE2014",
    "TITLE": "Metal Casting Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RIJESH M"
}, {
    "CODE": "MEE2014",
    "TITLE": "Metal Casting Technology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB226",
    "SLOT": "F1",
    "FACULTY": "SOLAMAN BOBBY S"
}, {
    "CODE": "MEE2014",
    "TITLE": "Metal Casting Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SOLAMAN BOBBY S"
}, {
    "CODE": "MEE2014",
    "TITLE": "Metal Casting Technology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM1\n02",
    "SLOT": "E1",
    "FACULTY": "SREEKANTH M. S"
}, {
    "CODE": "MEE2014",
    "TITLE": "Metal Casting Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SREEKANTH M. S"
}, {
    "CODE": "MEE2014",
    "TITLE": "Metal Casting Technology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDN128",
    "SLOT": "F2",
    "FACULTY": "SRINIVASAN NARAYANAN"
}, {
    "CODE": "MEE2014",
    "TITLE": "Metal Casting Technology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SRINIVASAN NARAYANAN"
}, {
    "CODE": "MEE2015",
    "TITLE": "Non Destructive Testing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB102",
    "SLOT": "G1+TG1",
    "FACULTY": "DEVENDIRAN S"
}, {
    "CODE": "MEE2015",
    "TITLE": "Non Destructive Testing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG06\nA",
    "SLOT": "L41+L42",
    "FACULTY": "DEVENDIRAN S"
}, {
    "CODE": "MEE2015",
    "TITLE": "Non Destructive Testing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG06\nA",
    "SLOT": "L53+L54",
    "FACULTY": "DEVENDIRAN S"
}, {
    "CODE": "MEE2016",
    "TITLE": "Rapid Manufacturing Technologies",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB213",
    "SLOT": "D1",
    "FACULTY": "SUGAVANESWARAN M"
}, {
    "CODE": "MEE2016",
    "TITLE": "Rapid Manufacturing Technologies",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUGAVANESWARAN M"
}, {
    "CODE": "MEE2016",
    "TITLE": "Rapid Manufacturing Technologies",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB203",
    "SLOT": "D2",
    "FACULTY": "SUGAVANESWARAN M"
}, {
    "CODE": "MEE2016",
    "TITLE": "Rapid Manufacturing Technologies",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUGAVANESWARAN M"
}, {
    "CODE": "MEE2016",
    "TITLE": "Rapid Manufacturing Technologies",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB202",
    "SLOT": "D1",
    "FACULTY": "FATHIMA PATHAM K"
}, {
    "CODE": "MEE2016",
    "TITLE": "Rapid Manufacturing Technologies",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "FATHIMA PATHAM K"
}, {
    "CODE": "MEE2016",
    "TITLE": "Rapid Manufacturing Technologies",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB226",
    "SLOT": "F2",
    "FACULTY": "SOLAMAN BOBBY S"
}, {
    "CODE": "MEE2016",
    "TITLE": "Rapid Manufacturing Technologies",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SOLAMAN BOBBY S"
}, {
    "CODE": "MEE2016",
    "TITLE": "Rapid Manufacturing Technologies",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDN109",
    "SLOT": "E1",
    "FACULTY": "FATHIMA PATHAM K"
}, {
    "CODE": "MEE2016",
    "TITLE": "Rapid Manufacturing Technologies",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "FATHIMA PATHAM K"
}, {
    "CODE": "MEE2020",
    "TITLE": "Metal Forming Theory and Practice",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDN120",
    "SLOT": "G2+TG2",
    "FACULTY": "PANDIVELAN C"
}, {
    "CODE": "MEE2022",
    "TITLE": "Power Plant Engineering",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB202",
    "SLOT": "E1+TE1",
    "FACULTY": "CHIRANJEEVI C"
}, {
    "CODE": "MEE2026",
    "TITLE": "Turbo Machines",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB219",
    "SLOT": "B2+TB2+V4",
    "FACULTY": "YAGNA S MUKKAMALA"
}, {
    "CODE": "MEE2026",
    "TITLE": "Turbo Machines",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN123",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "NITHIN BATTULA"
}, {
    "CODE": "MEE2026",
    "TITLE": "Turbo Machines",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10",
    "SLOT": "L11+L12",
    "FACULTY": "NITHIN BATTULA"
}, {
    "CODE": "MEE2026",
    "TITLE": "Turbo Machines",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG10",
    "SLOT": "L23+L24",
    "FACULTY": "YAGNA S MUKKAMALA"
}, {
    "CODE": "MEE2027",
    "TITLE": "Nuclear Power Engineering",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB203",
    "SLOT": "D1+TD1",
    "FACULTY": "GOVINDHA RASU N"
}, {
    "CODE": "MEE2027",
    "TITLE": "Nuclear Power Engineering",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB213",
    "SLOT": "A1+TA1",
    "FACULTY": "GUNDABATTINI EDISON"
}, {
    "CODE": "MEE2028",
    "TITLE": "Automotive Aerodynamics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB124",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "YAGNA S MUKKAMALA"
}, {
    "CODE": "MEE2028",
    "TITLE": "Automotive Aerodynamics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "YAGNA S MUKKAMALA"
}, {
    "CODE": "MEE2029",
    "TITLE": "Energy Conservation, Audit and\nManagement",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB124",
    "SLOT": "F1",
    "FACULTY": "CHIRANJEEVI C"
}, {
    "CODE": "MEE2029",
    "TITLE": "Energy Conservation, Audit and\nManagement",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "CHIRANJEEVI C"
}, {
    "CODE": "MEE2030",
    "TITLE": "Energy Systems Analysis and Design",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDN128",
    "SLOT": "D1+TD1",
    "FACULTY": "RAJU ABRAHAM"
}, {
    "CODE": "MEE2031",
    "TITLE": "Theory of Metal Cutting and Forming",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN128",
    "SLOT": "F1+TF1",
    "FACULTY": "RAJA ANNAMALAI"
}, {
    "CODE": "MEE2031",
    "TITLE": "Theory of Metal Cutting and Forming",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDNG26",
    "SLOT": "L11+L12",
    "FACULTY": "RAJA ANNAMALAI"
}, {
    "CODE": "MEE2032",
    "TITLE": "Kinematics and Dynamics of Machinery",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB103",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "DEVENDIRAN S"
}, {
    "CODE": "MEE2033",
    "TITLE": "Production Planning and Control",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB124",
    "SLOT": "G1+TG1",
    "FACULTY": "ARAVIND RAJ S"
}, {
    "CODE": "MEE2033",
    "TITLE": "Production Planning and Control",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM1\n01",
    "SLOT": "F1+TF1",
    "FACULTY": "SAMPATH KUMAR T"
}, {
    "CODE": "MEE2033",
    "TITLE": "Production Planning and Control",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "CDMM1\n02",
    "SLOT": "F2+TF2",
    "FACULTY": "SAMPATH KUMAR T"
}, {
    "CODE": "MEE2034",
    "TITLE": "Industrial Economics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDN122",
    "SLOT": "F2+TF2",
    "FACULTY": "RAMANUJAM R"
}, {
    "CODE": "MEE2035",
    "TITLE": "Logistics and Supply Chain Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB102",
    "SLOT": "F2+TF2",
    "FACULTY": "THIAGARAJAN S"
}, {
    "CODE": "MEE2035",
    "TITLE": "Logistics and Supply Chain Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB102",
    "SLOT": "F1+TF1",
    "FACULTY": "THIAGARAJAN S"
}, {
    "CODE": "MEE2035",
    "TITLE": "Logistics and Supply Chain Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB225",
    "SLOT": "F2+TF2",
    "FACULTY": "SIVAPRASAD DARLA"
}, {
    "CODE": "MEE2036",
    "TITLE": "Industrial Corrosion and Tribology",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB201",
    "SLOT": "B1+TB1",
    "FACULTY": "GEETHA MANIVASAGAM"
}, {
    "CODE": "MEE2036",
    "TITLE": "Industrial Corrosion and Tribology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GEETHA MANIVASAGAM"
}, {
    "CODE": "MEE2037",
    "TITLE": "Agile Manufacturing",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB202",
    "SLOT": "A1+TA1",
    "FACULTY": "ARAVIND RAJ S"
}, {
    "CODE": "MEE2037",
    "TITLE": "Agile Manufacturing",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDN122",
    "SLOT": "G2+TG2",
    "FACULTY": "VEZHAVENDHAN R"
}, {
    "CODE": "MEE2038",
    "TITLE": "Thermal and Heat Transfer",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB110",
    "SLOT": "A2+TA2+V3",
    "FACULTY": "PREMKARTIKKUMAR S R"
}, {
    "CODE": "MEE2041",
    "TITLE": "Vehicle Body Engineering",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDN129",
    "SLOT": "E1+TE1",
    "FACULTY": "PRABU K"
}, {
    "CODE": "MEE2042",
    "TITLE": "Two and Three Wheeler",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDN120",
    "SLOT": "C1+TC1",
    "FACULTY": "KANNAN C"
}, {
    "CODE": "MEE2043",
    "TITLE": "Vehicle Inspection and Maintenance",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB201",
    "SLOT": "D1",
    "FACULTY": "RAMESH KUMAR C"
}, {
    "CODE": "MEE2043",
    "TITLE": "Vehicle Inspection and Maintenance",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMESH KUMAR C"
}, {
    "CODE": "MEE2045",
    "TITLE": "Automotive Control Systems",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDN128",
    "SLOT": "G1",
    "FACULTY": "KRISHNA S"
}, {
    "CODE": "MEE2045",
    "TITLE": "Automotive Control Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KRISHNA S"
}, {
    "CODE": "MEE2052",
    "TITLE": "Sustainable Energy",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB315",
    "SLOT": "E1",
    "FACULTY": "SIVASANKARI S"
}, {
    "CODE": "MEE2052",
    "TITLE": "Sustainable Energy",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB315",
    "SLOT": "E2",
    "FACULTY": "SIVASANKARI S"
}, {
    "CODE": "MEE2052",
    "TITLE": "Sustainable Energy",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN135",
    "SLOT": "L11+L12",
    "FACULTY": "SIVASANKARI S"
}, {
    "CODE": "MEE2052",
    "TITLE": "Sustainable Energy",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN135",
    "SLOT": "L21+L22",
    "FACULTY": "SIVASANKARI S"
}, {
    "CODE": "MEE2052",
    "TITLE": "Sustainable Energy",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN135",
    "SLOT": "L31+L32",
    "FACULTY": "SIVASANKARI S"
}, {
    "CODE": "MEE2052",
    "TITLE": "Sustainable Energy",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN135",
    "SLOT": "L43+L44",
    "FACULTY": "SIVASANKARI S"
}, {
    "CODE": "MEE2058",
    "TITLE": "Small Hydro Power Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB213",
    "SLOT": "E1+TE1",
    "FACULTY": "KAVITHA M.S"
}, {
    "CODE": "MEE2058",
    "TITLE": "Small Hydro Power Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KAVITHA M.S"
}, {
    "CODE": "MEE2060",
    "TITLE": "Integrated Energy Systems",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB201",
    "SLOT": "F2+TF2",
    "FACULTY": "CHIRANJEEVI C"
}, {
    "CODE": "MEE2065",
    "TITLE": "Energy in Built Environment",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN129",
    "SLOT": "A2+TA2",
    "FACULTY": "SATYAJIT GHOSH"
}, {
    "CODE": "MEE2065",
    "TITLE": "Energy in Built Environment",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SATYAJIT GHOSH"
}, {
    "CODE": "MEE218",
    "TITLE": "Hardware Project",
    "TYPE": "PJT",
    "CREDITS": "2",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "MEE221",
    "TITLE": "Design Project",
    "TYPE": "PJT",
    "CREDITS": "2",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "MEE3001",
    "TITLE": "Design of Machine Elements",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB201",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "MOHAN VARMA DAMU\nSESHADRI"
}, {
    "CODE": "MEE3001",
    "TITLE": "Design of Machine Elements",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB213",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "BENEDICT THOMAS"
}, {
    "CODE": "MEE3001",
    "TITLE": "Design of Machine Elements",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB212",
    "SLOT": "D2+TD2+V6",
    "FACULTY": "BENEDICT THOMAS"
}, {
    "CODE": "MEE3001",
    "TITLE": "Design of Machine Elements",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB111",
    "SLOT": "A2+TA2+V3",
    "FACULTY": "BIKASH ROUTH"
}, {
    "CODE": "MEE3001",
    "TITLE": "Design of Machine Elements",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB201",
    "SLOT": "D2+TD2+V6",
    "FACULTY": "MANOHARAN R"
}, {
    "CODE": "MEE3001",
    "TITLE": "Design of Machine Elements",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB227",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "NIRANJANA BEHERA"
}, {
    "CODE": "MEE3001",
    "TITLE": "Design of Machine Elements",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB227",
    "SLOT": "A2+TA2+V3",
    "FACULTY": "VENKATESAN K"
}, {
    "CODE": "MEE3002",
    "TITLE": "Finite Element Analysis",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB219",
    "SLOT": "A1+TA1+V1",
    "FACULTY": "GANAPATHI M"
}, {
    "CODE": "MEE3002",
    "TITLE": "Finite Element Analysis",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "MB115",
    "SLOT": "L55+L56",
    "FACULTY": "GANAPATHI M"
}, {
    "CODE": "MEE3002",
    "TITLE": "Finite Element Analysis",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "MB115",
    "SLOT": "L5+L6",
    "FACULTY": "GANAPATHI M"
}, {
    "CODE": "MEE3003",
    "TITLE": "Engineering Failure Analysis",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN109",
    "SLOT": "G2+TG2",
    "FACULTY": "PADMANABHAN K"
}, {
    "CODE": "MEE3003",
    "TITLE": "Engineering Failure Analysis",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PADMANABHAN K"
}, {
    "CODE": "MEE3003",
    "TITLE": "Engineering Failure Analysis",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB214",
    "SLOT": "D1+TD1",
    "FACULTY": "SREETHUL DAS"
}, {
    "CODE": "MEE3003",
    "TITLE": "Engineering Failure Analysis",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SREETHUL DAS"
}, {
    "CODE": "MEE3004",
    "TITLE": "Internal Combustion Engines",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDN122",
    "SLOT": "F1+TF1",
    "FACULTY": "NANTHA GOPAL K"
}, {
    "CODE": "MEE3004",
    "TITLE": "Internal Combustion Engines",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB224",
    "SLOT": "E1+TE1",
    "FACULTY": "KAMATCHI R"
}, {
    "CODE": "MEE3004",
    "TITLE": "Internal Combustion Engines",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB218",
    "SLOT": "E1",
    "FACULTY": "RAJA SEKHAR Y"
}, {
    "CODE": "MEE3004",
    "TITLE": "Internal Combustion Engines",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB214",
    "SLOT": "F2+TF2",
    "FACULTY": "ARUNA KUMAR BEHURA"
}, {
    "CODE": "MEE3004",
    "TITLE": "Internal Combustion Engines",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB211",
    "SLOT": "G2+TG2",
    "FACULTY": "SEKARAPANDIAN N"
}, {
    "CODE": "MEE3005",
    "TITLE": "Refrigeration and Airconditioning",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "MB227",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "TANGELLAPALLI SRINIVAS"
}, {
    "CODE": "MEE3005",
    "TITLE": "Refrigeration and Airconditioning",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "GDN122",
    "SLOT": "C2+TC2+TCC2+V5",
    "FACULTY": "SABOOR S"
}, {
    "CODE": "MEE3005",
    "TITLE": "Refrigeration and Airconditioning",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "GDN129",
    "SLOT": "D2+TD2+TDD2+V6",
    "FACULTY": "VINOD KUMAR SHARMA"
}, {
    "CODE": "MEE3005",
    "TITLE": "Refrigeration and Airconditioning",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "MB315",
    "SLOT": "C1+TC1+TCC1+V2",
    "FACULTY": "SENTHIL KUMAR A"
}, {
    "CODE": "MEE3006",
    "TITLE": "Automobile Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB227",
    "SLOT": "E1",
    "FACULTY": "PONNUSAMY P"
}, {
    "CODE": "MEE3006",
    "TITLE": "Automobile Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L49+L50",
    "FACULTY": "PONNUSAMY P"
}, {
    "CODE": "MEE3006",
    "TITLE": "Automobile Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L53+L54",
    "FACULTY": "PONNUSAMY P"
}, {
    "CODE": "MEE3011",
    "TITLE": "Solar Thermal Power Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDN122",
    "SLOT": "G1",
    "FACULTY": "NATARAJAN M"
}, {
    "CODE": "MEE3011",
    "TITLE": "Solar Thermal Power Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN136",
    "SLOT": "L23+L24",
    "FACULTY": "NATARAJAN M"
}, {
    "CODE": "MEE3011",
    "TITLE": "Solar Thermal Power Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN136",
    "SLOT": "L29+L30",
    "FACULTY": "NATARAJAN M"
}, {
    "CODE": "MEE3011",
    "TITLE": "Solar Thermal Power Engineering",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB214",
    "SLOT": "F1",
    "FACULTY": "ARUNA KUMAR BEHURA"
}, {
    "CODE": "MEE3011",
    "TITLE": "Solar Thermal Power Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN136",
    "SLOT": "L37+L38",
    "FACULTY": "ARUNA KUMAR BEHURA"
}, {
    "CODE": "MEE3011",
    "TITLE": "Solar Thermal Power Engineering",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN136",
    "SLOT": "L43+L44",
    "FACULTY": "ARUNA KUMAR BEHURA"
}, {
    "CODE": "MEE3012",
    "TITLE": "Computer Aided Manufacturing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB218",
    "SLOT": "D1",
    "FACULTY": "RAJKUMAR E"
}, {
    "CODE": "MEE3012",
    "TITLE": "Computer Aided Manufacturing",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN130",
    "SLOT": "L41+L42",
    "FACULTY": "RAJKUMAR E"
}, {
    "CODE": "MEE3014",
    "TITLE": "Engineering Metrology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB111",
    "SLOT": "G2",
    "FACULTY": "SUNDARAMALI G"
}, {
    "CODE": "MEE3014",
    "TITLE": "Engineering Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN136",
    "SLOT": "L5+L6",
    "FACULTY": "SUNDARAMALI G"
}, {
    "CODE": "MEE3014",
    "TITLE": "Engineering Metrology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN136",
    "SLOT": "L11+L12",
    "FACULTY": "SUNDARAMALI G"
}, {
    "CODE": "MEE3015",
    "TITLE": "Automotive Engines",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB110",
    "SLOT": "C2+TC2",
    "FACULTY": "VIJAYAKUMAR T"
}, {
    "CODE": "MEE3015",
    "TITLE": "Automotive Engines",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L5+L6",
    "FACULTY": "VIJAYAKUMAR T"
}, {
    "CODE": "MEE3015",
    "TITLE": "Automotive Engines",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "GDN25A",
    "SLOT": "L9+L10",
    "FACULTY": "VIJAYAKUMAR T"
}, {
    "CODE": "MEE305",
    "TITLE": "Design Project",
    "TYPE": "PJT",
    "CREDITS": "2",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "MEE3999",
    "TITLE": "Technical Answers for Real World\nProblems (TARP)",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "MB218",
    "SLOT": "TG1",
    "FACULTY": "ANTHONY XAVIOR M"
}, {
    "CODE": "MEE3999",
    "TITLE": "Technical Answers for Real World\nProblems (TARP)",
    "TYPE": "EPJ",
    "CREDITS": "2",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANTHONY XAVIOR M"
}, {
    "CODE": "MEE3999",
    "TITLE": "Technical Answers for Real World\nProblems (TARP)",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "MB218",
    "SLOT": "TG2",
    "FACULTY": "ARIVAZHAGAN N"
}, {
    "CODE": "MEE3999",
    "TITLE": "Technical Answers for Real World\nProblems (TARP)",
    "TYPE": "EPJ",
    "CREDITS": "2",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ARIVAZHAGAN N"
}, {
    "CODE": "MEE3999",
    "TITLE": "Technical Answers for Real World\nProblems (TARP)",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "MB103",
    "SLOT": "TG1",
    "FACULTY": "THIAGARAJAN S"
}, {
    "CODE": "MEE3999",
    "TITLE": "Technical Answers for Real World\nProblems (TARP)",
    "TYPE": "EPJ",
    "CREDITS": "2",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "THIAGARAJAN S"
}, {
    "CODE": "MEE4001",
    "TITLE": "Tool Design",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CDMM1\n02",
    "SLOT": "B1+TB1",
    "FACULTY": "RAJYALAKSHMI G"
}, {
    "CODE": "MEE4001",
    "TITLE": "Tool Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJYALAKSHMI G"
}, {
    "CODE": "MEE4002",
    "TITLE": "Advanced Machining Processes",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "GDN109",
    "SLOT": "F2",
    "FACULTY": "MURALIDHARAN B"
}, {
    "CODE": "MEE4002",
    "TITLE": "Advanced Machining Processes",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MURALIDHARAN B"
}, {
    "CODE": "MEE4002",
    "TITLE": "Advanced Machining Processes",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB103",
    "SLOT": "F1",
    "FACULTY": "RAJAMURUGAN G"
}, {
    "CODE": "MEE4002",
    "TITLE": "Advanced Machining Processes",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAJAMURUGAN G"
}, {
    "CODE": "MEE4003",
    "TITLE": "Micro and Nano Machining",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB212",
    "SLOT": "D1+TD1",
    "FACULTY": "MURALIDHARAN B"
}, {
    "CODE": "MEE4005",
    "TITLE": "Surface Engineering",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB201",
    "SLOT": "G1+TG1",
    "FACULTY": "SITARAM DASH"
}, {
    "CODE": "MEE4006",
    "TITLE": "Computational Fluid Dynamics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB225",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "PADMANATHAN P"
}, {
    "CODE": "MEE4006",
    "TITLE": "Computational Fluid Dynamics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "MB112",
    "SLOT": "L5+L6",
    "FACULTY": "PADMANATHAN P"
}, {
    "CODE": "MEE4006",
    "TITLE": "Computational Fluid Dynamics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "MB112",
    "SLOT": "L23+L24",
    "FACULTY": "PADMANATHAN P"
}, {
    "CODE": "MEE4006",
    "TITLE": "Computational Fluid Dynamics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV105",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "ASHOK K"
}, {
    "CODE": "MEE4006",
    "TITLE": "Computational Fluid Dynamics",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SMV102",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "ASHOK K"
}, {
    "CODE": "MEE4006",
    "TITLE": "Computational Fluid Dynamics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "MB112",
    "SLOT": "L29+L30",
    "FACULTY": "ASHOK K"
}, {
    "CODE": "MEE4006",
    "TITLE": "Computational Fluid Dynamics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "MB112",
    "SLOT": "L15+L16",
    "FACULTY": "ASHOK K"
}, {
    "CODE": "MEE4006",
    "TITLE": "Computational Fluid Dynamics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "MB112",
    "SLOT": "L51+L52",
    "FACULTY": "ASHOK K"
}, {
    "CODE": "MEE4006",
    "TITLE": "Computational Fluid Dynamics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "MB112",
    "SLOT": "L59+L60",
    "FACULTY": "ASHOK K"
}, {
    "CODE": "MEE4007",
    "TITLE": "Design of Transmission Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB212",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "NARENDIRANATH BABU T"
}, {
    "CODE": "MEE4007",
    "TITLE": "Design of Transmission Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NARENDIRANATH BABU T"
}, {
    "CODE": "MEE4007",
    "TITLE": "Design of Transmission Systems",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB103",
    "SLOT": "A2+TA2+V3",
    "FACULTY": "RAMESH BABU VEMULURI"
}, {
    "CODE": "MEE4007",
    "TITLE": "Design of Transmission Systems",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMESH BABU VEMULURI"
}, {
    "CODE": "MEE499",
    "TITLE": "Project Work",
    "TYPE": "PJT",
    "CREDITS": "20",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "MEE6099",
    "TITLE": "Masters Thesis",
    "TYPE": "PJT",
    "CREDITS": "16",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "MGT1018",
    "TITLE": "Consumer Behaviour",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB202",
    "SLOT": "B1+TB1",
    "FACULTY": "VENUGOPAL P."
}, {
    "CODE": "MGT1018",
    "TITLE": "Consumer Behaviour",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT823",
    "SLOT": "C1+TC1",
    "FACULTY": "SURAJ KUSHE SHEKHAR"
}, {
    "CODE": "MGT1021",
    "TITLE": "Digital and Social Media Marketing",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "MB315",
    "SLOT": "F1+TF1",
    "FACULTY": "GANGATHARAN C"
}, {
    "CODE": "MGT1021",
    "TITLE": "Digital and Social Media Marketing",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "GDN123",
    "SLOT": "F1+TF1",
    "FACULTY": "PADMAVATHY C"
}, {
    "CODE": "MGT1023",
    "TITLE": "Fundamentals of Human Resource\nManagement",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB224",
    "SLOT": "F1+TF1",
    "FACULTY": "RAMASESHAN H."
}, {
    "CODE": "MGT1023",
    "TITLE": "Fundamentals of Human Resource\nManagement",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMASESHAN H."
}, {
    "CODE": "MGT1023",
    "TITLE": "Fundamentals of Human Resource\nManagement",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB224",
    "SLOT": "F2+TF2",
    "FACULTY": "RAMASESHAN H."
}, {
    "CODE": "MGT1023",
    "TITLE": "Fundamentals of Human Resource\nManagement",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMASESHAN H."
}, {
    "CODE": "MGT1023",
    "TITLE": "Fundamentals of Human Resource\nManagement",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB227",
    "SLOT": "F1+TF1",
    "FACULTY": "SUBASHINI R"
}, {
    "CODE": "MGT1023",
    "TITLE": "Fundamentals of Human Resource\nManagement",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUBASHINI R"
}, {
    "CODE": "MGT1024",
    "TITLE": "Organizational Behaviour",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB315",
    "SLOT": "B1+TB1",
    "FACULTY": "SEEMA A"
}, {
    "CODE": "MGT1024",
    "TITLE": "Organizational Behaviour",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SEEMA A"
}, {
    "CODE": "MGT1024",
    "TITLE": "Organizational Behaviour",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT803",
    "SLOT": "B2+TB2",
    "FACULTY": "SEEMA A"
}, {
    "CODE": "MGT1024",
    "TITLE": "Organizational Behaviour",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SEEMA A"
}, {
    "CODE": "MGT1028",
    "TITLE": "Accounting and Financial Management",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT823",
    "SLOT": "B2+TB2+V4",
    "FACULTY": "VISALAKSHMI S"
}, {
    "CODE": "MGT1028",
    "TITLE": "Accounting and Financial Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VISALAKSHMI S"
}, {
    "CODE": "MGT1030",
    "TITLE": "Entrepreneurship Development",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB226",
    "SLOT": "B1+TB1",
    "FACULTY": "MERCY MATHEW"
}, {
    "CODE": "MGT1030",
    "TITLE": "Entrepreneurship Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MERCY MATHEW"
}, {
    "CODE": "MGT1030",
    "TITLE": "Entrepreneurship Development",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB225",
    "SLOT": "G1+TG1",
    "FACULTY": "MERCY MATHEW"
}, {
    "CODE": "MGT1030",
    "TITLE": "Entrepreneurship Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MERCY MATHEW"
}, {
    "CODE": "MGT1034",
    "TITLE": "Project Management",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB214",
    "SLOT": "G1+TG1",
    "FACULTY": "GIRIRAJ M"
}, {
    "CODE": "MGT1034",
    "TITLE": "Project Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GIRIRAJ M"
}, {
    "CODE": "MGT1034",
    "TITLE": "Project Management",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN129",
    "SLOT": "F1+TF1",
    "FACULTY": "BOOPATHI M"
}, {
    "CODE": "MGT1034",
    "TITLE": "Project Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BOOPATHI M"
}, {
    "CODE": "MGT1036",
    "TITLE": "Principles of Marketing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN122",
    "SLOT": "A1+TA1",
    "FACULTY": "VENUGOPAL P."
}, {
    "CODE": "MGT1036",
    "TITLE": "Principles of Marketing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VENUGOPAL P."
}, {
    "CODE": "MGT1036",
    "TITLE": "Principles of Marketing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB103",
    "SLOT": "C1+TC1",
    "FACULTY": "NAGA VENKATA RAGHURAM J."
}, {
    "CODE": "MGT1036",
    "TITLE": "Principles of Marketing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NAGA VENKATA RAGHURAM J."
}, {
    "CODE": "MGT1036",
    "TITLE": "Principles of Marketing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "GDN129",
    "SLOT": "A1+TA1",
    "FACULTY": "GEMINI V JOY"
}, {
    "CODE": "MGT1036",
    "TITLE": "Principles of Marketing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GEMINI V JOY"
}, {
    "CODE": "MGT1036",
    "TITLE": "Principles of Marketing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB315",
    "SLOT": "D1+TD1",
    "FACULTY": "GEMINI V JOY"
}, {
    "CODE": "MGT1036",
    "TITLE": "Principles of Marketing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GEMINI V JOY"
}, {
    "CODE": "MGT1036",
    "TITLE": "Principles of Marketing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB225",
    "SLOT": "F1+TF1",
    "FACULTY": "SUDHAKAR  R"
}, {
    "CODE": "MGT1036",
    "TITLE": "Principles of Marketing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUDHAKAR  R"
}, {
    "CODE": "MGT1036",
    "TITLE": "Principles of Marketing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT825",
    "SLOT": "B2+TB2",
    "FACULTY": "SUDHAKAR  R"
}, {
    "CODE": "MGT1036",
    "TITLE": "Principles of Marketing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUDHAKAR  R"
}, {
    "CODE": "MGT1036",
    "TITLE": "Principles of Marketing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT825",
    "SLOT": "B1+TB1",
    "FACULTY": "PADMAVATHY C"
}, {
    "CODE": "MGT1036",
    "TITLE": "Principles of Marketing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "PADMAVATHY C"
}, {
    "CODE": "MGT1038",
    "TITLE": "Financial Econometrics",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT803",
    "SLOT": "G1",
    "FACULTY": "VISALAKSHMI S"
}, {
    "CODE": "MGT1038",
    "TITLE": "Financial Econometrics",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VISALAKSHMI S"
}, {
    "CODE": "MGT1039",
    "TITLE": "Financial Markets and Institutions",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "MB225",
    "SLOT": "B1",
    "FACULTY": "SEETHA RAM V."
}, {
    "CODE": "MGT1039",
    "TITLE": "Financial Markets and Institutions",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SEETHA RAM V."
}, {
    "CODE": "MGT1042",
    "TITLE": "Investment Analysis and Portfolio\nManagement",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CDMM1\n01",
    "SLOT": "G1",
    "FACULTY": "MANOHARAN M"
}, {
    "CODE": "MGT1042",
    "TITLE": "Investment Analysis and Portfolio\nManagement",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MANOHARAN M"
}, {
    "CODE": "MGT1047",
    "TITLE": "Social Marketing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "MB214",
    "SLOT": "B1+TB1",
    "FACULTY": "SURAJ KUSHE SHEKHAR"
}, {
    "CODE": "MGT1047",
    "TITLE": "Social Marketing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SURAJ KUSHE SHEKHAR"
}, {
    "CODE": "MGT1051",
    "TITLE": "Business Analytics for Engineers",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT824",
    "SLOT": "B2+TB2+V4",
    "FACULTY": "RAVIKUMAR B"
}, {
    "CODE": "MGT1051",
    "TITLE": "Business Analytics for Engineers",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT824",
    "SLOT": "C1+TC1+V2",
    "FACULTY": "RAVIKUMAR B"
}, {
    "CODE": "MGT1051",
    "TITLE": "Business Analytics for Engineers",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT823",
    "SLOT": "C2+TC2+V5",
    "FACULTY": "GANGATHARAN C"
}, {
    "CODE": "ARB1001",
    "TITLE": "Arabic for Beginners",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT824",
    "SLOT": "F1+TF1",
    "FACULTY": "INAMUL AZAD"
}, {
    "CODE": "ARB1001",
    "TITLE": "Arabic for Beginners",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG24",
    "SLOT": "F2+TF2",
    "FACULTY": "INAMUL AZAD"
}, {
    "CODE": "CCA1012",
    "TITLE": "Management Accounting",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT726",
    "SLOT": "A1+TA1",
    "FACULTY": "SELVAKUMAR D S"
}, {
    "CODE": "CCA1012",
    "TITLE": "Management Accounting",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT334",
    "SLOT": "D1+TD1",
    "FACULTY": "SELVAKUMAR D S"
}, {
    "CODE": "CCA1013",
    "TITLE": "Income Tax Law and Practice",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT305",
    "SLOT": "A1+TA1",
    "FACULTY": "VELMURUGAN G"
}, {
    "CODE": "CCA1013",
    "TITLE": "Income Tax Law and Practice",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VELMURUGAN G"
}, {
    "CODE": "CCA1013",
    "TITLE": "Income Tax Law and Practice",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT504",
    "SLOT": "D1+TD1",
    "FACULTY": "VELMURUGAN G"
}, {
    "CODE": "CCA1013",
    "TITLE": "Income Tax Law and Practice",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VELMURUGAN G"
}, {
    "CODE": "CCA1018",
    "TITLE": "IT and Business Applications",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT313",
    "SLOT": "E1",
    "FACULTY": "MANI P"
}, {
    "CODE": "CCA1018",
    "TITLE": "IT and Business Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MANI P"
}, {
    "CODE": "CCA1018",
    "TITLE": "IT and Business Applications",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CTS301",
    "SLOT": "F1",
    "FACULTY": "VIJAYASHREE J"
}, {
    "CODE": "CCA1018",
    "TITLE": "IT and Business Applications",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIJAYASHREE J"
}, {
    "CODE": "CCA1019",
    "TITLE": "Business Communication",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT313",
    "SLOT": "C1",
    "FACULTY": "NAGESWARI  R"
}, {
    "CODE": "CCA1019",
    "TITLE": "Business Communication",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NAGESWARI  R"
}, {
    "CODE": "CCA1019",
    "TITLE": "Business Communication",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CTS301",
    "SLOT": "B1",
    "FACULTY": "ANBURAJ G"
}, {
    "CODE": "CCA1019",
    "TITLE": "Business Communication",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ANBURAJ G"
}, {
    "CODE": "CCA1020",
    "TITLE": "Research Methods in Commerce",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT334",
    "SLOT": "D2",
    "FACULTY": "RAMOLA PREMALATHA J"
}, {
    "CODE": "CCA1020",
    "TITLE": "Research Methods in Commerce",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "RAMOLA PREMALATHA J"
}, {
    "CODE": "CCA1022",
    "TITLE": "Indian Financial System",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT313",
    "SLOT": "F1",
    "FACULTY": "MUTHUMEENAKSHI M"
}, {
    "CODE": "CCA1022",
    "TITLE": "Indian Financial System",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MUTHUMEENAKSHI M"
}, {
    "CODE": "CCA1022",
    "TITLE": "Indian Financial System",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "CTS301",
    "SLOT": "C1",
    "FACULTY": "MUTHUMEENAKSHI M"
}, {
    "CODE": "CCA1022",
    "TITLE": "Indian Financial System",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "MUTHUMEENAKSHI M"
}, {
    "CODE": "CCA1035",
    "TITLE": "Export Marketing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "TT313",
    "SLOT": "B1+TB1",
    "FACULTY": "VIJAYARAJ K"
}, {
    "CODE": "CCA1035",
    "TITLE": "Export Marketing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIJAYARAJ K"
}, {
    "CODE": "CCA1035",
    "TITLE": "Export Marketing",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "CTS302",
    "SLOT": "E1+TE1",
    "FACULTY": "VIJAYARAJ K"
}, {
    "CODE": "CCA1035",
    "TITLE": "Export Marketing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIJAYARAJ K"
}, {
    "CODE": "CCA1709",
    "TITLE": "Principles of Marketing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT333",
    "SLOT": "E1",
    "FACULTY": "GEETHA R"
}, {
    "CODE": "CCA1709",
    "TITLE": "Principles of Marketing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GEETHA R"
}, {
    "CODE": "CCA1709",
    "TITLE": "Principles of Marketing",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT334",
    "SLOT": "F1",
    "FACULTY": "GEETHA R"
}, {
    "CODE": "CCA1709",
    "TITLE": "Principles of Marketing",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GEETHA R"
}, {
    "CODE": "CCA2701",
    "TITLE": "Corporate Laws",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT333",
    "SLOT": "C1+TC1",
    "FACULTY": "USHA S"
}, {
    "CODE": "CCA2701",
    "TITLE": "Corporate Laws",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT334",
    "SLOT": "A1+TA1",
    "FACULTY": "USHA S"
}, {
    "CODE": "CCA2702",
    "TITLE": "Performance Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT333",
    "SLOT": "B1+TB1",
    "FACULTY": "MUTHUMEENAKSHI M"
}, {
    "CODE": "CCA2702",
    "TITLE": "Performance Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT334",
    "SLOT": "E1+TE1",
    "FACULTY": "DUNSTAN RAJKUMAR A"
}, {
    "CODE": "CCA2703",
    "TITLE": "Financial Reporting",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT333",
    "SLOT": "F1+TF1",
    "FACULTY": "AJAY KUMAR SHARMA"
}, {
    "CODE": "CCA2703",
    "TITLE": "Financial Reporting",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT334",
    "SLOT": "B1+TB1",
    "FACULTY": "AJAY KUMAR SHARMA"
}, {
    "CODE": "CCA2706",
    "TITLE": "Corporate Accounting",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "TT333",
    "SLOT": "A1+TA1+TAA1",
    "FACULTY": "RAMOLA PREMALATHA J"
}, {
    "CODE": "CCA2706",
    "TITLE": "Corporate Accounting",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "TT334",
    "SLOT": "C1+TC1+TCC1",
    "FACULTY": "RAMOLA PREMALATHA J"
}, {
    "CODE": "CCA2707",
    "TITLE": "Cost Accounting",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "CTS302",
    "SLOT": "C1+TC1+TCC1",
    "FACULTY": "AJAY KUMAR SHARMA"
}, {
    "CODE": "CCA2709",
    "TITLE": "Advanced Financial Accounting",
    "TYPE": "TH",
    "CREDITS": "4",
    "VENUE": "CTS302",
    "SLOT": "A1+TA1+TAA1",
    "FACULTY": "SARAVANA BHAVAN  N"
}, {
    "CODE": "CCA3702",
    "TITLE": "E-Commerce",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT621A",
    "SLOT": "E1+TE1",
    "FACULTY": "VIJAYASHREE J"
}, {
    "CODE": "ENG1012",
    "TITLE": "Communicative English",
    "TYPE": "LO",
    "CREDITS": "2",
    "VENUE": "SJT224",
    "SLOT": "L15+L16+L29+L30",
    "FACULTY": "SENGUTTUVAN M"
}, {
    "CODE": "ESP1001",
    "TITLE": "ESPANOL FUNDAMENTAL",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "SJT501",
    "SLOT": "A1",
    "FACULTY": "GAURAV SUSHANT"
}, {
    "CODE": "ESP2001",
    "TITLE": "ESPANOL INTERMEDIO",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT126",
    "SLOT": "E1",
    "FACULTY": "GAURAV SUSHANT"
}, {
    "CODE": "ESP2001",
    "TITLE": "ESPANOL INTERMEDIO",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT318",
    "SLOT": "L21+L22",
    "FACULTY": "GAURAV SUSHANT"
}, {
    "CODE": "FRE1001",
    "TITLE": "Francais quotidien",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "TT531A",
    "SLOT": "A1",
    "FACULTY": "COUMARAN G"
}, {
    "CODE": "FRE1001",
    "TITLE": "Francais quotidien",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "TT524",
    "SLOT": "B1",
    "FACULTY": "COUMARAN G"
}, {
    "CODE": "FRE1001",
    "TITLE": "Francais quotidien",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "SMV101",
    "SLOT": "B2",
    "FACULTY": "MALATHY O"
}, {
    "CODE": "FRE1001",
    "TITLE": "Francais quotidien",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "SMV217",
    "SLOT": "C2",
    "FACULTY": "MALATHY O"
}, {
    "CODE": "FRE1001",
    "TITLE": "Francais quotidien",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "SMVG33",
    "SLOT": "G1",
    "FACULTY": "MALATHY O"
}, {
    "CODE": "FRE1001",
    "TITLE": "Francais quotidien",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "SMV104",
    "SLOT": "C2",
    "FACULTY": "ANTOINETTE DANIEL"
}, {
    "CODE": "FRE1001",
    "TITLE": "Francais quotidien",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "SMV109",
    "SLOT": "B2",
    "FACULTY": "ANTOINETTE DANIEL"
}, {
    "CODE": "FRE2001",
    "TITLE": "Francais progressif",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT318",
    "SLOT": "L27+L28",
    "FACULTY": "CALAIVANANE R"
}, {
    "CODE": "FRE2001",
    "TITLE": "Francais progressif",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV105",
    "SLOT": "B1",
    "FACULTY": "CALAIVANANE R"
}, {
    "CODE": "GER1001",
    "TITLE": "Grundstufe Deutsch",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "SMV235",
    "SLOT": "B2",
    "FACULTY": "NISHA P.V"
}, {
    "CODE": "GER1001",
    "TITLE": "Grundstufe Deutsch",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "SMVG33",
    "SLOT": "A1",
    "FACULTY": "SREEKUMAR K N"
}, {
    "CODE": "GER1001",
    "TITLE": "Grundstufe Deutsch",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "TT621",
    "SLOT": "B2",
    "FACULTY": "ADAIKALAM ARULANANDAM"
}, {
    "CODE": "GER2001",
    "TITLE": "Mittelstufe Deutsch",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT318",
    "SLOT": "L25+L26",
    "FACULTY": "SREEKUMAR K N"
}, {
    "CODE": "GER2001",
    "TITLE": "Mittelstufe Deutsch",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMVG33",
    "SLOT": "B1",
    "FACULTY": "SREEKUMAR K N"
}, {
    "CODE": "HIN1003",
    "TITLE": "Prathamik Hindi",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMVG33",
    "SLOT": "F1+TF1",
    "FACULTY": "JAYALAKSHMI K"
}, {
    "CODE": "HIN1004",
    "TITLE": "Functional Hindi",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMVG33",
    "SLOT": "C1",
    "FACULTY": "JAYALAKSHMI K"
}, {
    "CODE": "HIN1004",
    "TITLE": "Functional Hindi",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT318",
    "SLOT": "L57+L58",
    "FACULTY": "JAYALAKSHMI K"
}, {
    "CODE": "HUM1006",
    "TITLE": "Business Accounting for Engineers",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT305",
    "SLOT": "F2+TF2",
    "FACULTY": "SELVAKUMAR D S"
}, {
    "CODE": "HUM1006",
    "TITLE": "Business Accounting for Engineers",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT333",
    "SLOT": "G2+TG2",
    "FACULTY": "SELVAM V"
}, {
    "CODE": "HUM1007",
    "TITLE": "Contemporary Legal Framework for\nBusiness",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT313",
    "SLOT": "G1+TG1",
    "FACULTY": "USHA S"
}, {
    "CODE": "HUM1009",
    "TITLE": "International Business",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT305",
    "SLOT": "D2+TD2",
    "FACULTY": "GEETHA R"
}, {
    "CODE": "HUM1009",
    "TITLE": "International Business",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT334",
    "SLOT": "F2+TF2",
    "FACULTY": "VIJAYARAJ K"
}, {
    "CODE": "HUM1012",
    "TITLE": "Introduction to Sociology",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT617",
    "SLOT": "D2+TD2",
    "FACULTY": "BALAMURUGAN J"
}, {
    "CODE": "HUM1013",
    "TITLE": "Population Studies",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT334",
    "SLOT": "B2+TB2",
    "FACULTY": "KUBENDRAN A"
}, {
    "CODE": "HUM1021",
    "TITLE": "Ethics and Values",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "SJT504",
    "SLOT": "G2",
    "FACULTY": "SUDHEER C.V."
}, {
    "CODE": "HUM1022",
    "TITLE": "Psychology in Everyday Life",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT333",
    "SLOT": "C2",
    "FACULTY": "BHUVANESWARI M"
}, {
    "CODE": "HUM1022",
    "TITLE": "Psychology in Everyday Life",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BHUVANESWARI M"
}, {
    "CODE": "HUM1022",
    "TITLE": "Psychology in Everyday Life",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT502",
    "SLOT": "E2",
    "FACULTY": "TONY P JOSE"
}, {
    "CODE": "HUM1022",
    "TITLE": "Psychology in Everyday Life",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "TONY P JOSE"
}, {
    "CODE": "HUM1022",
    "TITLE": "Psychology in Everyday Life",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMVG11",
    "SLOT": "D2",
    "FACULTY": "NAVIN KUMAR"
}, {
    "CODE": "HUM1022",
    "TITLE": "Psychology in Everyday Life",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "NAVIN KUMAR"
}, {
    "CODE": "HUM1023",
    "TITLE": "Indian Heritage and Culture",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV219",
    "SLOT": "E2",
    "FACULTY": "BANGALORE MORARJI"
}, {
    "CODE": "HUM1023",
    "TITLE": "Indian Heritage and Culture",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BANGALORE MORARJI"
}, {
    "CODE": "HUM1024",
    "TITLE": "India and Contemporary World",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SMV105",
    "SLOT": "F1",
    "FACULTY": "BANGALORE MORARJI"
}, {
    "CODE": "HUM1024",
    "TITLE": "India and Contemporary World",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BANGALORE MORARJI"
}, {
    "CODE": "HUM1025",
    "TITLE": "Indian Classical Music",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT301A",
    "SLOT": "TB2",
    "FACULTY": "SUDHEER C.V."
}, {
    "CODE": "HUM1025",
    "TITLE": "Indian Classical Music",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "SJT301A",
    "SLOT": "TG1",
    "FACULTY": "SUDHEER C.V."
}, {
    "CODE": "HUM1025",
    "TITLE": "Indian Classical Music",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT301A",
    "SLOT": "L11+L12",
    "FACULTY": "SUDHEER C.V."
}, {
    "CODE": "HUM1025",
    "TITLE": "Indian Classical Music",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUDHEER C.V."
}, {
    "CODE": "HUM1025",
    "TITLE": "Indian Classical Music",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT301A",
    "SLOT": "L23+L24",
    "FACULTY": "SUDHEER C.V."
}, {
    "CODE": "HUM1025",
    "TITLE": "Indian Classical Music",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUDHEER C.V."
}, {
    "CODE": "HUM1033",
    "TITLE": "Micro Economics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT334",
    "SLOT": "G2+TG2",
    "FACULTY": "ALLI P"
}, {
    "CODE": "HUM1033",
    "TITLE": "Micro Economics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMVG11",
    "SLOT": "D1+TD1",
    "FACULTY": "SIVAKUMAR S"
}, {
    "CODE": "HUM1034",
    "TITLE": "Macro Economics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJTG23",
    "SLOT": "C1+TC1",
    "FACULTY": "ALLI P"
}, {
    "CODE": "HUM1034",
    "TITLE": "Macro Economics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT617",
    "SLOT": "G2+TG2",
    "FACULTY": "NILAVATHY K"
}, {
    "CODE": "HUM1034",
    "TITLE": "Macro Economics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT617",
    "SLOT": "C2+TC2",
    "FACULTY": "SAVITHA N"
}, {
    "CODE": "HUM1035",
    "TITLE": "Introductory Econometrics",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT617",
    "SLOT": "F1",
    "FACULTY": "SRIRAM G"
}, {
    "CODE": "HUM1035",
    "TITLE": "Introductory Econometrics",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT318",
    "SLOT": "L39+L40",
    "FACULTY": "SRIRAM G"
}, {
    "CODE": "HUM1037",
    "TITLE": "Applied Game Theory",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT617",
    "SLOT": "F2",
    "FACULTY": "SRIRAM G"
}, {
    "CODE": "HUM1037",
    "TITLE": "Applied Game Theory",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SRIRAM G"
}, {
    "CODE": "HUM1038",
    "TITLE": "International Economics",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT333",
    "SLOT": "E2+TE2",
    "FACULTY": "SIVAKUMAR S"
}, {
    "CODE": "HUM1040",
    "TITLE": "Indian Social Problems",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "TT333",
    "SLOT": "F2+TF2",
    "FACULTY": "KUBENDRAN A"
}, {
    "CODE": "HUM1042",
    "TITLE": "Industrial Relations and Labour Welfare\nin India",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SMV109",
    "SLOT": "B1+TB1",
    "FACULTY": "PRABAKAR S"
}, {
    "CODE": "HUM1043",
    "TITLE": "Mass Media and Society",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT619",
    "SLOT": "F1",
    "FACULTY": "BALAMURUGAN J"
}, {
    "CODE": "HUM1043",
    "TITLE": "Mass Media and Society",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BALAMURUGAN J"
}, {
    "CODE": "HUM1045",
    "TITLE": "Introduction to Psychology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "TT333",
    "SLOT": "A2",
    "FACULTY": "NAVIN KUMAR"
}, {
    "CODE": "HUM1045",
    "TITLE": "Introduction to Psychology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT501",
    "SLOT": "G1",
    "FACULTY": "TONY P JOSE"
}, {
    "CODE": "HUM1045",
    "TITLE": "Introduction to Psychology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJTG23",
    "SLOT": "D1",
    "FACULTY": "BHUVANESWARI M"
}, {
    "CODE": "HUM1045",
    "TITLE": "Introduction to Psychology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT432",
    "SLOT": "L57+L58",
    "FACULTY": "TONY P JOSE"
}, {
    "CODE": "HUM1045",
    "TITLE": "Introduction to Psychology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT432",
    "SLOT": "L37+L38",
    "FACULTY": "BHUVANESWARI M"
}, {
    "CODE": "HUM1045",
    "TITLE": "Introduction to Psychology",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "TT432",
    "SLOT": "L23+L24",
    "FACULTY": "NAVIN KUMAR"
}, {
    "CODE": "ITL1002",
    "TITLE": "Italiano Di Base",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "SJTG16",
    "SLOT": "A1",
    "FACULTY": "JACOPO MOSESSO"
}, {
    "CODE": "ITL1002",
    "TITLE": "Italiano Di Base",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "SJT801",
    "SLOT": "B1",
    "FACULTY": "JACOPO MOSESSO"
}, {
    "CODE": "RUS1001",
    "TITLE": "Russian for Beginners",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "TT621A",
    "SLOT": "B1",
    "FACULTY": "IRINA L.TRUBETSKOVA"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT408",
    "SLOT": "B1+TB1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT409",
    "SLOT": "B1+TB1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT415",
    "SLOT": "B1+TB1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT421",
    "SLOT": "B1+TB1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT422",
    "SLOT": "B1+TB1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT423",
    "SLOT": "B1+TB1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT424",
    "SLOT": "B1+TB1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT501",
    "SLOT": "B1+TB1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJTG08",
    "SLOT": "B1+TB1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT127",
    "SLOT": "B1+TB1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT408",
    "SLOT": "B2+TB2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT409",
    "SLOT": "B2+TB2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT415",
    "SLOT": "B2+TB2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT421",
    "SLOT": "B2+TB2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT422",
    "SLOT": "B2+TB2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT424",
    "SLOT": "B2+TB2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJTG08",
    "SLOT": "B2+TB2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT127",
    "SLOT": "B2+TB2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT423",
    "SLOT": "B2+TB2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3006",
    "TITLE": "Preparedness for External\nOpportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SJT207",
    "SLOT": "B2+TB2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CBMR10\n1",
    "SLOT": "B1+TB1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CBMR10\n1",
    "SLOT": "B2+TB2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CBMR30\n1",
    "SLOT": "B1+TB1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CBMR30\n1",
    "SLOT": "B2+TB2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT434A",
    "SLOT": "B1+TB1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT434A",
    "SLOT": "B2+TB2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV121",
    "SLOT": "B1+TB1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV121",
    "SLOT": "B2+TB2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "SMV112",
    "SLOT": "B1+TB1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB111",
    "SLOT": "B1+TB1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB111",
    "SLOT": "B2+TB2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB110",
    "SLOT": "B1+TB1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB110",
    "SLOT": "B2+TB2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB102",
    "SLOT": "B1+TB1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB102",
    "SLOT": "B2+TB2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB103",
    "SLOT": "B1+TB1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB103",
    "SLOT": "B2+TB2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB124",
    "SLOT": "B1+TB1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "MB124",
    "SLOT": "B2+TB2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN120",
    "SLOT": "B1+TB1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN120",
    "SLOT": "B2+TB2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN121",
    "SLOT": "B1+TB1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN121",
    "SLOT": "B2+TB2",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN122",
    "SLOT": "B1+TB1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN122",
    "SLOT": "B2+TB2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN123",
    "SLOT": "B1+TB1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "GDN123",
    "SLOT": "B2+TB2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CDMM3\n01",
    "SLOT": "B1+TB1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CDMM3\n01",
    "SLOT": "B2+TB2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CDMM3\n02",
    "SLOT": "B1+TB1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CDMM3\n02",
    "SLOT": "B2+TB2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT308",
    "SLOT": "B2+TB2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT619",
    "SLOT": "B1+TB1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT619",
    "SLOT": "B2+TB2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT620",
    "SLOT": "B1+TB1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT620",
    "SLOT": "B2+TB2",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TT621",
    "SLOT": "B1+TB1",
    "FACULTY": "SMART (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TTGAL0\n1",
    "SLOT": "B1+TB1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "TTGAL0\n1",
    "SLOT": "B2+TB2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CDMM1\n05",
    "SLOT": "B1+TB1",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CDMM1\n05",
    "SLOT": "B2+TB2",
    "FACULTY": "ETHNUS (APT)"
}, {
    "CODE": "STS3007",
    "TITLE": "Preparedness for Career Opportunities",
    "TYPE": "SS",
    "CREDITS": "1",
    "VENUE": "CTS201",
    "SLOT": "B1+TB1",
    "FACULTY": "FACE (APT)"
}, {
    "CODE": "BMT1009",
    "TITLE": "Production and Operations\nManagement",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT602A",
    "SLOT": "D1+TD1",
    "FACULTY": "STEPHAN THANGAIAH I S"
}, {
    "CODE": "BMT1009",
    "TITLE": "Production and Operations\nManagement",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT602A",
    "SLOT": "C2+TC2",
    "FACULTY": "GOUTAM KUMAR KUNDU"
}, {
    "CODE": "BMT1011",
    "TITLE": "Business Law",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT603",
    "SLOT": "B1+TB1",
    "FACULTY": "T.N.V.R.L. SWAMY"
}, {
    "CODE": "BMT1011",
    "TITLE": "Business Law",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT602A",
    "SLOT": "G2+TG2",
    "FACULTY": "INDIRA DEVI R"
}, {
    "CODE": "BMT1012",
    "TITLE": "Indian Financial System",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT603",
    "SLOT": "D2+TD2",
    "FACULTY": "SAKTHI SRINIVASAN K"
}, {
    "CODE": "BMT1012",
    "TITLE": "Indian Financial System",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT603",
    "SLOT": "C1+TC1",
    "FACULTY": "SEETHA RAM V."
}, {
    "CODE": "BMT1013",
    "TITLE": "Banking and Insurance",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT604",
    "SLOT": "C1+TC1",
    "FACULTY": "RAMANAN M"
}, {
    "CODE": "BMT1015",
    "TITLE": "Principles of Taxation",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT602A",
    "SLOT": "A1+TA1",
    "FACULTY": "CA. SRINIVAS SRIRAJ"
}, {
    "CODE": "BMT1017",
    "TITLE": "International Business",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT602A",
    "SLOT": "A2+TA2",
    "FACULTY": "BHANU SREE REDDY"
}, {
    "CODE": "BMT1017",
    "TITLE": "International Business",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT603",
    "SLOT": "A2+TA2",
    "FACULTY": "SUDIPTO BHATTACHARYA"
}, {
    "CODE": "BMT1019",
    "TITLE": "Corporate Social Responsibility",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT604",
    "SLOT": "G2",
    "FACULTY": "BHANU SREE REDDY"
}, {
    "CODE": "BMT1019",
    "TITLE": "Corporate Social Responsibility",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BHANU SREE REDDY"
}, {
    "CODE": "BMT2003",
    "TITLE": "Organizational Change and\nDevelopment",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT603",
    "SLOT": "E1+TE1",
    "FACULTY": "SUSAN CHIRAYATH"
}, {
    "CODE": "BMT2003",
    "TITLE": "Organizational Change and\nDevelopment",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT602",
    "SLOT": "D2+TD2",
    "FACULTY": "SYED KHALID PERWEZ"
}, {
    "CODE": "BMT2005",
    "TITLE": "Sales Management",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT603",
    "SLOT": "B2",
    "FACULTY": "SIVAKUMAR A"
}, {
    "CODE": "BMT2005",
    "TITLE": "Sales Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SIVAKUMAR A"
}, {
    "CODE": "BMT2005",
    "TITLE": "Sales Management",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT601",
    "SLOT": "C2",
    "FACULTY": "SUNDARA RAJAN C R"
}, {
    "CODE": "BMT2005",
    "TITLE": "Sales Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUNDARA RAJAN C R"
}, {
    "CODE": "BMT2006",
    "TITLE": "Services Marketing",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT602",
    "SLOT": "B2+TB2",
    "FACULTY": "GANESAN P"
}, {
    "CODE": "BMT2007",
    "TITLE": "Consumer Behaviour",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT602A",
    "SLOT": "E2",
    "FACULTY": "SATHISH A S"
}, {
    "CODE": "BMT2007",
    "TITLE": "Consumer Behaviour",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SATHISH A S"
}, {
    "CODE": "BMT2007",
    "TITLE": "Consumer Behaviour",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT603",
    "SLOT": "E2",
    "FACULTY": "UMA PRICILDA J."
}, {
    "CODE": "BMT2007",
    "TITLE": "Consumer Behaviour",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "UMA PRICILDA J."
}, {
    "CODE": "BMT2008",
    "TITLE": "Advertising Management",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT602A",
    "SLOT": "D2+TD2",
    "FACULTY": "UMA PRICILDA J."
}, {
    "CODE": "BMT2009",
    "TITLE": "Retail Management",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT604",
    "SLOT": "E1",
    "FACULTY": "SATHISH A S"
}, {
    "CODE": "BMT2009",
    "TITLE": "Retail Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SATHISH A S"
}, {
    "CODE": "BMT2010",
    "TITLE": "Recruitment and Selection",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT602A",
    "SLOT": "C1+TC1",
    "FACULTY": "GOMATHI S"
}, {
    "CODE": "BMT2010",
    "TITLE": "Recruitment and Selection",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT603",
    "SLOT": "C2+TC2",
    "FACULTY": "SUSAN CHIRAYATH"
}, {
    "CODE": "BMT2011",
    "TITLE": "Training and Development",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT604",
    "SLOT": "F2",
    "FACULTY": "GOMATHI S"
}, {
    "CODE": "BMT2011",
    "TITLE": "Training and Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "GOMATHI S"
}, {
    "CODE": "BMT2011",
    "TITLE": "Training and Development",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT602",
    "SLOT": "C2",
    "FACULTY": "INDIRA DEVI R"
}, {
    "CODE": "BMT2011",
    "TITLE": "Training and Development",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "INDIRA DEVI R"
}, {
    "CODE": "BMT2012",
    "TITLE": "Industrial Relations and Labour Law",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT604",
    "SLOT": "A2+TA2",
    "FACULTY": "SELVAM M"
}, {
    "CODE": "BMT2012",
    "TITLE": "Industrial Relations and Labour Law",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "SJT604",
    "SLOT": "F1+TF1",
    "FACULTY": "T.N.V.R.L. SWAMY"
}, {
    "CODE": "BMT213",
    "TITLE": "Summer Internship in Service Sector",
    "TYPE": "PJT",
    "CREDITS": "5",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "BMT3001",
    "TITLE": "Financial Management",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT602A",
    "SLOT": "F1+TF1",
    "FACULTY": "VASUMATHI  A"
}, {
    "CODE": "BMT3001",
    "TITLE": "Financial Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VASUMATHI  A"
}, {
    "CODE": "BMT3001",
    "TITLE": "Financial Management",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "SJT603",
    "SLOT": "F1+TF1",
    "FACULTY": "SUBHASHREE P"
}, {
    "CODE": "BMT3001",
    "TITLE": "Financial Management",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUBHASHREE P"
}, {
    "CODE": "BMT3004",
    "TITLE": "Managing the Family Business",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT601",
    "SLOT": "B2",
    "FACULTY": "SUDIPTO BHATTACHARYA"
}, {
    "CODE": "BMT3004",
    "TITLE": "Managing the Family Business",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SUDIPTO BHATTACHARYA"
}, {
    "CODE": "BMT306",
    "TITLE": "Accounting Software Application",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "SJT627",
    "SLOT": "B2",
    "FACULTY": "THIRUVENKADAM A"
}, {
    "CODE": "BMT306",
    "TITLE": "Accounting Software Application",
    "TYPE": "ELA",
    "CREDITS": "1",
    "VENUE": "SJT620",
    "SLOT": "L39+L40",
    "FACULTY": "THIRUVENKADAM A"
}, {
    "CODE": "BMT308",
    "TITLE": "Summer Internship in Manufacturing\nSector",
    "TYPE": "PJT",
    "CREDITS": "5",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "BMT3099",
    "TITLE": "Capstone Project",
    "TYPE": "PJT",
    "CREDITS": "10",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "ARC1013",
    "TITLE": "Basic Design and Workshop",
    "TYPE": "ELA",
    "CREDITS": "6",
    "VENUE": "LIB402",
    "SLOT": "L43+L44+L45+L46+L 49+L50+L51+L52+L\n55+L56+L57+L58",
    "FACULTY": "VIDYALAKSHMI S"
}, {
    "CODE": "ARC1013",
    "TITLE": "Basic Design and Workshop",
    "TYPE": "EPJ",
    "CREDITS": "2",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "VIDYALAKSHMI S"
}, {
    "CODE": "ARC1013",
    "TITLE": "Basic Design and Workshop",
    "TYPE": "ELA",
    "CREDITS": "6",
    "VENUE": "LIB402",
    "SLOT": "L43+L44+L45+L46+L 49+L50+L51+L52+L\n55+L56+L57+L58",
    "FACULTY": "BHASKAR JYOTI BORGOHAIN"
}, {
    "CODE": "ARC1013",
    "TITLE": "Basic Design and Workshop",
    "TYPE": "EPJ",
    "CREDITS": "2",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "BHASKAR JYOTI BORGOHAIN"
}, {
    "CODE": "ARC1014",
    "TITLE": "Visual Arts - Basic Skill Development",
    "TYPE": "LO",
    "CREDITS": "4",
    "VENUE": "LIB402",
    "SLOT": "L31+L32+L33+L34+L\n37+L38+L39+L40",
    "FACULTY": "BHASKAR JYOTI BORGOHAIN"
}, {
    "CODE": "ARC1015",
    "TITLE": "Basic Architectural Graphics",
    "TYPE": "LO",
    "CREDITS": "3",
    "VENUE": "LIB402",
    "SLOT": "L9+L10+L11+L12+L2\n9+L30",
    "FACULTY": "DEVI PRASAD N"
}, {
    "CODE": "ARC1015",
    "TITLE": "Basic Architectural Graphics",
    "TYPE": "LO",
    "CREDITS": "3",
    "VENUE": "LIB402",
    "SLOT": "L9+L10+L11+L12+L2\n9+L30",
    "FACULTY": "E.S. DINESH RAGHAVAN"
}, {
    "CODE": "ARC1016",
    "TITLE": "Study Tour 1",
    "TYPE": "PJT",
    "CREDITS": "2",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "ARC1018",
    "TITLE": "Theory of Landscape Design",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "LIB601",
    "SLOT": "E1",
    "FACULTY": "JAYADEV N"
}, {
    "CODE": "ARC1018",
    "TITLE": "Theory of Landscape Design",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JAYADEV N"
}, {
    "CODE": "ARC1020",
    "TITLE": "Human Settlements and Vernacular\nArchitecture",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "LIB601",
    "SLOT": "D1",
    "FACULTY": "KAAVIYA  R"
}, {
    "CODE": "ARC1020",
    "TITLE": "Human Settlements and Vernacular\nArchitecture",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KAAVIYA  R"
}, {
    "CODE": "ARC1023",
    "TITLE": "Building Services - Plumbing and\nSanitary",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "LIB501",
    "SLOT": "D1+TD1",
    "FACULTY": "MOHAFIZ RIYAZ"
}, {
    "CODE": "ARC1024",
    "TITLE": "Computer Graphics - Skill Development",
    "TYPE": "LO",
    "CREDITS": "3",
    "VENUE": "LIB502",
    "SLOT": "L23+L24+L31+L32+L\n33+L34",
    "FACULTY": "MOHAFIZ RIYAZ"
}, {
    "CODE": "ARC1025",
    "TITLE": "Environmental Studies -Site Planning, Landscape and Climatology",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "LIB501",
    "SLOT": "F1",
    "FACULTY": "KOTA SANDEEP"
}, {
    "CODE": "ARC1025",
    "TITLE": "Environmental Studies -Site Planning, Landscape and Climatology",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KOTA SANDEEP"
}, {
    "CODE": "ARC2001",
    "TITLE": "Strength of Materials",
    "TYPE": "TH",
    "CREDITS": "2",
    "VENUE": "LIB501",
    "SLOT": "A1",
    "FACULTY": "VISWANATHAN T S"
}, {
    "CODE": "ARC2016",
    "TITLE": "Study Tour 2",
    "TYPE": "PJT",
    "CREDITS": "2",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "ARC2018",
    "TITLE": "Architecture Structural Design-\nComposite",
    "TYPE": "TH",
    "CREDITS": "3",
    "VENUE": "LIB601",
    "SLOT": "A1+TA1",
    "FACULTY": "SUNEEL KUMAR M"
}, {
    "CODE": "ARC3001",
    "TITLE": "Architectural Design - Rural Study",
    "TYPE": "ELA",
    "CREDITS": "6",
    "VENUE": "LIB502",
    "SLOT": "L43+L44+L45+L46+L 49+L50+L51+L52+L\n55+L56+L57+L58",
    "FACULTY": "KAAVIYA  R"
}, {
    "CODE": "ARC3001",
    "TITLE": "Architectural Design - Rural Study",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KAAVIYA  R"
}, {
    "CODE": "ARC3001",
    "TITLE": "Architectural Design - Rural Study",
    "TYPE": "ELA",
    "CREDITS": "6",
    "VENUE": "LIB502",
    "SLOT": "L43+L44+L45+L46+L 49+L50+L51+L52+L\n55+L56+L57+L58",
    "FACULTY": "JAYADEV N"
}, {
    "CODE": "ARC3001",
    "TITLE": "Architectural Design - Rural Study",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "JAYADEV N"
}, {
    "CODE": "ARC3003",
    "TITLE": "Construction Technology - Concrete and\nSteel",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "LIB501",
    "SLOT": "TA1",
    "FACULTY": "MOHAFIZ RIYAZ"
}, {
    "CODE": "ARC3003",
    "TITLE": "Construction Technology - Concrete and\nSteel",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "LIB502",
    "SLOT": "L37+L38+L39+L40",
    "FACULTY": "MOHAFIZ RIYAZ"
}, {
    "CODE": "ARC3003",
    "TITLE": "Construction Technology - Concrete and\nSteel",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "LIB502",
    "SLOT": "L37+L38+L39+L40",
    "FACULTY": "DEVI PRASAD N"
}, {
    "CODE": "ARC3006",
    "TITLE": "History and Theory of Architecture -\nAncient",
    "TYPE": "ETH",
    "CREDITS": "3",
    "VENUE": "LIB501",
    "SLOT": "C1+TC1",
    "FACULTY": "SHEFALI NAYAK"
}, {
    "CODE": "ARC3006",
    "TITLE": "History and Theory of Architecture -\nAncient",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "SHEFALI NAYAK"
}, {
    "CODE": "ARC3099",
    "TITLE": "Internship",
    "TYPE": "PJT",
    "CREDITS": "12",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "ACADEMICS"
}, {
    "CODE": "ARC5002",
    "TITLE": "Construction Technology -Interiors and\nLandscape",
    "TYPE": "ETH",
    "CREDITS": "1",
    "VENUE": "LIB601",
    "SLOT": "TD1",
    "FACULTY": "MEENAKSHI PAPPU"
}, {
    "CODE": "ARC5002",
    "TITLE": "Construction Technology -Interiors and\nLandscape",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "LIB602",
    "SLOT": "L37+L38+L39+L40",
    "FACULTY": "MEENAKSHI PAPPU"
}, {
    "CODE": "ARC5002",
    "TITLE": "Construction Technology -Interiors and\nLandscape",
    "TYPE": "ELA",
    "CREDITS": "2",
    "VENUE": "LIB602",
    "SLOT": "L37+L38+L39+L40",
    "FACULTY": "VIDYALAKSHMI S"
}, {
    "CODE": "ARC5006",
    "TITLE": "Architectural Conservation",
    "TYPE": "ETH",
    "CREDITS": "2",
    "VENUE": "LIB601",
    "SLOT": "F1",
    "FACULTY": "E.S. DINESH RAGHAVAN"
}, {
    "CODE": "ARC5006",
    "TITLE": "Architectural Conservation",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "E.S. DINESH RAGHAVAN"
}, {
    "CODE": "ARC5014",
    "TITLE": "Architectural Design – Institutions",
    "TYPE": "ELA",
    "CREDITS": "6",
    "VENUE": "LIB602",
    "SLOT": "L43+L44+L45+L46+L 49+L50+L51+L52+L\n55+L56+L57+L58",
    "FACULTY": "DURGANAND BALSAVAR"
}, {
    "CODE": "ARC5014",
    "TITLE": "Architectural Design – Institutions",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "DURGANAND BALSAVAR"
}, {
    "CODE": "ARC5014",
    "TITLE": "Architectural Design – Institutions",
    "TYPE": "ELA",
    "CREDITS": "6",
    "VENUE": "LIB602",
    "SLOT": "L43+L44+L45+L46+L 49+L50+L51+L52+L\n55+L56+L57+L58",
    "FACULTY": "KOTA SANDEEP"
}, {
    "CODE": "ARC5014",
    "TITLE": "Architectural Design – Institutions",
    "TYPE": "EPJ",
    "CREDITS": "1",
    "VENUE": "NIL",
    "SLOT": "NIL",
    "FACULTY": "KOTA SANDEEP"
}];

export default facultiesInfo;