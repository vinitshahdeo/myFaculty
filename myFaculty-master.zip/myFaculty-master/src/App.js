import React, { Component } from 'react';
import AutoCompletedText from './myFaculty';
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <AutoCompletedText />
      </div>
    );
  }
}

export default App;
